
-- Create table for business integration settings
CREATE TABLE business_integration_settings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  provider TEXT NOT NULL,
  settings JSONB,
  is_enabled BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  UNIQUE(business_id, provider)
);
ALTER TABLE business_integration_settings ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER business_integration_settings_updated_at BEFORE UPDATE ON business_integration_settings FOR EACH ROW EXECUTE FUNCTION handle_updated_at();

-- Create table for custom field mappings
CREATE TABLE custom_field_mappings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  provider TEXT NOT NULL,
  local_field TEXT NOT NULL,
  remote_field TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);
ALTER TABLE custom_field_mappings ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER custom_field_mappings_updated_at BEFORE UPDATE ON custom_field_mappings FOR EACH ROW EXECUTE FUNCTION handle_updated_at();

-- Create table for sync logs
CREATE TABLE sync_logs (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  provider TEXT NOT NULL,
  status TEXT CHECK (status IN ('success', 'failed', 'in_progress')) NOT NULL,
  direction TEXT CHECK (direction IN ('local_to_remote', 'remote_to_local')),
  records_processed INTEGER,
  details TEXT,
  started_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  finished_at TIMESTAMP WITH TIME ZONE
);
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for business_integration_settings
CREATE POLICY "Users can view their business integration settings" ON business_integration_settings FOR SELECT USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND status = 'active')
);
CREATE POLICY "Business owners/admins can manage integration settings" ON business_integration_settings FOR ALL USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active')
);

-- RLS Policies for custom_field_mappings
CREATE POLICY "Users can view their custom field mappings" ON custom_field_mappings FOR SELECT USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND status = 'active')
);
CREATE POLICY "Business owners/admins can manage custom field mappings" ON custom_field_mappings FOR ALL USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active')
);

-- RLS Policies for sync_logs
CREATE POLICY "Users can view their sync logs" ON sync_logs FOR SELECT USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND status = 'active')
);
CREATE POLICY "Business owners/admins can manage sync logs" ON sync_logs FOR ALL USING (
  business_id IN (SELECT business_id FROM business_users WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active')
);
