
-- Create enum for business types
CREATE TYPE business_type AS ENUM ('medical', 'dental', 'legal', 'real_estate', 'retail', 'restaurant', 'automotive', 'beauty', 'fitness', 'other');

-- Create enum for subscription plans
CREATE TYPE subscription_plan AS ENUM ('free', 'starter', 'professional', 'enterprise');

-- Create businesses table for multi-tenancy
CREATE TABLE businesses (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  business_type business_type NOT NULL,
  industry TEXT,
  phone_number TEXT,
  email TEXT,
  website TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  zip_code TEXT,
  country TEXT DEFAULT 'US',
  timezone TEXT DEFAULT 'America/New_York',
  operating_hours JSONB DEFAULT '{}',
  subscription_plan subscription_plan DEFAULT 'free',
  subscription_status TEXT DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Update profiles table to link to businesses
ALTER TABLE profiles ADD COLUMN business_id UUID REFERENCES businesses(id) ON DELETE CASCADE;
ALTER TABLE profiles ADD COLUMN is_business_owner BOOLEAN DEFAULT false;

-- Create business_users junction table for team management
CREATE TABLE business_users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  role TEXT CHECK (role IN ('owner', 'admin', 'agent', 'viewer')) DEFAULT 'agent',
  invited_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()),
  joined_at TIMESTAMP WITH TIME ZONE,
  status TEXT CHECK (status IN ('pending', 'active', 'inactive')) DEFAULT 'pending',
  UNIQUE(business_id, user_id)
);

-- Update customers table to be business-specific
ALTER TABLE customers ADD COLUMN business_id UUID REFERENCES businesses(id) ON DELETE CASCADE;

-- Update calls table to be business-specific
ALTER TABLE calls ADD COLUMN business_id UUID REFERENCES businesses(id) ON DELETE CASCADE;

-- Update analytics table to be business-specific
ALTER TABLE analytics ADD COLUMN business_id UUID REFERENCES businesses(id) ON DELETE CASCADE;

-- Add trigger for businesses updated_at
CREATE TRIGGER businesses_updated_at BEFORE UPDATE ON businesses FOR EACH ROW EXECUTE FUNCTION handle_updated_at();

-- Enable RLS on new tables
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_users ENABLE ROW LEVEL SECURITY;

-- RLS Policies for businesses
CREATE POLICY "Users can view their own business" ON businesses FOR SELECT USING (
  id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Business owners can update their business" ON businesses FOR UPDATE USING (
  id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active'
  )
);

CREATE POLICY "Authenticated users can create businesses" ON businesses FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- RLS Policies for business_users
CREATE POLICY "Users can view business team members" ON business_users FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Business owners can manage team" ON business_users FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active'
  )
);

-- Update existing RLS policies to include business_id checks
DROP POLICY IF EXISTS "Authenticated users can view customers" ON customers;
DROP POLICY IF EXISTS "Authenticated users can manage customers" ON customers;

CREATE POLICY "Users can view business customers" ON customers FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Users can manage business customers" ON customers FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

-- Update calls policies
DROP POLICY IF EXISTS "Authenticated users can view calls" ON calls;
DROP POLICY IF EXISTS "Authenticated users can manage calls" ON calls;

CREATE POLICY "Users can view business calls" ON calls FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Users can manage business calls" ON calls FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

-- Update analytics policies
DROP POLICY IF EXISTS "Authenticated users can view analytics" ON analytics;
DROP POLICY IF EXISTS "Admins can manage analytics" ON analytics;

CREATE POLICY "Users can view business analytics" ON analytics FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Business owners can manage analytics" ON analytics FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active'
  )
);

-- Function to automatically create business owner relationship
CREATE OR REPLACE FUNCTION create_business_owner()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert the business owner into business_users
  INSERT INTO business_users (business_id, user_id, role, status, joined_at)
  VALUES (NEW.id, auth.uid(), 'owner', 'active', now());
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create business owner relationship
CREATE TRIGGER on_business_created
  AFTER INSERT ON businesses
  FOR EACH ROW
  EXECUTE FUNCTION create_business_owner();
