
-- Insert sample calls to populate the dashboard
INSERT INTO calls (customer_id, agent_id, status, call_type, duration, sentiment_score, intent, transcript, created_at, updated_at) 
SELECT 
  c.id as customer_id,
  p.id as agent_id,
  CASE 
    WHEN random() < 0.3 THEN 'active'
    WHEN random() < 0.6 THEN 'queued'
    WHEN random() < 0.8 THEN 'completed'
    ELSE 'dropped'
  END as status,
  CASE WHEN random() < 0.7 THEN 'inbound' ELSE 'outbound' END as call_type,
  CASE 
    WHEN random() < 0.3 THEN 0  -- active/queued calls have 0 duration
    ELSE floor(random() * 600 + 60)::integer  -- completed calls 1-10 minutes
  END as duration,
  (random() * 2 - 1)::numeric as sentiment_score,  -- -1 to 1
  CASE 
    WHEN random() < 0.25 THEN 'billing'
    WHEN random() < 0.5 THEN 'support'
    WHEN random() < 0.75 THEN 'account'
    ELSE 'general'
  END as intent,
  CASE 
    WHEN random() < 0.3 THEN 'Hello, I need help with my account'
    WHEN random() < 0.6 THEN 'I have a billing question'
    ELSE 'Thank you for your assistance'
  END as transcript,
  now() - interval '1 hour' * random() * 24 as created_at,
  now() - interval '1 hour' * random() * 24 as updated_at
FROM customers c
CROSS JOIN profiles p
WHERE c.id IN (SELECT id FROM customers LIMIT 3)
AND p.id IN (SELECT id FROM profiles LIMIT 2)
LIMIT 15
ON CONFLICT DO NOTHING;

-- Insert some active calls for real-time demonstration
INSERT INTO calls (customer_id, status, call_type, duration, created_at, updated_at)
SELECT 
  c.id,
  'active',
  'inbound',
  floor(random() * 300)::integer,
  now() - interval '1 minute' * floor(random() * 30),
  now()
FROM customers c
LIMIT 3
ON CONFLICT DO NOTHING;

-- Insert some queued calls
INSERT INTO calls (customer_id, status, call_type, duration, created_at, updated_at)
SELECT 
  c.id,
  'queued',
  'inbound',
  0,
  now() - interval '1 minute' * floor(random() * 10),
  now()
FROM customers c
LIMIT 2
ON CONFLICT DO NOTHING;

-- Update today's analytics with realistic data
UPDATE analytics 
SET 
  total_calls = 52,
  answered_calls = 45,
  dropped_calls = 7,
  avg_wait_time = 145,
  avg_call_duration = 320,
  customer_satisfaction = 78
WHERE date = CURRENT_DATE;

-- Insert analytics for yesterday if not exists
INSERT INTO analytics (date, total_calls, answered_calls, dropped_calls, avg_wait_time, avg_call_duration, customer_satisfaction)
VALUES (CURRENT_DATE - INTERVAL '1 day', 48, 42, 6, 135, 298, 76)
ON CONFLICT (date) DO NOTHING;
