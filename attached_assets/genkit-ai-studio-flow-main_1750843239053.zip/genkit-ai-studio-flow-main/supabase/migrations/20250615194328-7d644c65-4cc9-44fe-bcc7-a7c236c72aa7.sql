
-- Add missing tables for comprehensive customer and business management

-- Enhance customers table with additional fields for better management
ALTER TABLE customers ADD COLUMN IF NOT EXISTS notes TEXT;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS tags TEXT[];
ALTER TABLE customers ADD COLUMN IF NOT EXISTS last_contact_date TIMESTAMP WITH TIME ZONE;
ALTER TABLE customers ADD COLUMN IF NOT EXISTS preferred_contact_method TEXT CHECK (preferred_contact_method IN ('phone', 'email', 'sms')) DEFAULT 'phone';

-- Create agent_configurations table for AI agent settings
CREATE TABLE IF NOT EXISTS agent_configurations (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  personality JSONB DEFAULT '{}',
  voice_settings JSONB DEFAULT '{}',
  knowledge_base TEXT,
  response_templates JSONB DEFAULT '{}',
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create knowledge_base table for storing business information
CREATE TABLE IF NOT EXISTS knowledge_base (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT,
  tags TEXT[],
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create call_recordings table for storing call data
CREATE TABLE IF NOT EXISTS call_recordings (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  call_id UUID REFERENCES calls(id) ON DELETE CASCADE NOT NULL,
  recording_url TEXT,
  transcript TEXT,
  summary TEXT,
  sentiment_analysis JSONB,
  duration INTEGER DEFAULT 0,
  file_size BIGINT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create campaigns table for outbound calling campaigns
CREATE TABLE IF NOT EXISTS campaigns (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  status TEXT CHECK (status IN ('draft', 'active', 'paused', 'completed')) DEFAULT 'draft',
  target_customers UUID[],
  script TEXT,
  schedule_settings JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create notifications table for system notifications
CREATE TABLE IF NOT EXISTS notifications (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID NOT NULL,
  business_id UUID REFERENCES businesses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT CHECK (type IN ('info', 'warning', 'error', 'success')) DEFAULT 'info',
  is_read BOOLEAN DEFAULT false,
  action_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Add triggers for updated_at
CREATE TRIGGER agent_configurations_updated_at BEFORE UPDATE ON agent_configurations FOR EACH ROW EXECUTE FUNCTION handle_updated_at();
CREATE TRIGGER knowledge_base_updated_at BEFORE UPDATE ON knowledge_base FOR EACH ROW EXECUTE FUNCTION handle_updated_at();
CREATE TRIGGER campaigns_updated_at BEFORE UPDATE ON campaigns FOR EACH ROW EXECUTE FUNCTION handle_updated_at();

-- Enable RLS on new tables
ALTER TABLE agent_configurations ENABLE ROW LEVEL SECURITY;
ALTER TABLE knowledge_base ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_recordings ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- RLS Policies for agent_configurations
CREATE POLICY "Users can view business agent configurations" ON agent_configurations FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Business admins can manage agent configurations" ON agent_configurations FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND role IN ('owner', 'admin') AND status = 'active'
  )
);

-- RLS Policies for knowledge_base
CREATE POLICY "Users can view business knowledge base" ON knowledge_base FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Users can manage business knowledge base" ON knowledge_base FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

-- RLS Policies for call_recordings
CREATE POLICY "Users can view business call recordings" ON call_recordings FOR SELECT USING (
  call_id IN (
    SELECT c.id FROM calls c
    WHERE c.business_id IN (
      SELECT business_id FROM business_users 
      WHERE user_id = auth.uid() AND status = 'active'
    )
  )
);

CREATE POLICY "Users can manage business call recordings" ON call_recordings FOR ALL USING (
  call_id IN (
    SELECT c.id FROM calls c
    WHERE c.business_id IN (
      SELECT business_id FROM business_users 
      WHERE user_id = auth.uid() AND status = 'active'
    )
  )
);

-- RLS Policies for campaigns
CREATE POLICY "Users can view business campaigns" ON campaigns FOR SELECT USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

CREATE POLICY "Users can manage business campaigns" ON campaigns FOR ALL USING (
  business_id IN (
    SELECT business_id FROM business_users 
    WHERE user_id = auth.uid() AND status = 'active'
  )
);

-- RLS Policies for notifications
CREATE POLICY "Users can view their notifications" ON notifications FOR SELECT USING (
  user_id = auth.uid()
);

CREATE POLICY "Users can update their notifications" ON notifications FOR UPDATE USING (
  user_id = auth.uid()
);

-- Enable realtime for new tables
ALTER TABLE agent_configurations REPLICA IDENTITY FULL;
ALTER TABLE knowledge_base REPLICA IDENTITY FULL;
ALTER TABLE call_recordings REPLICA IDENTITY FULL;
ALTER TABLE campaigns REPLICA IDENTITY FULL;
ALTER TABLE notifications REPLICA IDENTITY FULL;

-- Add tables to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE agent_configurations;
ALTER PUBLICATION supabase_realtime ADD TABLE knowledge_base;
ALTER PUBLICATION supabase_realtime ADD TABLE call_recordings;
ALTER PUBLICATION supabase_realtime ADD TABLE campaigns;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- Insert sample data for testing
INSERT INTO agent_configurations (business_id, name, personality, knowledge_base) 
SELECT b.id, 'Default Agent', 
  '{"tone": "professional", "style": "helpful", "personality": "friendly"}',
  'I am a helpful AI assistant for this business. I can help with general inquiries and provide information about our services.'
FROM businesses b 
ON CONFLICT DO NOTHING;
