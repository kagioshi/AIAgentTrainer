
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { keys } = await req.json()
    
    if (!Array.isArray(keys)) {
      throw new Error('Keys must be an array')
    }

    const secrets: Record<string, string> = {}
    
    for (const key of keys) {
      const value = Deno.env.get(key)
      if (value) {
        secrets[key] = value
      }
    }

    return new Response(
      JSON.stringify(secrets),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        } 
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        } 
      },
    )
  }
})
