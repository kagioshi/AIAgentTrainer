export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      agent_configurations: {
        Row: {
          business_id: string
          created_at: string
          id: string
          is_active: boolean | null
          knowledge_base: string | null
          name: string
          personality: Json | null
          response_templates: Json | null
          updated_at: string
          voice_settings: Json | null
        }
        Insert: {
          business_id: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          knowledge_base?: string | null
          name: string
          personality?: Json | null
          response_templates?: Json | null
          updated_at?: string
          voice_settings?: Json | null
        }
        Update: {
          business_id?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          knowledge_base?: string | null
          name?: string
          personality?: Json | null
          response_templates?: Json | null
          updated_at?: string
          voice_settings?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_configurations_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      analytics: {
        Row: {
          answered_calls: number | null
          avg_call_duration: number | null
          avg_wait_time: number | null
          business_id: string | null
          created_at: string
          customer_satisfaction: number | null
          date: string
          dropped_calls: number | null
          id: string
          total_calls: number | null
        }
        Insert: {
          answered_calls?: number | null
          avg_call_duration?: number | null
          avg_wait_time?: number | null
          business_id?: string | null
          created_at?: string
          customer_satisfaction?: number | null
          date: string
          dropped_calls?: number | null
          id?: string
          total_calls?: number | null
        }
        Update: {
          answered_calls?: number | null
          avg_call_duration?: number | null
          avg_wait_time?: number | null
          business_id?: string | null
          created_at?: string
          customer_satisfaction?: number | null
          date?: string
          dropped_calls?: number | null
          id?: string
          total_calls?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "analytics_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_integration_settings: {
        Row: {
          business_id: string
          created_at: string
          id: string
          is_enabled: boolean | null
          provider: string
          settings: Json | null
          updated_at: string
        }
        Insert: {
          business_id: string
          created_at?: string
          id?: string
          is_enabled?: boolean | null
          provider: string
          settings?: Json | null
          updated_at?: string
        }
        Update: {
          business_id?: string
          created_at?: string
          id?: string
          is_enabled?: boolean | null
          provider?: string
          settings?: Json | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_integration_settings_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      business_users: {
        Row: {
          business_id: string
          id: string
          invited_at: string | null
          joined_at: string | null
          role: string | null
          status: string | null
          user_id: string
        }
        Insert: {
          business_id: string
          id?: string
          invited_at?: string | null
          joined_at?: string | null
          role?: string | null
          status?: string | null
          user_id: string
        }
        Update: {
          business_id?: string
          id?: string
          invited_at?: string | null
          joined_at?: string | null
          role?: string | null
          status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_users_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      businesses: {
        Row: {
          address: string | null
          business_type: Database["public"]["Enums"]["business_type"]
          city: string | null
          country: string | null
          created_at: string
          email: string | null
          id: string
          industry: string | null
          name: string
          operating_hours: Json | null
          phone_number: string | null
          state: string | null
          subscription_plan:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status: string | null
          timezone: string | null
          updated_at: string
          website: string | null
          zip_code: string | null
        }
        Insert: {
          address?: string | null
          business_type: Database["public"]["Enums"]["business_type"]
          city?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          id?: string
          industry?: string | null
          name: string
          operating_hours?: Json | null
          phone_number?: string | null
          state?: string | null
          subscription_plan?:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status?: string | null
          timezone?: string | null
          updated_at?: string
          website?: string | null
          zip_code?: string | null
        }
        Update: {
          address?: string | null
          business_type?: Database["public"]["Enums"]["business_type"]
          city?: string | null
          country?: string | null
          created_at?: string
          email?: string | null
          id?: string
          industry?: string | null
          name?: string
          operating_hours?: Json | null
          phone_number?: string | null
          state?: string | null
          subscription_plan?:
            | Database["public"]["Enums"]["subscription_plan"]
            | null
          subscription_status?: string | null
          timezone?: string | null
          updated_at?: string
          website?: string | null
          zip_code?: string | null
        }
        Relationships: []
      }
      call_recordings: {
        Row: {
          call_id: string
          created_at: string
          duration: number | null
          file_size: number | null
          id: string
          recording_url: string | null
          sentiment_analysis: Json | null
          summary: string | null
          transcript: string | null
        }
        Insert: {
          call_id: string
          created_at?: string
          duration?: number | null
          file_size?: number | null
          id?: string
          recording_url?: string | null
          sentiment_analysis?: Json | null
          summary?: string | null
          transcript?: string | null
        }
        Update: {
          call_id?: string
          created_at?: string
          duration?: number | null
          file_size?: number | null
          id?: string
          recording_url?: string | null
          sentiment_analysis?: Json | null
          summary?: string | null
          transcript?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "call_recordings_call_id_fkey"
            columns: ["call_id"]
            isOneToOne: false
            referencedRelation: "calls"
            referencedColumns: ["id"]
          },
        ]
      }
      calls: {
        Row: {
          agent_id: string | null
          business_id: string | null
          call_type: string
          created_at: string
          customer_id: string
          duration: number | null
          id: string
          intent: string | null
          recording_url: string | null
          sentiment_score: number | null
          status: string | null
          transcript: string | null
          updated_at: string
        }
        Insert: {
          agent_id?: string | null
          business_id?: string | null
          call_type: string
          created_at?: string
          customer_id: string
          duration?: number | null
          id?: string
          intent?: string | null
          recording_url?: string | null
          sentiment_score?: number | null
          status?: string | null
          transcript?: string | null
          updated_at?: string
        }
        Update: {
          agent_id?: string | null
          business_id?: string | null
          call_type?: string
          created_at?: string
          customer_id?: string
          duration?: number | null
          id?: string
          intent?: string | null
          recording_url?: string | null
          sentiment_score?: number | null
          status?: string | null
          transcript?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "calls_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calls_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "calls_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          business_id: string
          created_at: string
          description: string | null
          id: string
          name: string
          schedule_settings: Json | null
          script: string | null
          status: string | null
          target_customers: string[] | null
          updated_at: string
        }
        Insert: {
          business_id: string
          created_at?: string
          description?: string | null
          id?: string
          name: string
          schedule_settings?: Json | null
          script?: string | null
          status?: string | null
          target_customers?: string[] | null
          updated_at?: string
        }
        Update: {
          business_id?: string
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          schedule_settings?: Json | null
          script?: string | null
          status?: string | null
          target_customers?: string[] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      custom_field_mappings: {
        Row: {
          business_id: string
          created_at: string
          id: string
          local_field: string
          provider: string
          remote_field: string
          updated_at: string
        }
        Insert: {
          business_id: string
          created_at?: string
          id?: string
          local_field: string
          provider: string
          remote_field: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          created_at?: string
          id?: string
          local_field?: string
          provider?: string
          remote_field?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "custom_field_mappings_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          business_id: string | null
          created_at: string
          email: string | null
          first_name: string | null
          id: string
          last_contact_date: string | null
          last_name: string | null
          notes: string | null
          phone_number: string
          preferred_contact_method: string | null
          status: string | null
          tags: string[] | null
          tier: string | null
          updated_at: string
        }
        Insert: {
          business_id?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          id?: string
          last_contact_date?: string | null
          last_name?: string | null
          notes?: string | null
          phone_number: string
          preferred_contact_method?: string | null
          status?: string | null
          tags?: string[] | null
          tier?: string | null
          updated_at?: string
        }
        Update: {
          business_id?: string | null
          created_at?: string
          email?: string | null
          first_name?: string | null
          id?: string
          last_contact_date?: string | null
          last_name?: string | null
          notes?: string | null
          phone_number?: string
          preferred_contact_method?: string | null
          status?: string | null
          tags?: string[] | null
          tier?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "customers_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      knowledge_base: {
        Row: {
          business_id: string
          category: string | null
          content: string
          created_at: string
          id: string
          is_active: boolean | null
          tags: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          business_id: string
          category?: string | null
          content: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          tags?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          business_id?: string
          category?: string | null
          content?: string
          created_at?: string
          id?: string
          is_active?: boolean | null
          tags?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "knowledge_base_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          action_url: string | null
          business_id: string | null
          created_at: string
          id: string
          is_read: boolean | null
          message: string
          title: string
          type: string | null
          user_id: string
        }
        Insert: {
          action_url?: string | null
          business_id?: string | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message: string
          title: string
          type?: string | null
          user_id: string
        }
        Update: {
          action_url?: string | null
          business_id?: string | null
          created_at?: string
          id?: string
          is_read?: boolean | null
          message?: string
          title?: string
          type?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          business_id: string | null
          created_at: string
          email: string
          first_name: string | null
          id: string
          is_business_owner: boolean | null
          last_name: string | null
          role: string | null
          updated_at: string
        }
        Insert: {
          business_id?: string | null
          created_at?: string
          email: string
          first_name?: string | null
          id: string
          is_business_owner?: boolean | null
          last_name?: string | null
          role?: string | null
          updated_at?: string
        }
        Update: {
          business_id?: string | null
          created_at?: string
          email?: string
          first_name?: string | null
          id?: string
          is_business_owner?: boolean | null
          last_name?: string | null
          role?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      sync_logs: {
        Row: {
          business_id: string
          details: string | null
          direction: string | null
          finished_at: string | null
          id: string
          provider: string
          records_processed: number | null
          started_at: string
          status: string
        }
        Insert: {
          business_id: string
          details?: string | null
          direction?: string | null
          finished_at?: string | null
          id?: string
          provider: string
          records_processed?: number | null
          started_at?: string
          status: string
        }
        Update: {
          business_id?: string
          details?: string | null
          direction?: string | null
          finished_at?: string | null
          id?: string
          provider?: string
          records_processed?: number | null
          started_at?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "sync_logs_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      business_type:
        | "medical"
        | "dental"
        | "legal"
        | "real_estate"
        | "retail"
        | "restaurant"
        | "automotive"
        | "beauty"
        | "fitness"
        | "other"
      subscription_plan: "free" | "starter" | "professional" | "enterprise"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      business_type: [
        "medical",
        "dental",
        "legal",
        "real_estate",
        "retail",
        "restaurant",
        "automotive",
        "beauty",
        "fitness",
        "other",
      ],
      subscription_plan: ["free", "starter", "professional", "enterprise"],
    },
  },
} as const
