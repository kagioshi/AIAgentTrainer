
import { Database } from '@/integrations/supabase/types';

// Enhanced type definitions for better type safety
export type Tables = Database['public']['Tables'];

// Base table types
export type Call = Tables['calls']['Row'];
export type Customer = Tables['customers']['Row'];
export type Profile = Tables['profiles']['Row'];
export type Analytics = Tables['analytics']['Row'];
export type BusinessIntegrationSettings = Tables['business_integration_settings']['Row'];
export type CustomFieldMapping = Tables['custom_field_mappings']['Row'];
export type SyncLog = Tables['sync_logs']['Row'];

// Insert types
export type CallInsert = Tables['calls']['Insert'];
export type CustomerInsert = Tables['customers']['Insert'];
export type ProfileInsert = Tables['profiles']['Insert'];
export type AnalyticsInsert = Tables['analytics']['Insert'];
export type BusinessIntegrationSettingsInsert = Tables['business_integration_settings']['Insert'];
export type CustomFieldMappingInsert = Tables['custom_field_mappings']['Insert'];
export type SyncLogInsert = Tables['sync_logs']['Insert'];

// Update types
export type CallUpdate = Tables['calls']['Update'];
export type CustomerUpdate = Tables['customers']['Update'];
export type ProfileUpdate = Tables['profiles']['Update'];
export type AnalyticsUpdate = Tables['analytics']['Update'];
export type BusinessIntegrationSettingsUpdate = Tables['business_integration_settings']['Update'];
export type CustomFieldMappingUpdate = Tables['custom_field_mappings']['Update'];
export type SyncLogUpdate = Tables['sync_logs']['Update'];

// Enum types for better type safety
export type CallStatus = 'queued' | 'active' | 'completed' | 'dropped';
export type CallType = 'inbound' | 'outbound';
export type CustomerStatus = 'active' | 'inactive';
export type CustomerTier = 'bronze' | 'silver' | 'gold' | 'platinum';
export type ProfileRole = 'admin' | 'supervisor' | 'agent';

// Enhanced interfaces with relationships
export interface CallWithRelations extends Call {
  customers?: Pick<Customer, 'first_name' | 'last_name' | 'phone_number' | 'email' | 'tier'>;
  profiles?: Pick<Profile, 'first_name' | 'last_name' | 'role'>;
}

export interface CustomerWithStats extends Customer {
  total_calls?: number;
  avg_duration?: number;
  satisfaction_score?: number;
}

export interface AgentWithStats extends Profile {
  active_calls?: number;
  total_calls_today?: number;
  avg_handle_time?: number;
}

// API Response types
export interface DashboardStats {
  activeCalls: number;
  availableAgents: string;
  avgHandleTime: string;
  customerSatisfaction: string;
}

// Fixed to match database schema (snake_case)
export interface CallMetrics {
  total_calls: number;
  answered_calls: number;
  dropped_calls: number;
  avg_wait_time: number;
  avg_call_duration: number;
  customer_satisfaction: number;
}

// Form validation types
export interface CallFormData {
  customer_id: string;
  call_type: CallType;
  agent_id?: string;
}

export interface CustomerFormData {
  phone_number: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  tier?: CustomerTier;
}

// Real-time update types
export interface RealtimeCallUpdate {
  id: string;
  status: CallStatus;
  duration?: number;
  agent_id?: string;
  sentiment_score?: number;
  intent?: string;
  transcript?: string;
}

export interface RealtimeAnalyticsUpdate extends AnalyticsUpdate {
  date: string;
}
