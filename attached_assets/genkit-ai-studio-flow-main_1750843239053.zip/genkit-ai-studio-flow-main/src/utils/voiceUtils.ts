
/**
 * Voice API and processing utilities for the AI Contact Center
 */

// WebRTC connection management
export interface WebRTCConnectionOptions {
  iceServers?: RTCIceServer[];
  audio: boolean;
  video: boolean;
}

// Audio processing options
export interface AudioProcessingOptions {
  sampleRate?: number;
  channels?: number;
  autoGainControl?: boolean;
  noiseSuppression?: boolean;
  echoCancellation?: boolean;
}

// Default WebRTC configuration
export const defaultRTCConfig: WebRTCConnectionOptions = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
  audio: true,
  video: false,
};

// Default audio processing settings
export const defaultAudioProcessing: AudioProcessingOptions = {
  sampleRate: 16000,
  channels: 1,
  autoGainControl: true,
  noiseSuppression: true,
  echoCancellation: true,
};

/**
 * Request microphone access with optimized audio settings
 */
export const requestMicrophone = async (options: AudioProcessingOptions = defaultAudioProcessing) => {
  try {
    const constraints = {
      audio: {
        sampleRate: options.sampleRate,
        channelCount: options.channels,
        autoGainControl: options.autoGainControl,
        noiseSuppression: options.noiseSuppression,
        echoCancellation: options.echoCancellation,
      }
    };
    
    return await navigator.mediaDevices.getUserMedia(constraints);
  } catch (error) {
    console.error('Error accessing microphone:', error);
    throw new Error('Microphone access denied');
  }
};

/**
 * Convert audio blob to base64 for API transmission
 */
export const audioToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64data = reader.result as string;
      resolve(base64data.split(',')[1]); // Remove the data URL prefix
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

/**
 * Convert text to speech using the Google Text-to-Speech API
 * This is a mock implementation that would be replaced with actual API calls
 */
export const textToSpeech = async (text: string, voice: string = 'en-US-Wavenet-F'): Promise<AudioBuffer> => {
  // This would be replaced with actual Google TTS API call
  console.log(`Converting to speech: ${text} using voice ${voice}`);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Create a simple audio context and buffer (mock implementation)
  const audioContext = new AudioContext();
  const buffer = audioContext.createBuffer(1, 16000, 16000);
  
  // In real implementation, we would decode the audio data from the API response
  return buffer;
};

/**
 * Play audio buffer through the speakers
 */
export const playAudioBuffer = (buffer: AudioBuffer): void => {
  const audioContext = new AudioContext();
  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start();
};

/**
 * Format seconds as MM:SS string
 */
export const formatCallDuration = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};
