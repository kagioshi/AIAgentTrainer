
export type VoiceState = 'inactive' | 'connecting' | 'listening' | 'processing' | 'speaking';

export class CallStateManager {
  private onStateChange?: (state: VoiceState) => void;

  constructor(onStateChange?: (state: VoiceState) => void) {
    this.onStateChange = onStateChange;
  }

  setState(state: VoiceState) {
    if (this.onStateChange) {
      this.onStateChange(state);
    }
  }

  transitionToConnecting() {
    this.setState('connecting');
  }

  transitionToListening() {
    this.setState('listening');
  }

  transitionToProcessing() {
    this.setState('processing');
  }

  transitionToSpeaking() {
    this.setState('speaking');
  }

  transitionToInactive() {
    this.setState('inactive');
  }
}
