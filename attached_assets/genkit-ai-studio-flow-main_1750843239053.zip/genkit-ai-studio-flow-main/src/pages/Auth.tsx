
import { SignIn, SignUp } from '@clerk/clerk-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Building2, Users, Phone } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

const Auth = () => {
  const [searchParams] = useSearchParams();
  const defaultTab = searchParams.get('tab') || 'login';

  const clerkAppearance = {
    elements: {
      rootBox: "mx-auto",
      card: "bg-transparent shadow-none",
      headerTitle: "text-white",
      headerSubtitle: "text-gray-300",
      socialButtonsBlockButton: "bg-white/10 border-white/20 text-white hover:bg-white/20",
      formFieldLabel: "text-white",
      formFieldInput: "bg-white/10 border-white/20 text-white",
      footerActionLink: "text-blue-400 hover:text-blue-300",
      identityPreviewText: "text-white",
      formButtonPrimary: "bg-blue-600 hover:bg-blue-700 text-white border-0 shadow-lg",
      footer: "hidden"
    },
    variables: {
      colorPrimary: "#2563eb", // blue-600
      colorPrimaryText: "#ffffff",
      colorBackground: "transparent",
      colorInputBackground: "rgba(255, 255, 255, 0.1)",
      colorInputText: "#ffffff",
      borderRadius: "0.375rem"
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Building2 className="w-8 h-8 text-white" />
            <h1 className="text-3xl font-bold text-white">ConversaAI</h1>
          </div>
          <p className="text-gray-300">Build AI agents for your business</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <Tabs defaultValue={defaultTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="signup">Sign Up</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <CardTitle className="text-white">Welcome back</CardTitle>
                <CardDescription className="text-gray-300">
                  Sign in to your ConversaAI account
                </CardDescription>
              </TabsContent>
              
              <TabsContent value="signup">
                <CardTitle className="text-white">Get started</CardTitle>
                <CardDescription className="text-gray-300">
                  Create your ConversaAI account and start building AI agents
                </CardDescription>
              </TabsContent>
            </Tabs>
          </CardHeader>

          <CardContent>
            <Tabs defaultValue={defaultTab} className="w-full">
              <TabsContent value="login">
                <div className="flex justify-center">
                  <SignIn 
                    appearance={clerkAppearance}
                    forceRedirectUrl="/"
                  />
                </div>
              </TabsContent>

              <TabsContent value="signup">
                <div className="flex justify-center">
                  <SignUp 
                    appearance={clerkAppearance}
                    forceRedirectUrl="/"
                  />
                </div>

                <div className="bg-blue-500/10 border-blue-500/20 border rounded-lg p-4 mt-4">
                  <div className="flex items-start gap-2 text-blue-400 text-sm">
                    <Building2 className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium">Next: Set up your business</p>
                      <p className="text-blue-300">After signing up, you'll configure your business profile and AI agent.</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-6 text-center">
              <div className="text-gray-400 text-sm">
                Trusted by businesses worldwide
              </div>
              <div className="flex items-center justify-center gap-6 mt-2 text-gray-500 text-xs">
                <div className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  <span>5000+ Users</span>
                </div>
                <div className="flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  <span>100k+ Calls</span>
                </div>
                <div className="flex items-center gap-1">
                  <Building2 className="w-3 h-3" />
                  <span>500+ Businesses</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Auth;
