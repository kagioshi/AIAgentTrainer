
import React, { useState } from 'react';
import Sidebar from '@/components/Sidebar';
import DashboardStats from '@/components/DashboardStats';
import CallManagementDashboard from '@/components/call-management/CallManagementDashboard';
import CustomerDashboard from '@/components/customers/CustomerDashboard';
import AnalyticsDashboard from '@/components/analytics/AnalyticsDashboard';
import CampaignDashboard from '@/components/campaigns/CampaignDashboard';
import ConversationFlowBuilder from '@/components/ai-features/ConversationFlowBuilder';
import IntegrationDashboard from '@/components/integrations/IntegrationDashboard';
import AgentManagementDashboard from '@/components/agents/AgentManagementDashboard';
import QueueDashboard from '@/components/call-management/QueueDashboard';
import { useAuth } from '@/hooks/useAuth';
import StreamingInterface from '@/components/StreamingInterface';

const Index = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Welcome to AI Contact Center</h1>
          <p className="text-xl text-gray-300 mb-8">Please sign in to continue</p>
          <a 
            href="/auth" 
            className="bg-white text-purple-900 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-gray-900">Dashboard Overview</h1>
            <DashboardStats />
            <div className="grid lg:grid-cols-2 gap-6">
              <StreamingInterface />
            </div>
          </div>
        );
      case 'calls':
        return <CallManagementDashboard />;
      case 'customers':
        return <CustomerDashboard />;
      case 'analytics':
        return <AnalyticsDashboard />;
      case 'campaigns':
        return <CampaignDashboard />;
      case 'ai-features':
        return <ConversationFlowBuilder />;
      case 'integrations':
        return <IntegrationDashboard />;
      case 'agents':
        return <AgentManagementDashboard />;
      case 'queue':
        return <QueueDashboard />;
      case 'conversations':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Conversations</h2>
            <p className="text-gray-600">Conversation analysis features coming soon...</p>
          </div>
        );
      case 'quality':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Quality Control</h2>
            <p className="text-gray-600">Quality control features coming soon...</p>
          </div>
        );
      case 'settings':
        return (
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Settings</h2>
            <p className="text-gray-600">System settings coming soon...</p>
          </div>
        );
      default:
        return <DashboardStats />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      <div className="flex">
        <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 p-8 overflow-auto">
          <div className="bg-white rounded-2xl shadow-xl min-h-[calc(100vh-4rem)] p-8">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Index;
