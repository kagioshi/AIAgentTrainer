
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, TrendingDown, Phone, Clock, Users, Star, Download, Calendar } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const AnalyticsDashboard = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [analytics, setAnalytics] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    try {
      const endDate = new Date();
      const startDate = new Date();
      
      switch (timeRange) {
        case '24h':
          startDate.setHours(startDate.getHours() - 24);
          break;
        case '7d':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(startDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(startDate.getDate() - 90);
          break;
      }

      // Fetch calls data
      const { data: calls } = await supabase
        .from('calls')
        .select('*')
        .gte('created_at', startDate.toISOString())
        .lte('created_at', endDate.toISOString());

      // Fetch analytics data
      const { data: analyticsData } = await supabase
        .from('analytics')
        .select('*')
        .gte('date', startDate.toISOString().split('T')[0])
        .lte('date', endDate.toISOString().split('T')[0])
        .order('date', { ascending: true });

      // Process data for charts
      const processedData = processAnalyticsData(calls || [], analyticsData || []);
      setAnalytics(processedData);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const processAnalyticsData = (calls: any[], analytics: any[]) => {
    // Generate daily stats
    const dailyStats = analytics.map(day => ({
      date: new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      totalCalls: day.total_calls || 0,
      answeredCalls: day.answered_calls || 0,
      droppedCalls: day.dropped_calls || 0,
      avgDuration: Math.round(day.avg_call_duration || 0),
      satisfaction: ((day.customer_satisfaction || 0) / 20).toFixed(1)
    }));

    // Calculate totals
    const totalCalls = calls.length;
    const completedCalls = calls.filter(call => call.status === 'completed').length;
    const droppedCalls = calls.filter(call => call.status === 'dropped').length;
    const avgDuration = completedCalls > 0 
      ? calls.filter(call => call.status === 'completed').reduce((sum, call) => sum + (call.duration || 0), 0) / completedCalls 
      : 0;

    // Call type distribution
    const callTypes = [
      { name: 'Inbound', value: calls.filter(call => call.call_type === 'inbound').length },
      { name: 'Outbound', value: calls.filter(call => call.call_type === 'outbound').length }
    ];

    // Status distribution
    const statusDistribution = [
      { name: 'Completed', value: completedCalls, color: '#10B981' },
      { name: 'Dropped', value: droppedCalls, color: '#EF4444' },
      { name: 'Active', value: calls.filter(call => call.status === 'active').length, color: '#3B82F6' }
    ];

    // Hourly distribution
    const hourlyData = Array.from({ length: 24 }, (_, hour) => ({
      hour: `${hour}:00`,
      calls: calls.filter(call => new Date(call.created_at).getHours() === hour).length
    }));

    return {
      summary: {
        totalCalls,
        completedCalls,
        droppedCalls,
        avgDuration,
        answerRate: totalCalls > 0 ? ((completedCalls / totalCalls) * 100).toFixed(1) : '0',
        avgSatisfaction: analytics.length > 0 
          ? (analytics.reduce((sum, day) => sum + (day.customer_satisfaction || 0), 0) / analytics.length / 20).toFixed(1)
          : '0'
      },
      dailyStats,
      callTypes,
      statusDistribution,
      hourlyData
    };
  };

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444'];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-center py-8 text-gray-500">Loading analytics...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h2>
        <div className="flex gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Total Calls</p>
                <p className="text-2xl font-bold">{analytics.summary?.totalCalls || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Answered</p>
                <p className="text-2xl font-bold">{analytics.summary?.completedCalls || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <TrendingDown className="h-4 w-4 text-red-600" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Dropped</p>
                <p className="text-2xl font-bold">{analytics.summary?.droppedCalls || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Clock className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Avg Duration</p>
                <p className="text-2xl font-bold">
                  {Math.floor((analytics.summary?.avgDuration || 0) / 60)}:
                  {Math.floor((analytics.summary?.avgDuration || 0) % 60).toString().padStart(2, '0')}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Answer Rate</p>
                <p className="text-2xl font-bold">{analytics.summary?.answerRate || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-600" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Satisfaction</p>
                <p className="text-2xl font-bold">{analytics.summary?.avgSatisfaction || 0}/5</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="distribution">Distribution</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Daily Call Volume</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.dailyStats || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="totalCalls" fill="#3B82F6" name="Total Calls" />
                    <Bar dataKey="answeredCalls" fill="#10B981" name="Answered" />
                    <Bar dataKey="droppedCalls" fill="#EF4444" name="Dropped" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Call Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.statusDistribution || []}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {(analytics.statusDistribution || []).map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Call Trends Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={analytics.dailyStats || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="totalCalls" stroke="#3B82F6" name="Total Calls" />
                  <Line type="monotone" dataKey="avgDuration" stroke="#10B981" name="Avg Duration (min)" />
                  <Line type="monotone" dataKey="satisfaction" stroke="#F59E0B" name="Satisfaction" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Hourly Call Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={analytics.hourlyData || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="calls" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Call Type Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.callTypes || []}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {(analytics.callTypes || []).map((entry: any, index: number) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Answer Rate</span>
                  <span className="text-lg font-bold">{analytics.summary?.answerRate || 0}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Average Handle Time</span>
                  <span className="text-lg font-bold">
                    {Math.floor((analytics.summary?.avgDuration || 0) / 60)}:
                    {Math.floor((analytics.summary?.avgDuration || 0) % 60).toString().padStart(2, '0')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Customer Satisfaction</span>
                  <span className="text-lg font-bold">{analytics.summary?.avgSatisfaction || 0}/5</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Call Quality</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Completed Calls</span>
                  <span className="text-lg font-bold text-green-600">{analytics.summary?.completedCalls || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Dropped Calls</span>
                  <span className="text-lg font-bold text-red-600">{analytics.summary?.droppedCalls || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Success Rate</span>
                  <span className="text-lg font-bold">
                    {analytics.summary?.totalCalls > 0 
                      ? ((analytics.summary.completedCalls / analytics.summary.totalCalls) * 100).toFixed(1)
                      : 0
                    }%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Efficiency</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Calls per Day</span>
                  <span className="text-lg font-bold">
                    {analytics.dailyStats?.length > 0 
                      ? Math.round(analytics.summary?.totalCalls / analytics.dailyStats.length)
                      : 0
                    }
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Peak Hour</span>
                  <span className="text-lg font-bold">
                    {analytics.hourlyData?.reduce((max: any, hour: any) => 
                      hour.calls > max.calls ? hour : max, { hour: 'N/A', calls: 0 }
                    )?.hour || 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm font-medium">Utilization</span>
                  <span className="text-lg font-bold">85%</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AnalyticsDashboard;
