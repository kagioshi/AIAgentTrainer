
import React, { useState } from 'react';
import { Brain, Cpu, Zap, Star, ChevronDown } from 'lucide-react';

const ModelSelector = () => {
  const [selectedModel, setSelectedModel] = useState('gemini-pro');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const models = [
    {
      id: 'gemini-pro',
      name: 'Gemini Pro',
      description: 'Advanced multimodal model for complex reasoning',
      type: 'Foundation',
      performance: 95,
      icon: Brain
    },
    {
      id: 'gemini-ultra',
      name: 'Gemini Ultra',
      description: 'Most capable model for highly complex tasks',
      type: 'Premium',
      performance: 98,
      icon: Star
    },
    {
      id: 'palm-2',
      name: 'PaLM 2',
      description: 'Large language model for text generation',
      type: 'Standard',
      performance: 88,
      icon: Cpu
    },
    {
      id: 'codey',
      name: 'Codey',
      description: 'Specialized model for code generation',
      type: 'Specialized',
      performance: 92,
      icon: Zap
    }
  ];

  const selectedModelData = models.find(m => m.id === selectedModel);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <h3 className="text-xl font-semibold text-white mb-4">Model Selection</h3>
      
      <div className="relative mb-6">
        <button
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-left text-white flex items-center justify-between hover:bg-white/20 transition-colors"
        >
          <div className="flex items-center gap-3">
            {selectedModelData && <selectedModelData.icon className="w-5 h-5" />}
            <span>{selectedModelData?.name}</span>
          </div>
          <ChevronDown className={`w-4 h-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
        </button>

        {isDropdownOpen && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white/20 backdrop-blur-lg border border-white/20 rounded-xl overflow-hidden z-10">
            {models.map((model) => {
              const Icon = model.icon;
              return (
                <button
                  key={model.id}
                  onClick={() => {
                    setSelectedModel(model.id);
                    setIsDropdownOpen(false);
                  }}
                  className="w-full px-4 py-3 text-left hover:bg-white/10 transition-colors border-b border-white/10 last:border-b-0"
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5 text-white" />
                    <div>
                      <div className="text-white font-medium">{model.name}</div>
                      <div className="text-gray-300 text-sm">{model.description}</div>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {selectedModelData && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-gray-300">Type</span>
            <span className="px-3 py-1 bg-purple-500/30 text-purple-200 rounded-full text-sm">
              {selectedModelData.type}
            </span>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-gray-300">Performance</span>
              <span className="text-white font-medium">{selectedModelData.performance}%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${selectedModelData.performance}%` }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelSelector;
