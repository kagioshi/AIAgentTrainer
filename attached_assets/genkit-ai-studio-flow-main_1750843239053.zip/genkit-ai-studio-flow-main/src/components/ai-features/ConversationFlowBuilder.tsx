
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, ArrowDown, MessageSquare, Brain, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ConversationFlowBuilder = () => {
  const [nodes, setNodes] = useState([
    {
      id: '1',
      type: 'greeting',
      title: 'Initial Greeting',
      content: 'Hello! Thank you for your interest in our services. How can I help you today?',
      responses: ['Product Info', 'Pricing', 'Support']
    }
  ]);
  const [selectedNode, setSelectedNode] = useState('1');
  const { toast } = useToast();

  const nodeTypes = [
    { id: 'greeting', label: 'Greeting', icon: MessageSquare, color: 'bg-blue-100 text-blue-800' },
    { id: 'question', label: 'Question', icon: MessageSquare, color: 'bg-green-100 text-green-800' },
    { id: 'response', label: 'Response', icon: Brain, color: 'bg-purple-100 text-purple-800' },
    { id: 'action', label: 'Action', icon: Settings, color: 'bg-orange-100 text-orange-800' }
  ];

  const addNode = (type: string) => {
    const newNode = {
      id: Date.now().toString(),
      type,
      title: `New ${type}`,
      content: '',
      responses: []
    };
    setNodes([...nodes, newNode]);
    setSelectedNode(newNode.id);
  };

  const updateNode = (id: string, field: string, value: any) => {
    setNodes(nodes.map(node => 
      node.id === id ? { ...node, [field]: value } : node
    ));
  };

  const deleteNode = (id: string) => {
    setNodes(nodes.filter(node => node.id !== id));
    if (selectedNode === id) {
      setSelectedNode(nodes[0]?.id || '');
    }
  };

  const selectedNodeData = nodes.find(node => node.id === selectedNode);

  return (
    <div className="grid lg:grid-cols-3 gap-6 h-full">
      {/* Flow Canvas */}
      <div className="lg:col-span-2">
        <Card className="h-full">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Conversation Flow</CardTitle>
              <div className="flex gap-2">
                {nodeTypes.map((type) => {
                  const Icon = type.icon;
                  return (
                    <Button
                      key={type.id}
                      variant="outline"
                      size="sm"
                      onClick={() => addNode(type.id)}
                      className="flex items-center gap-2"
                    >
                      <Icon className="w-4 h-4" />
                      {type.label}
                    </Button>
                  );
                })}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {nodes.map((node, index) => {
                const nodeType = nodeTypes.find(t => t.id === node.type);
                const Icon = nodeType?.icon || MessageSquare;
                
                return (
                  <div key={node.id} className="space-y-2">
                    <div
                      className={`border rounded-lg p-4 cursor-pointer transition-all ${
                        selectedNode === node.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedNode(node.id)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <Icon className="w-5 h-5 text-gray-600" />
                          <h3 className="font-medium">{node.title}</h3>
                          <Badge className={nodeType?.color}>
                            {nodeType?.label}
                          </Badge>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNode(node.id);
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{node.content}</p>
                      {node.responses.length > 0 && (
                        <div className="flex gap-2 flex-wrap">
                          {node.responses.map((response, idx) => (
                            <Badge key={idx} variant="outline" className="text-xs">
                              {response}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                    {index < nodes.length - 1 && (
                      <div className="flex justify-center">
                        <ArrowDown className="w-5 h-5 text-gray-400" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Node Editor */}
      <div>
        <Card className="h-full">
          <CardHeader>
            <CardTitle>Node Editor</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedNodeData ? (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={selectedNodeData.title}
                    onChange={(e) => updateNode(selectedNode, 'title', e.target.value)}
                    placeholder="Node title"
                  />
                </div>
                
                <div>
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    value={selectedNodeData.content}
                    onChange={(e) => updateNode(selectedNode, 'content', e.target.value)}
                    placeholder="What should the AI say?"
                    className="min-h-[100px]"
                  />
                </div>

                <div>
                  <Label>Expected Responses</Label>
                  <div className="space-y-2 mt-2">
                    {selectedNodeData.responses.map((response, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          value={response}
                          onChange={(e) => {
                            const newResponses = [...selectedNodeData.responses];
                            newResponses[index] = e.target.value;
                            updateNode(selectedNode, 'responses', newResponses);
                          }}
                          placeholder="Expected customer response"
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const newResponses = selectedNodeData.responses.filter((_, i) => i !== index);
                            updateNode(selectedNode, 'responses', newResponses);
                          }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        updateNode(selectedNode, 'responses', [...selectedNodeData.responses, '']);
                      }}
                      className="w-full"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add Response
                    </Button>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <Button
                    onClick={() => {
                      toast({
                        title: "Flow Saved",
                        description: "Conversation flow has been saved successfully"
                      });
                    }}
                    className="w-full"
                  >
                    Save Flow
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Select a node to edit its properties</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ConversationFlowBuilder;
