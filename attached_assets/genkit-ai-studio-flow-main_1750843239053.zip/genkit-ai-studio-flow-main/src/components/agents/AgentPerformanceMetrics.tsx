
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Clock, Phone, Star, Target } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface AgentMetrics {
  id: string;
  name: string;
  email: string;
  totalCalls: number;
  answeredCalls: number;
  avgHandleTime: number;
  customerSatisfaction: number;
  conversionRate: number;
  performanceScore: number;
  trend: 'up' | 'down' | 'stable';
}

const AgentPerformanceMetrics = () => {
  const [agents, setAgents] = useState<AgentMetrics[]>([]);
  const [timeRange, setTimeRange] = useState('today');
  const [sortBy, setSortBy] = useState('performanceScore');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAgentMetrics();
  }, [timeRange]);

  const fetchAgentMetrics = async () => {
    try {
      // Get date range
      const now = new Date();
      let startDate = new Date();
      
      switch (timeRange) {
        case 'today':
          startDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          startDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          startDate.setMonth(now.getMonth() - 1);
          break;
      }

      // Get agents
      const { data: businessUsers, error: agentsError } = await supabase
        .from('business_users')
        .select(`
          user_id,
          profiles (first_name, last_name, email)
        `)
        .eq('status', 'active');

      if (agentsError) throw agentsError;

      // Get call metrics for each agent
      const { data: calls, error: callsError } = await supabase
        .from('calls')
        .select('agent_id, status, duration, sentiment_score')
        .gte('created_at', startDate.toISOString())
        .not('agent_id', 'is', null);

      if (callsError) throw callsError;

      // Calculate metrics for each agent
      const agentMetrics: AgentMetrics[] = businessUsers?.map(bu => {
        const agentCalls = calls?.filter(call => call.agent_id === bu.user_id) || [];
        const totalCalls = agentCalls.length;
        const answeredCalls = agentCalls.filter(call => call.status === 'completed').length;
        const totalDuration = agentCalls.reduce((sum, call) => sum + (call.duration || 0), 0);
        const avgHandleTime = totalCalls > 0 ? Math.round(totalDuration / totalCalls) : 0;
        
        const sentimentScores = agentCalls
          .filter(call => call.sentiment_score !== null)
          .map(call => call.sentiment_score || 0);
        const customerSatisfaction = sentimentScores.length > 0 
          ? Math.round(sentimentScores.reduce((sum, score) => sum + score, 0) / sentimentScores.length * 50 + 50)
          : 0;

        const conversionRate = totalCalls > 0 ? Math.round((answeredCalls / totalCalls) * 100) : 0;
        
        // Calculate performance score (weighted average)
        const performanceScore = Math.round(
          (conversionRate * 0.3) + 
          (customerSatisfaction * 0.4) + 
          (Math.max(0, 100 - avgHandleTime / 10) * 0.3)
        );

        return {
          id: bu.user_id,
          name: bu.profiles?.first_name && bu.profiles?.last_name 
            ? `${bu.profiles.first_name} ${bu.profiles.last_name}`
            : bu.profiles?.email || 'Unknown',
          email: bu.profiles?.email || '',
          totalCalls,
          answeredCalls,
          avgHandleTime,
          customerSatisfaction: Math.max(0, Math.min(100, customerSatisfaction)),
          conversionRate,
          performanceScore: Math.max(0, Math.min(100, performanceScore)),
          trend: Math.random() > 0.5 ? 'up' : Math.random() > 0.5 ? 'down' : 'stable'
        };
      }) || [];

      // Sort agents
      const sortedAgents = [...agentMetrics].sort((a, b) => {
        switch (sortBy) {
          case 'totalCalls': return b.totalCalls - a.totalCalls;
          case 'customerSatisfaction': return b.customerSatisfaction - a.customerSatisfaction;
          case 'conversionRate': return b.conversionRate - a.conversionRate;
          default: return b.performanceScore - a.performanceScore;
        }
      });

      setAgents(sortedAgents);
    } catch (error) {
      console.error('Error fetching agent metrics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getPerformanceColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPerformanceBadge = (score: number) => {
    if (score >= 80) return <Badge className="bg-green-100 text-green-700">Excellent</Badge>;
    if (score >= 60) return <Badge className="bg-yellow-100 text-yellow-700">Good</Badge>;
    return <Badge className="bg-red-100 text-red-700">Needs Improvement</Badge>;
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down': return <TrendingDown className="w-4 h-4 text-red-600" />;
      default: return <div className="w-4 h-4" />;
    }
  };

  const chartData = agents.slice(0, 8).map(agent => ({
    name: agent.name.split(' ')[0],
    performance: agent.performanceScore,
    satisfaction: agent.customerSatisfaction,
    calls: agent.totalCalls
  }));

  if (isLoading) {
    return <div className="text-center py-8 text-gray-500">Loading performance metrics...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
            </SelectContent>
          </Select>
          
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="performanceScore">Performance Score</SelectItem>
              <SelectItem value="totalCalls">Total Calls</SelectItem>
              <SelectItem value="customerSatisfaction">Customer Satisfaction</SelectItem>
              <SelectItem value="conversionRate">Conversion Rate</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Performance Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="performance" fill="#3b82f6" name="Performance Score" />
                <Bar dataKey="satisfaction" fill="#10b981" name="Customer Satisfaction" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Performers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {agents.slice(0, 5).map((agent, index) => (
                <div key={agent.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <Avatar className="w-8 h-8">
                      <AvatarFallback className="text-xs">
                        {agent.name[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-sm">{agent.name}</div>
                      <div className="text-xs text-gray-500">{agent.totalCalls} calls</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className={`text-sm font-medium ${getPerformanceColor(agent.performanceScore)}`}>
                      {agent.performanceScore}%
                    </div>
                    {getTrendIcon(agent.trend)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Agent Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {agents.map((agent) => (
              <div key={agent.id} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarFallback>{agent.name[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{agent.name}</div>
                      <div className="text-sm text-gray-600">{agent.email}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {getPerformanceBadge(agent.performanceScore)}
                    {getTrendIcon(agent.trend)}
                  </div>
                </div>

                <div className="grid grid-cols-5 gap-4">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Phone className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium">Calls</span>
                    </div>
                    <div className="text-lg font-bold">{agent.totalCalls}</div>
                    <div className="text-xs text-gray-500">{agent.answeredCalls} answered</div>
                  </div>

                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Clock className="w-4 h-4 text-orange-600" />
                      <span className="text-sm font-medium">Handle Time</span>
                    </div>
                    <div className="text-lg font-bold">{agent.avgHandleTime}s</div>
                    <div className="text-xs text-gray-500">average</div>
                  </div>

                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Star className="w-4 h-4 text-yellow-600" />
                      <span className="text-sm font-medium">Satisfaction</span>
                    </div>
                    <div className="text-lg font-bold">{agent.customerSatisfaction}%</div>
                    <Progress value={agent.customerSatisfaction} className="h-1 mt-1" />
                  </div>

                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <Target className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium">Conversion</span>
                    </div>
                    <div className="text-lg font-bold">{agent.conversionRate}%</div>
                    <Progress value={agent.conversionRate} className="h-1 mt-1" />
                  </div>

                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <TrendingUp className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium">Performance</span>
                    </div>
                    <div className={`text-lg font-bold ${getPerformanceColor(agent.performanceScore)}`}>
                      {agent.performanceScore}%
                    </div>
                    <Progress value={agent.performanceScore} className="h-1 mt-1" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AgentPerformanceMetrics;
