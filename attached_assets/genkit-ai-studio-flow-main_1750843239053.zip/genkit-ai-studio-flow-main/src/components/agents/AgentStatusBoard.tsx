
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { UserCheck, UserX, Phone, Clock, MessageSquare } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface Agent {
  id: string;
  first_name: string | null;
  last_name: string | null;
  email: string;
  role: string;
  status: 'available' | 'busy' | 'break' | 'offline';
  current_call_id?: string;
  last_activity?: string;
  calls_today: number;
  avg_handle_time: number;
}

const AgentStatusBoard = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAgents();

    const channel = supabase
      .channel('agent-status-board')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'business_users'
      }, () => {
        fetchAgents();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchAgents = async () => {
    try {
      const { data: businessUsers, error } = await supabase
        .from('business_users')
        .select(`
          user_id,
          role,
          status,
          profiles (id, first_name, last_name, email)
        `)
        .eq('status', 'active');

      if (error) throw error;

      // Get active calls for each agent
      const { data: activeCalls } = await supabase
        .from('calls')
        .select('agent_id')
        .eq('status', 'active');

      const busyAgentIds = new Set(activeCalls?.map(call => call.agent_id).filter(Boolean));

      // Get today's call stats
      const today = new Date().toISOString().split('T')[0];
      const { data: todayCalls } = await supabase
        .from('calls')
        .select('agent_id, duration')
        .gte('created_at', today + 'T00:00:00.000Z')
        .eq('status', 'completed');

      const callStats = todayCalls?.reduce((acc, call) => {
        if (call.agent_id) {
          if (!acc[call.agent_id]) {
            acc[call.agent_id] = { count: 0, totalDuration: 0 };
          }
          acc[call.agent_id].count++;
          acc[call.agent_id].totalDuration += call.duration || 0;
        }
        return acc;
      }, {} as Record<string, { count: number; totalDuration: number }>) || {};

      const agentData: Agent[] = businessUsers?.map(bu => {
        const stats = callStats[bu.user_id] || { count: 0, totalDuration: 0 };
        return {
          id: bu.user_id,
          first_name: bu.profiles?.first_name || null,
          last_name: bu.profiles?.last_name || null,
          email: bu.profiles?.email || '',
          role: bu.role || 'agent',
          status: busyAgentIds.has(bu.user_id) ? 'busy' : 'available',
          calls_today: stats.count,
          avg_handle_time: stats.count > 0 ? Math.round(stats.totalDuration / stats.count) : 0
        };
      }) || [];

      setAgents(agentData);
    } catch (error) {
      console.error('Error fetching agents:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return <UserCheck className="w-4 h-4 text-green-600" />;
      case 'busy': return <Phone className="w-4 h-4 text-orange-600" />;
      case 'break': return <Clock className="w-4 h-4 text-blue-600" />;
      case 'offline': return <UserX className="w-4 h-4 text-red-600" />;
      default: return <UserX className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      available: 'bg-green-100 text-green-700',
      busy: 'bg-orange-100 text-orange-700',
      break: 'bg-blue-100 text-blue-700',
      offline: 'bg-red-100 text-red-700'
    };
    
    return (
      <Badge className={variants[status as keyof typeof variants] || 'bg-gray-100 text-gray-700'}>
        {status}
      </Badge>
    );
  };

  const statusCounts = agents.reduce((acc, agent) => {
    acc[agent.status] = (acc[agent.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (isLoading) {
    return (
      <div className="text-center py-8 text-gray-500">Loading agents...</div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{statusCounts.available || 0}</div>
            <div className="text-sm text-gray-600">Available</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{statusCounts.busy || 0}</div>
            <div className="text-sm text-gray-600">Busy</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{statusCounts.break || 0}</div>
            <div className="text-sm text-gray-600">On Break</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{statusCounts.offline || 0}</div>
            <div className="text-sm text-gray-600">Offline</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Agent Status Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {agents.map((agent) => (
              <div 
                key={agent.id}
                className="flex items-center justify-between p-4 rounded-lg border hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>
                      {agent.first_name?.[0] || agent.email[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div>
                    <div className="font-medium">
                      {agent.first_name && agent.last_name 
                        ? `${agent.first_name} ${agent.last_name}`
                        : agent.email
                      }
                    </div>
                    <div className="text-sm text-gray-600 capitalize">
                      {agent.role}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-sm font-medium">{agent.calls_today}</div>
                    <div className="text-xs text-gray-500">Calls Today</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="text-sm font-medium">{agent.avg_handle_time}s</div>
                    <div className="text-xs text-gray-500">Avg Handle Time</div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {getStatusIcon(agent.status)}
                    {getStatusBadge(agent.status)}
                  </div>
                  
                  <Button variant="outline" size="sm">
                    <MessageSquare className="w-4 h-4 mr-1" />
                    Message
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AgentStatusBoard;
