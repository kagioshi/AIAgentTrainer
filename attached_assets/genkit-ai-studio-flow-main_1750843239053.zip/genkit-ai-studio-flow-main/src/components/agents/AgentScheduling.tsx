
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, Clock, Plus, Edit, Trash2 } from 'lucide-react';

interface Schedule {
  id: string;
  agentId: string;
  agentName: string;
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  shiftType: 'regular' | 'overtime' | 'on-call';
  status: 'scheduled' | 'confirmed' | 'requested-off';
}

interface Agent {
  id: string;
  name: string;
  role: string;
}

const AgentScheduling = () => {
  const [schedules, setSchedules] = useState<Schedule[]>([
    {
      id: '1',
      agentId: 'agent1',
      agentName: 'John Smith',
      dayOfWeek: 'Monday',
      startTime: '09:00',
      endTime: '17:00',
      shiftType: 'regular',
      status: 'confirmed'
    },
    {
      id: '2',
      agentId: 'agent1',
      agentName: 'John Smith',
      dayOfWeek: 'Tuesday',
      startTime: '09:00',
      endTime: '17:00',
      shiftType: 'regular',
      status: 'scheduled'
    },
    {
      id: '3',
      agentId: 'agent2',
      agentName: 'Sarah Johnson',
      dayOfWeek: 'Monday',
      startTime: '13:00',
      endTime: '21:00',
      shiftType: 'regular',
      status: 'confirmed'
    }
  ]);

  const [agents] = useState<Agent[]>([
    { id: 'agent1', name: 'John Smith', role: 'Senior Agent' },
    { id: 'agent2', name: 'Sarah Johnson', role: 'Agent' },
    { id: 'agent3', name: 'Mike Wilson', role: 'Agent' }
  ]);

  const [selectedWeek, setSelectedWeek] = useState('current');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    agentId: '',
    dayOfWeek: '',
    startTime: '',
    endTime: '',
    shiftType: 'regular' as const
  });

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  const getShiftTypeBadge = (type: string) => {
    const variants = {
      regular: 'bg-blue-100 text-blue-700',
      overtime: 'bg-orange-100 text-orange-700',
      'on-call': 'bg-purple-100 text-purple-700'
    };
    return <Badge className={variants[type as keyof typeof variants]}>{type}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      scheduled: 'bg-yellow-100 text-yellow-700',
      confirmed: 'bg-green-100 text-green-700',
      'requested-off': 'bg-red-100 text-red-700'
    };
    return <Badge className={variants[status as keyof typeof variants]}>{status.replace('-', ' ')}</Badge>;
  };

  const handleAddSchedule = () => {
    if (newSchedule.agentId && newSchedule.dayOfWeek && newSchedule.startTime && newSchedule.endTime) {
      const agent = agents.find(a => a.id === newSchedule.agentId);
      const schedule: Schedule = {
        id: Date.now().toString(),
        agentId: newSchedule.agentId,
        agentName: agent?.name || '',
        dayOfWeek: newSchedule.dayOfWeek,
        startTime: newSchedule.startTime,
        endTime: newSchedule.endTime,
        shiftType: newSchedule.shiftType,
        status: 'scheduled'
      };
      
      setSchedules([...schedules, schedule]);
      setNewSchedule({
        agentId: '',
        dayOfWeek: '',
        startTime: '',
        endTime: '',
        shiftType: 'regular'
      });
      setShowAddForm(false);
    }
  };

  const handleDeleteSchedule = (id: string) => {
    setSchedules(schedules.filter(s => s.id !== id));
  };

  const getScheduleByDayAndAgent = (day: string, agentId: string) => {
    return schedules.find(s => s.dayOfWeek === day && s.agentId === agentId);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Select value={selectedWeek} onValueChange={setSelectedWeek}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Current Week</SelectItem>
              <SelectItem value="next">Next Week</SelectItem>
              <SelectItem value="previous">Previous Week</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <Button onClick={() => setShowAddForm(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Schedule
        </Button>
      </div>

      {showAddForm && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Agent</Label>
                <Select value={newSchedule.agentId} onValueChange={(value) => 
                  setNewSchedule({...newSchedule, agentId: value})
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select agent" />
                  </SelectTrigger>
                  <SelectContent>
                    {agents.map(agent => (
                      <SelectItem key={agent.id} value={agent.id}>
                        {agent.name} - {agent.role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Day of Week</Label>
                <Select value={newSchedule.dayOfWeek} onValueChange={(value) => 
                  setNewSchedule({...newSchedule, dayOfWeek: value})
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Select day" />
                  </SelectTrigger>
                  <SelectContent>
                    {daysOfWeek.map(day => (
                      <SelectItem key={day} value={day}>{day}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Start Time</Label>
                <Input
                  type="time"
                  value={newSchedule.startTime}
                  onChange={(e) => setNewSchedule({...newSchedule, startTime: e.target.value})}
                />
              </div>

              <div>
                <Label>End Time</Label>
                <Input
                  type="time"
                  value={newSchedule.endTime}
                  onChange={(e) => setNewSchedule({...newSchedule, endTime: e.target.value})}
                />
              </div>

              <div>
                <Label>Shift Type</Label>
                <Select value={newSchedule.shiftType} onValueChange={(value: any) => 
                  setNewSchedule({...newSchedule, shiftType: value})
                }>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="regular">Regular</SelectItem>
                    <SelectItem value="overtime">Overtime</SelectItem>
                    <SelectItem value="on-call">On-Call</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2 mt-4">
              <Button onClick={handleAddSchedule}>Add Schedule</Button>
              <Button variant="outline" onClick={() => setShowAddForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Weekly Schedule
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="text-left p-3 border-b font-medium">Agent</th>
                  {daysOfWeek.map(day => (
                    <th key={day} className="text-center p-3 border-b font-medium min-w-32">
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {agents.map(agent => (
                  <tr key={agent.id} className="border-b">
                    <td className="p-3">
                      <div>
                        <div className="font-medium">{agent.name}</div>
                        <div className="text-sm text-gray-600">{agent.role}</div>
                      </div>
                    </td>
                    {daysOfWeek.map(day => {
                      const schedule = getScheduleByDayAndAgent(day, agent.id);
                      return (
                        <td key={day} className="p-2 text-center">
                          {schedule ? (
                            <div className="space-y-1">
                              <div className="text-sm font-medium flex items-center justify-center gap-1">
                                <Clock className="w-3 h-3" />
                                {schedule.startTime} - {schedule.endTime}
                              </div>
                              <div className="flex flex-col gap-1">
                                {getShiftTypeBadge(schedule.shiftType)}
                                {getStatusBadge(schedule.status)}
                              </div>
                              <div className="flex justify-center gap-1 mt-1">
                                <Button variant="ghost" size="sm">
                                  <Edit className="w-3 h-3" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleDeleteSchedule(schedule.id)}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          ) : (
                            <div className="text-gray-400 text-sm">Not scheduled</div>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">
              {schedules.filter(s => s.status === 'confirmed').length}
            </div>
            <div className="text-sm text-gray-600">Confirmed Shifts</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">
              {schedules.filter(s => s.status === 'scheduled').length}
            </div>
            <div className="text-sm text-gray-600">Pending Confirmation</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">
              {schedules.filter(s => s.status === 'requested-off').length}
            </div>
            <div className="text-sm text-gray-600">Time Off Requests</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AgentScheduling;
