
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Activity, Clock, Award } from 'lucide-react';
import AgentStatusBoard from './AgentStatusBoard';
import AgentPerformanceMetrics from './AgentPerformanceMetrics';
import AgentScheduling from './AgentScheduling';
import AgentConfiguration from './AgentConfiguration';

const AgentManagementDashboard = () => {
  const [activeTab, setActiveTab] = useState('status');

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Agent Management</h1>
        <p className="text-gray-600">Manage your contact center agents and monitor performance</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="status" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Agent Status
          </TabsTrigger>
          <TabsTrigger value="performance" className="flex items-center gap-2">
            <Activity className="w-4 h-4" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="scheduling" className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Scheduling
          </TabsTrigger>
          <TabsTrigger value="configuration" className="flex items-center gap-2">
            <Award className="w-4 h-4" />
            Configuration
          </TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="space-y-6">
          <AgentStatusBoard />
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <AgentPerformanceMetrics />
        </TabsContent>

        <TabsContent value="scheduling" className="space-y-6">
          <AgentScheduling />
        </TabsContent>

        <TabsContent value="configuration" className="space-y-6">
          <AgentConfiguration />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AgentManagementDashboard;
