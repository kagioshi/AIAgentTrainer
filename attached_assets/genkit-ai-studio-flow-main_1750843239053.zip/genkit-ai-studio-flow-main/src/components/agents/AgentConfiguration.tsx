
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Settings, Shield, Headphones, MessageSquare, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface AgentConfig {
  id: string;
  name: string;
  email: string;
  role: string;
  permissions: {
    canManageCalls: boolean;
    canViewAnalytics: boolean;
    canManageCustomers: boolean;
    canAccessSettings: boolean;
  };
  voiceSettings: {
    autoAnswer: boolean;
    recordCalls: boolean;
    transcribeRealtime: boolean;
    voiceModel: string;
    language: string;
  };
  notifications: {
    emailAlerts: boolean;
    smsAlerts: boolean;
    desktopNotifications: boolean;
    escalationAlerts: boolean;
  };
  workingHours: {
    timezone: string;
    startTime: string;
    endTime: string;
    workingDays: string[];
  };
}

const AgentConfiguration = () => {
  const [agents, setAgents] = useState<AgentConfig[]>([
    {
      id: 'agent1',
      name: 'John Smith',
      email: 'john.smith@company.com',
      role: 'senior_agent',
      permissions: {
        canManageCalls: true,
        canViewAnalytics: true,
        canManageCustomers: true,
        canAccessSettings: false
      },
      voiceSettings: {
        autoAnswer: false,
        recordCalls: true,
        transcribeRealtime: true,
        voiceModel: 'standard',
        language: 'en-US'
      },
      notifications: {
        emailAlerts: true,
        smsAlerts: false,
        desktopNotifications: true,
        escalationAlerts: true
      },
      workingHours: {
        timezone: 'America/New_York',
        startTime: '09:00',
        endTime: '17:00',
        workingDays: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
      }
    }
  ]);

  const [selectedAgent, setSelectedAgent] = useState<string>('agent1');
  const { toast } = useToast();

  const currentAgent = agents.find(a => a.id === selectedAgent);

  const updateAgentConfig = (updates: Partial<AgentConfig>) => {
    setAgents(prev => prev.map(agent => 
      agent.id === selectedAgent 
        ? { ...agent, ...updates }
        : agent
    ));
  };

  const updatePermissions = (permission: keyof AgentConfig['permissions'], value: boolean) => {
    if (!currentAgent) return;
    
    updateAgentConfig({
      permissions: {
        ...currentAgent.permissions,
        [permission]: value
      }
    });
  };

  const updateVoiceSettings = (setting: keyof AgentConfig['voiceSettings'], value: any) => {
    if (!currentAgent) return;
    
    updateAgentConfig({
      voiceSettings: {
        ...currentAgent.voiceSettings,
        [setting]: value
      }
    });
  };

  const updateNotifications = (setting: keyof AgentConfig['notifications'], value: boolean) => {
    if (!currentAgent) return;
    
    updateAgentConfig({
      notifications: {
        ...currentAgent.notifications,
        [setting]: value
      }
    });
  };

  const updateWorkingHours = (setting: keyof AgentConfig['workingHours'], value: any) => {
    if (!currentAgent) return;
    
    updateAgentConfig({
      workingHours: {
        ...currentAgent.workingHours,
        [setting]: value
      }
    });
  };

  const handleSaveConfig = () => {
    toast({
      title: "Configuration Saved",
      description: `Settings for ${currentAgent?.name} have been updated successfully.`
    });
  };

  const getRoleBadge = (role: string) => {
    const variants = {
      admin: 'bg-purple-100 text-purple-700',
      supervisor: 'bg-blue-100 text-blue-700',
      senior_agent: 'bg-green-100 text-green-700',
      agent: 'bg-gray-100 text-gray-700'
    };
    
    return (
      <Badge className={variants[role as keyof typeof variants] || variants.agent}>
        {role.replace('_', ' ').toUpperCase()}
      </Badge>
    );
  };

  if (!currentAgent) {
    return <div className="text-center py-8 text-gray-500">Agent not found</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Select value={selectedAgent} onValueChange={setSelectedAgent}>
            <SelectTrigger className="w-64">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {agents.map(agent => (
                <SelectItem key={agent.id} value={agent.id}>
                  {agent.name} - {agent.email}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <Button onClick={handleSaveConfig} className="flex items-center gap-2">
          <Save className="w-4 h-4" />
          Save Configuration
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Avatar>
              <AvatarFallback>{currentAgent.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-semibold">{currentAgent.name}</div>
              <div className="text-sm text-gray-600">{currentAgent.email}</div>
            </div>
            {getRoleBadge(currentAgent.role)}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <Label>Role</Label>
              <Select 
                value={currentAgent.role} 
                onValueChange={(value) => updateAgentConfig({ role: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="agent">Agent</SelectItem>
                  <SelectItem value="senior_agent">Senior Agent</SelectItem>
                  <SelectItem value="supervisor">Supervisor</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Permissions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Call Management</Label>
                <p className="text-sm text-gray-600">Allow agent to manage and transfer calls</p>
              </div>
              <Switch
                checked={currentAgent.permissions.canManageCalls}
                onCheckedChange={(checked) => updatePermissions('canManageCalls', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>View Analytics</Label>
                <p className="text-sm text-gray-600">Access to performance analytics and reports</p>
              </div>
              <Switch
                checked={currentAgent.permissions.canViewAnalytics}
                onCheckedChange={(checked) => updatePermissions('canViewAnalytics', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Customer Management</Label>
                <p className="text-sm text-gray-600">Create and edit customer information</p>
              </div>
              <Switch
                checked={currentAgent.permissions.canManageCustomers}
                onCheckedChange={(checked) => updatePermissions('canManageCustomers', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Settings Access</Label>
                <p className="text-sm text-gray-600">Access to system settings and configuration</p>
              </div>
              <Switch
                checked={currentAgent.permissions.canAccessSettings}
                onCheckedChange={(checked) => updatePermissions('canAccessSettings', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Headphones className="w-5 h-5" />
            Voice Settings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Voice Model</Label>
                <Select 
                  value={currentAgent.voiceSettings.voiceModel} 
                  onValueChange={(value) => updateVoiceSettings('voiceModel', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="neural">Neural</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Language</Label>
                <Select 
                  value={currentAgent.voiceSettings.language} 
                  onValueChange={(value) => updateVoiceSettings('language', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en-US">English (US)</SelectItem>
                    <SelectItem value="en-GB">English (UK)</SelectItem>
                    <SelectItem value="es-ES">Spanish</SelectItem>
                    <SelectItem value="fr-FR">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Auto Answer Calls</Label>
                <Switch
                  checked={currentAgent.voiceSettings.autoAnswer}
                  onCheckedChange={(checked) => updateVoiceSettings('autoAnswer', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Record Calls</Label>
                <Switch
                  checked={currentAgent.voiceSettings.recordCalls}
                  onCheckedChange={(checked) => updateVoiceSettings('recordCalls', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label>Real-time Transcription</Label>
                <Switch
                  checked={currentAgent.voiceSettings.transcribeRealtime}
                  onCheckedChange={(checked) => updateVoiceSettings('transcribeRealtime', checked)}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Email Alerts</Label>
                <p className="text-sm text-gray-600">Receive email notifications for important events</p>
              </div>
              <Switch
                checked={currentAgent.notifications.emailAlerts}
                onCheckedChange={(checked) => updateNotifications('emailAlerts', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>SMS Alerts</Label>
                <p className="text-sm text-gray-600">Receive SMS notifications for urgent matters</p>
              </div>
              <Switch
                checked={currentAgent.notifications.smsAlerts}
                onCheckedChange={(checked) => updateNotifications('smsAlerts', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Desktop Notifications</Label>
                <p className="text-sm text-gray-600">Show browser notifications</p>
              </div>
              <Switch
                checked={currentAgent.notifications.desktopNotifications}
                onCheckedChange={(checked) => updateNotifications('desktopNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label>Escalation Alerts</Label>
                <p className="text-sm text-gray-600">Notifications for call escalations</p>
              </div>
              <Switch
                checked={currentAgent.notifications.escalationAlerts}
                onCheckedChange={(checked) => updateNotifications('escalationAlerts', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Working Hours
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <Label>Timezone</Label>
                <Select 
                  value={currentAgent.workingHours.timezone} 
                  onValueChange={(value) => updateWorkingHours('timezone', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="America/New_York">Eastern Time</SelectItem>
                    <SelectItem value="America/Chicago">Central Time</SelectItem>
                    <SelectItem value="America/Denver">Mountain Time</SelectItem>
                    <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Start Time</Label>
                <Input
                  type="time"
                  value={currentAgent.workingHours.startTime}
                  onChange={(e) => updateWorkingHours('startTime', e.target.value)}
                />
              </div>

              <div>
                <Label>End Time</Label>
                <Input
                  type="time"
                  value={currentAgent.workingHours.endTime}
                  onChange={(e) => updateWorkingHours('endTime', e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label>Working Days</Label>
              <div className="grid grid-cols-7 gap-2 mt-2">
                {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => (
                  <Button
                    key={day}
                    variant={currentAgent.workingHours.workingDays.includes(day) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => {
                      const workingDays = currentAgent.workingHours.workingDays.includes(day)
                        ? currentAgent.workingHours.workingDays.filter(d => d !== day)
                        : [...currentAgent.workingHours.workingDays, day];
                      updateWorkingHours('workingDays', workingDays);
                    }}
                  >
                    {day.slice(0, 3)}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AgentConfiguration;
