
import React from 'react';
import { Clock, Users, ArrowUp, ArrowDown, Phone } from 'lucide-react';

interface QueuedCall {
  id: string;
  customerName: string;
  phoneNumber: string;
  waitTime: string;
  priority: 'low' | 'medium' | 'high';
  reason: string;
  estimatedHandleTime: string;
}

const QueueManagement = () => {
  const queuedCalls: QueuedCall[] = [
    {
      id: 'Q001',
      customerName: 'Jennifer Adams',
      phoneNumber: '+1 (555) 111-2222',
      waitTime: '2:15',
      priority: 'high',
      reason: 'Billing Issue',
      estimatedHandleTime: '5:00'
    },
    {
      id: 'Q002',
      customerName: 'Robert Kim',
      phoneNumber: '+1 (555) 333-4444',
      waitTime: '1:45',
      priority: 'medium',
      reason: 'Technical Support',
      estimatedHandleTime: '7:00'
    },
    {
      id: 'Q003',
      customerName: 'Emily Davis',
      phoneNumber: '+1 (555) 555-6666',
      waitTime: '0:45',
      priority: 'low',
      reason: 'General Inquiry',
      estimatedHandleTime: '3:00'
    },
    {
      id: 'Q004',
      customerName: 'Michael Turner',
      phoneNumber: '+1 (555) 777-8888',
      waitTime: '3:30',
      priority: 'high',
      reason: 'Account Access',
      estimatedHandleTime: '4:00'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-red-500 bg-red-500/10';
      case 'medium': return 'border-l-yellow-500 bg-yellow-500/10';
      case 'low': return 'border-l-green-500 bg-green-500/10';
      default: return 'border-l-gray-500 bg-gray-500/10';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return <ArrowUp className="w-4 h-4 text-red-400" />;
      case 'medium': return <ArrowUp className="w-4 h-4 text-yellow-400 rotate-45" />;
      case 'low': return <ArrowDown className="w-4 h-4 text-green-400" />;
      default: return null;
    }
  };

  const avgWaitTime = '2:05';
  const totalInQueue = queuedCalls.length;
  const highPriorityCount = queuedCalls.filter(call => call.priority === 'high').length;

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <Users className="w-5 h-5" />
          Call Queue
        </h3>
        <div className="flex items-center gap-4 text-sm text-gray-300">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            Avg Wait: {avgWaitTime}
          </div>
          <div>Queue: {totalInQueue}</div>
        </div>
      </div>

      {/* Queue Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-white">{totalInQueue}</div>
          <div className="text-gray-400 text-sm">In Queue</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-red-400">{highPriorityCount}</div>
          <div className="text-gray-400 text-sm">High Priority</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-2xl font-bold text-cyan-400">{avgWaitTime}</div>
          <div className="text-gray-400 text-sm">Avg Wait</div>
        </div>
      </div>

      {/* Queue List */}
      <div className="space-y-3 max-h-64 overflow-y-auto">
        {queuedCalls.map((call, index) => (
          <div 
            key={call.id} 
            className={`rounded-lg p-4 border-l-4 ${getPriorityColor(call.priority)} hover:bg-white/5 transition-colors`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="text-gray-400 text-sm font-mono">#{index + 1}</div>
                {getPriorityIcon(call.priority)}
                <div>
                  <div className="text-white font-medium">{call.customerName}</div>
                  <div className="text-gray-400 text-sm">{call.reason}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white text-sm font-mono">Wait: {call.waitTime}</div>
                <div className="text-gray-400 text-xs">ETA: {call.estimatedHandleTime}</div>
              </div>
            </div>

            <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/10">
              <div className="text-gray-400 text-sm">{call.phoneNumber}</div>
              <div className="flex gap-2">
                <button className="px-3 py-1 bg-yellow-600 hover:bg-yellow-700 text-white text-xs rounded transition-colors">
                  Priority Up
                </button>
                <button className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-xs rounded transition-colors flex items-center gap-1">
                  <Phone className="w-3 h-3" />
                  Connect
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Queue Controls */}
      <div className="flex gap-3 mt-6 pt-6 border-t border-white/20">
        <button className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
          Auto-Route Next
        </button>
        <button className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg transition-colors">
          Broadcast Message
        </button>
      </div>
    </div>
  );
};

export default QueueManagement;
