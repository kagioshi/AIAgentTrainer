
import React from 'react';
import { TrendingUp, Target, Clock, Star, AlertTriangle } from 'lucide-react';

const PerformanceMetrics = () => {
  const metrics = [
    {
      label: 'Service Level (20s)',
      current: 89.5,
      target: 90,
      trend: -2.1,
      status: 'warning',
      icon: Target
    },
    {
      label: 'First Call Resolution',
      current: 78.2,
      target: 75,
      trend: +3.4,
      status: 'good',
      icon: Star
    },
    {
      label: 'Average Speed to Answer',
      current: 18,
      target: 20,
      trend: -2,
      status: 'good',
      icon: Clock
    },
    {
      label: 'Abandonment Rate',
      current: 4.2,
      target: 5,
      trend: +0.8,
      status: 'warning',
      icon: AlertTriangle
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'good': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getProgressColor = (current: number, target: number, isInverse = false) => {
    const ratio = isInverse ? target / current : current / target;
    if (ratio >= 1) return 'bg-green-500';
    if (ratio >= 0.9) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getTrendIcon = (trend: number) => {
    if (trend > 0) return '↗';
    if (trend < 0) return '↘';
    return '→';
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Performance SLA
        </h3>
        <div className="text-sm text-gray-300">Last updated: 2 min ago</div>
      </div>

      <div className="space-y-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          const isInverse = metric.label.includes('Abandonment');
          const progressWidth = isInverse 
            ? Math.min((metric.target / metric.current) * 100, 100)
            : Math.min((metric.current / metric.target) * 100, 100);

          return (
            <div key={index} className="bg-white/5 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                    <Icon className={`w-5 h-5 ${getStatusColor(metric.status)}`} />
                  </div>
                  <div>
                    <div className="text-white font-medium">{metric.label}</div>
                    <div className="text-gray-400 text-sm">
                      Target: {metric.target}{metric.label.includes('Time') ? 's' : '%'}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white text-xl font-bold">
                    {metric.current}{metric.label.includes('Speed') ? 's' : '%'}
                  </div>
                  <div className={`text-sm flex items-center gap-1 ${
                    metric.trend > 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    <span>{getTrendIcon(metric.trend)}</span>
                    <span>{Math.abs(metric.trend)}{metric.label.includes('Speed') ? 's' : '%'}</span>
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-white/10 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all duration-300 ${getProgressColor(metric.current, metric.target, isInverse)}`}
                  style={{ width: `${progressWidth}%` }}
                ></div>
              </div>

              {/* Status Indicator */}
              <div className="flex justify-between items-center mt-2">
                <span className={`text-xs px-2 py-1 rounded-full ${
                  metric.status === 'good' ? 'bg-green-500/20 text-green-400' :
                  metric.status === 'warning' ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {metric.status === 'good' ? 'On Target' : 
                   metric.status === 'warning' ? 'Needs Attention' : 'Critical'}
                </span>
                <span className="text-xs text-gray-400">
                  {progressWidth.toFixed(1)}% of target
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Overall Score */}
      <div className="mt-6 pt-6 border-t border-white/20">
        <div className="flex items-center justify-between">
          <span className="text-white font-medium">Overall SLA Score</span>
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold text-yellow-400">87.2%</div>
            <div className="text-sm text-yellow-400">↘ 1.3%</div>
          </div>
        </div>
        <div className="w-full bg-white/10 rounded-full h-3 mt-2">
          <div className="bg-yellow-500 h-3 rounded-full" style={{ width: '87.2%' }}></div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceMetrics;
