
import React from 'react';
import { Server, Database, Wifi, Cpu, HardDrive, Activity } from 'lucide-react';

const SystemHealth = () => {
  const systemComponents = [
    {
      name: 'Web Server',
      status: 'healthy',
      uptime: 99.9,
      responseTime: '45ms',
      icon: Server,
      details: 'All services operational'
    },
    {
      name: 'Database',
      status: 'healthy',
      uptime: 99.8,
      responseTime: '12ms',
      icon: Database,
      details: 'Query performance optimal'
    },
    {
      name: 'Network',
      status: 'warning',
      uptime: 98.5,
      responseTime: '89ms',
      icon: Wifi,
      details: 'Intermittent latency spikes'
    },
    {
      name: 'CPU Usage',
      status: 'healthy',
      uptime: 100,
      responseTime: '68%',
      icon: Cpu,
      details: 'Normal load distribution'
    }
  ];

  const infrastructureMetrics = {
    totalRequests: 456789,
    errorRate: 0.02,
    avgResponseTime: '120ms',
    peakConcurrentUsers: 234
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-500/20';
      case 'warning': return 'bg-yellow-500/20';
      case 'critical': return 'bg-red-500/20';
      default: return 'bg-gray-500/20';
    }
  };

  const getHealthBar = (uptime: number) => {
    if (uptime >= 99.5) return 'bg-green-500';
    if (uptime >= 95) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <Activity className="w-5 h-5" />
          System Health
        </h3>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">All Systems Operational</span>
        </div>
      </div>

      {/* Infrastructure Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-white font-bold">{infrastructureMetrics.totalRequests.toLocaleString()}</div>
          <div className="text-gray-400 text-xs">Total Requests</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-green-400 font-bold">{infrastructureMetrics.errorRate}%</div>
          <div className="text-gray-400 text-xs">Error Rate</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-blue-400 font-bold">{infrastructureMetrics.avgResponseTime}</div>
          <div className="text-gray-400 text-xs">Avg Response</div>
        </div>
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="text-purple-400 font-bold">{infrastructureMetrics.peakConcurrentUsers}</div>
          <div className="text-gray-400 text-xs">Peak Users</div>
        </div>
      </div>

      {/* Component Status */}
      <div className="space-y-4">
        <h4 className="text-lg font-medium text-white">Component Status</h4>
        {systemComponents.map((component, index) => {
          const Icon = component.icon;
          return (
            <div key={index} className="bg-white/5 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusBg(component.status)}`}>
                    <Icon className={`w-5 h-5 ${getStatusColor(component.status)}`} />
                  </div>
                  <div>
                    <div className="text-white font-medium">{component.name}</div>
                    <div className="text-gray-400 text-sm">{component.details}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium capitalize ${getStatusColor(component.status)}`}>
                    {component.status}
                  </div>
                  <div className="text-gray-400 text-xs">{component.responseTime}</div>
                </div>
              </div>

              {/* Uptime Bar */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-gray-400 text-sm">Uptime</span>
                <span className="text-white text-sm">{component.uptime}%</span>
              </div>
              <div className="w-full bg-white/10 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${getHealthBar(component.uptime)}`}
                  style={{ width: `${component.uptime}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Resource Usage */}
      <div className="mt-6 pt-6 border-t border-white/20">
        <h4 className="text-lg font-medium text-white mb-4">Resource Usage</h4>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/5 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-blue-400" />
                <span className="text-gray-300 text-sm">CPU</span>
              </div>
              <span className="text-white text-sm">68%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full" style={{ width: '68%' }}></div>
            </div>
          </div>

          <div className="bg-white/5 rounded-lg p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-purple-400" />
                <span className="text-gray-300 text-sm">Memory</span>
              </div>
              <span className="text-white text-sm">42%</span>
            </div>
            <div className="w-full bg-white/10 rounded-full h-2">
              <div className="bg-purple-500 h-2 rounded-full" style={{ width: '42%' }}></div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-3 mt-6">
        <button className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
          View Logs
        </button>
        <button className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors">
          Run Diagnostics
        </button>
      </div>
    </div>
  );
};

export default SystemHealth;
