
import React from 'react';
import { Phone } from 'lucide-react';

interface CallHeaderProps {
  isInCall: boolean;
  callDuration: number;
  formatDuration: (seconds: number) => string;
}

const CallHeader = ({ isInCall, callDuration, formatDuration }: CallHeaderProps) => {
  return (
    <h3 className="text-xl font-semibold text-white mb-4 flex items-center justify-between">
      <span className="flex items-center gap-2">
        {isInCall ? <Phone className="w-5 h-5 text-green-400 animate-pulse" /> : <Phone className="w-5 h-5" />}
        Voice AI Agent
      </span>
      {isInCall && (
        <span className="text-sm font-mono bg-white/10 px-3 py-1 rounded-full">
          {formatDuration(callDuration)}
        </span>
      )}
    </h3>
  );
};

export default CallHeader;
