
import React, { useState } from 'react';
import { Send, Phone, PhoneOff } from 'lucide-react';

interface MessageInputProps {
  isStreaming: boolean;
  isInCall: boolean;
  onSendMessage: (message: string) => void;
  onStartCall: () => void;
  onEndCall: () => void;
}

const MessageInput = ({ 
  isStreaming, 
  isInCall, 
  onSendMessage, 
  onStartCall, 
  onEndCall 
}: MessageInputProps) => {
  const [message, setMessage] = useState('');

  const handleSendMessage = () => {
    if (message.trim() && !isStreaming) {
      onSendMessage(message);
      setMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message here..."
            className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-2 text-white placeholder-gray-400 resize-none focus:outline-none focus:ring-2 focus:ring-purple-500"
            rows={2}
            disabled={isStreaming || isInCall}
          />
        </div>
        
        <div className="flex flex-col gap-2">
          <button
            onClick={handleSendMessage}
            disabled={isStreaming || !message.trim() || isInCall}
            className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
          </button>
          
          {isInCall ? (
            <button
              onClick={onEndCall}
              className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
            >
              <PhoneOff className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onStartCall}
              disabled={isStreaming}
              className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Phone className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      
      {isInCall && (
        <div className="mt-2 text-xs text-gray-400">
          Voice call active. Text input is disabled during calls.
        </div>
      )}
      
      {isStreaming && (
        <div className="mt-2 flex items-center gap-2 text-sm text-gray-300">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          AI is responding...
        </div>
      )}
    </>
  );
};

export default MessageInput;
