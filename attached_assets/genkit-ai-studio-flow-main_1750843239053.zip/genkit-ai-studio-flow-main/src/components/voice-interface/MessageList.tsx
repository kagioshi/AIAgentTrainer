
import React, { useRef, useEffect } from 'react';

export interface Message {
  id: number;
  text: string;
  sender: 'user' | 'ai';
  timestamp: string;
}

interface MessageListProps {
  messages: Message[];
  streamedResponse: string;
  isStreaming: boolean;
}

const MessageList = ({ messages, streamedResponse, isStreaming }: MessageListProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, streamedResponse]);

  return (
    <div className="flex-1 overflow-y-auto space-y-4 mb-4">
      {messages.map((msg) => (
        <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
          <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
            msg.sender === 'user' 
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
              : 'bg-white/10 text-white border border-white/20'
          }`}>
            <p className="text-sm">{msg.text}</p>
            <p className="text-xs opacity-70 mt-1">{msg.timestamp}</p>
          </div>
        </div>
      ))}
      
      {isStreaming && streamedResponse && (
        <div className="flex justify-start">
          <div className="max-w-xs lg:max-w-md px-4 py-2 rounded-lg bg-white/10 text-white border border-white/20">
            <p className="text-sm">{streamedResponse}<span className="animate-pulse">|</span></p>
          </div>
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
};

export default MessageList;
