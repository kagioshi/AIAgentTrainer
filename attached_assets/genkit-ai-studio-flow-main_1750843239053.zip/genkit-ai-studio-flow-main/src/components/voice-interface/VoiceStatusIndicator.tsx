
import React from 'react';
import { Mic, Square, Volume, VolumeOff } from 'lucide-react';
import { VoiceState } from '@/hooks/useVoiceCall';

interface VoiceStatusIndicatorProps {
  voiceState: VoiceState;
  isInCall: boolean;
  isRecording: boolean;
  isMuted: boolean;
  toggleMute: () => void;
  toggleRecording: () => void;
}

const VoiceStatusIndicator = ({ 
  voiceState, 
  isInCall,
  isRecording,
  isMuted,
  toggleMute,
  toggleRecording 
}: VoiceStatusIndicatorProps) => {
  if (!isInCall) return null;
  
  return (
    <div className="mb-4 bg-white/5 p-3 rounded-lg flex items-center justify-between">
      <div className="flex items-center gap-2">
        {voiceState === 'listening' && (
          <div className="flex items-center">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></span>
            <span className="text-green-400 text-sm">Listening...</span>
          </div>
        )}
        {voiceState === 'processing' && (
          <div className="flex items-center">
            <span className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse mr-2"></span>
            <span className="text-yellow-400 text-sm">Processing...</span>
          </div>
        )}
        {voiceState === 'speaking' && (
          <div className="flex items-center">
            <span className="w-2 h-2 bg-blue-500 rounded-full animate-pulse mr-2"></span>
            <span className="text-blue-400 text-sm">Speaking...</span>
          </div>
        )}
        {voiceState === 'connecting' && (
          <div className="flex items-center">
            <span className="w-2 h-2 bg-purple-500 rounded-full animate-pulse mr-2"></span>
            <span className="text-purple-400 text-sm">Connecting...</span>
          </div>
        )}
      </div>
      <div className="flex gap-2">
        <button
          onClick={toggleMute}
          className={`p-2 rounded-full ${isMuted ? 'bg-red-600' : 'bg-gray-600'} hover:opacity-80`}
          title={isMuted ? "Unmute" : "Mute"}
        >
          {isMuted ? <VolumeOff className="w-4 h-4" /> : <Volume className="w-4 h-4" />}
        </button>
        <button
          onClick={toggleRecording}
          className={`p-2 rounded-full ${isRecording ? 'bg-red-600 animate-pulse' : 'bg-gray-600'}`}
          title={isRecording ? "Stop Recording" : "Start Recording"}
        >
          {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};

export default VoiceStatusIndicator;
