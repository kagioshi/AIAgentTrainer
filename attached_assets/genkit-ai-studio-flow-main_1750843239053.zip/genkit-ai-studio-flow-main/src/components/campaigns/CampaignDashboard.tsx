
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Play, Pause, BarChart3, Users, Phone, Calendar } from 'lucide-react';
import CampaignBuilder from './CampaignBuilder';
import CampaignMetrics from './CampaignMetrics';
import CampaignList from './CampaignList';

const CampaignDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [showCampaignBuilder, setShowCampaignBuilder] = useState(false);

  const campaignStats = [
    {
      title: "Active Campaigns",
      value: "12",
      icon: Play,
      color: "text-green-600"
    },
    {
      title: "Total Contacts",
      value: "2,847",
      icon: Users,
      color: "text-blue-600"
    },
    {
      title: "Calls Today",
      value: "341",
      icon: Phone,
      color: "text-purple-600"
    },
    {
      title: "Success Rate",
      value: "68%",
      icon: BarChart3,
      color: "text-orange-600"
    }
  ];

  if (showCampaignBuilder) {
    return (
      <CampaignBuilder 
        onClose={() => setShowCampaignBuilder(false)}
        onSave={(campaign) => {
          console.log('Campaign saved:', campaign);
          setShowCampaignBuilder(false);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Campaign Management</h1>
          <p className="text-gray-600 mt-1">Create and manage your outbound calling campaigns</p>
        </div>
        <Button onClick={() => setShowCampaignBuilder(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          New Campaign
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {campaignStats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  </div>
                  <Icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <CampaignMetrics />
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-6">
          <CampaignList onEditCampaign={(id) => console.log('Edit campaign:', id)} />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Advanced analytics coming soon...</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Conversion Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Conversion tracking coming soon...</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CampaignDashboard;
