
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, Trash2, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CampaignBuilderProps {
  onClose: () => void;
  onSave: (campaign: any) => void;
}

const CampaignBuilder: React.FC<CampaignBuilderProps> = ({ onClose, onSave }) => {
  const [campaignData, setCampaignData] = useState({
    name: '',
    description: '',
    type: 'outbound',
    schedule: 'immediate',
    script: '',
    targetAudience: [],
    settings: {
      maxConcurrentCalls: 10,
      retryAttempts: 3,
      callTimeout: 30
    }
  });
  const [currentStep, setCurrentStep] = useState(1);
  const { toast } = useToast();

  const steps = [
    { id: 1, title: 'Basic Info', description: 'Campaign details and settings' },
    { id: 2, title: 'Target Audience', description: 'Select your contact list' },
    { id: 3, title: 'Script & AI', description: 'Configure conversation flow' },
    { id: 4, title: 'Schedule', description: 'Set timing and execution' }
  ];

  const handleSave = () => {
    if (!campaignData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Campaign name is required",
        variant: "destructive"
      });
      return;
    }

    onSave({
      ...campaignData,
      id: Date.now().toString(),
      status: 'draft',
      createdAt: new Date().toISOString()
    });

    toast({
      title: "Campaign Created",
      description: "Your campaign has been successfully created"
    });
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <Label htmlFor="name">Campaign Name *</Label>
              <Input
                id="name"
                value={campaignData.name}
                onChange={(e) => setCampaignData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter campaign name"
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={campaignData.description}
                onChange={(e) => setCampaignData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe your campaign objectives..."
              />
            </div>
            <div>
              <Label htmlFor="type">Campaign Type</Label>
              <Select value={campaignData.type} onValueChange={(value) => setCampaignData(prev => ({ ...prev, type: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="outbound">Outbound Calls</SelectItem>
                  <SelectItem value="followup">Follow-up Campaign</SelectItem>
                  <SelectItem value="survey">Customer Survey</SelectItem>
                  <SelectItem value="reminder">Appointment Reminder</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <div>
              <Label>Target Audience</Label>
              <div className="border rounded-lg p-4 mt-2">
                <div className="text-center py-8">
                  <Plus className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-4">Select customers for this campaign</p>
                  <Button variant="outline">
                    Choose from Customer List
                  </Button>
                </div>
              </div>
            </div>
            <div>
              <Label>Filters</Label>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary">All Customers</Badge>
                <Badge variant="outline">+ Add Filter</Badge>
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <div>
              <Label htmlFor="script">AI Script Template</Label>
              <Textarea
                id="script"
                value={campaignData.script}
                onChange={(e) => setCampaignData(prev => ({ ...prev, script: e.target.value }))}
                placeholder="Hello {customer_name}, I'm calling from..."
                className="min-h-[150px]"
              />
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label>Voice Settings</Label>
                <Select defaultValue="default">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default Voice</SelectItem>
                    <SelectItem value="professional">Professional Voice</SelectItem>
                    <SelectItem value="friendly">Friendly Voice</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Language</Label>
                <Select defaultValue="en">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6">
            <div>
              <Label>Execution Schedule</Label>
              <Select value={campaignData.schedule} onValueChange={(value) => setCampaignData(prev => ({ ...prev, schedule: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">Start Immediately</SelectItem>
                  <SelectItem value="scheduled">Schedule for Later</SelectItem>
                  <SelectItem value="recurring">Recurring Campaign</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <Label>Max Concurrent Calls</Label>
                <Input
                  type="number"
                  value={campaignData.settings.maxConcurrentCalls}
                  onChange={(e) => setCampaignData(prev => ({
                    ...prev,
                    settings: { ...prev.settings, maxConcurrentCalls: parseInt(e.target.value) }
                  }))}
                />
              </div>
              <div>
                <Label>Retry Attempts</Label>
                <Input
                  type="number"
                  value={campaignData.settings.retryAttempts}
                  onChange={(e) => setCampaignData(prev => ({
                    ...prev,
                    settings: { ...prev.settings, retryAttempts: parseInt(e.target.value) }
                  }))}
                />
              </div>
              <div>
                <Label>Call Timeout (seconds)</Label>
                <Input
                  type="number"
                  value={campaignData.settings.callTimeout}
                  onChange={(e) => setCampaignData(prev => ({
                    ...prev,
                    settings: { ...prev.settings, callTimeout: parseInt(e.target.value) }
                  }))}
                />
              </div>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" onClick={onClose} className="flex items-center gap-2">
          <ArrowLeft className="w-4 h-4" />
          Back to Campaigns
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Campaign Builder</h1>
          <p className="text-gray-600">Create a new outbound calling campaign</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Steps</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {steps.map((step) => (
                <div
                  key={step.id}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    currentStep === step.id
                      ? 'bg-blue-50 border border-blue-200'
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => setCurrentStep(step.id)}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-medium ${
                        currentStep === step.id
                          ? 'bg-blue-600 text-white'
                          : currentStep > step.id
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-200 text-gray-600'
                      }`}
                    >
                      {step.id}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{step.title}</p>
                      <p className="text-xs text-gray-600">{step.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>{steps[currentStep - 1]?.title}</CardTitle>
            </CardHeader>
            <CardContent>
              {renderStepContent()}
              
              <div className="flex justify-between mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(prev => Math.max(1, prev - 1))}
                  disabled={currentStep === 1}
                >
                  Previous
                </Button>
                <div className="flex gap-3">
                  {currentStep === steps.length ? (
                    <>
                      <Button variant="outline" onClick={handleSave}>
                        Save as Draft
                      </Button>
                      <Button onClick={handleSave}>
                        Create Campaign
                      </Button>
                    </>
                  ) : (
                    <Button onClick={() => setCurrentStep(prev => Math.min(steps.length, prev + 1))}>
                      Next
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CampaignBuilder;
