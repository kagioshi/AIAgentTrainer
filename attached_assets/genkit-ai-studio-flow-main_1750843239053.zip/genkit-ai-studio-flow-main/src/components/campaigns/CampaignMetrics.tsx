
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Phone, Users, Clock, Target } from 'lucide-react';

const CampaignMetrics = () => {
  const recentCampaigns = [
    {
      id: 1,
      name: "Q1 Product Launch",
      status: "active",
      progress: 65,
      totalContacts: 500,
      completed: 325,
      successRate: 72,
      trend: "up"
    },
    {
      id: 2,
      name: "Customer Feedback Survey",
      status: "paused",
      progress: 45,
      totalContacts: 800,
      completed: 360,
      successRate: 68,
      trend: "down"
    },
    {
      id: 3,
      name: "Appointment Reminders",
      status: "completed",
      progress: 100,
      totalContacts: 200,
      completed: 200,
      successRate: 89,
      trend: "up"
    }
  ];

  const performanceMetrics = [
    {
      title: "Average Call Duration",
      value: "4m 32s",
      change: "+12%",
      trend: "up",
      icon: Clock
    },
    {
      title: "Connection Rate",
      value: "78%",
      change: "+5%",
      trend: "up",
      icon: Phone
    },
    {
      title: "Conversion Rate",
      value: "23%",
      change: "-3%",
      trend: "down",
      icon: Target
    },
    {
      title: "Customer Satisfaction",
      value: "4.6/5",
      change: "+0.2",
      trend: "up",
      icon: Users
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {performanceMetrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{metric.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{metric.value}</p>
                    <div className="flex items-center gap-1 mt-2">
                      {metric.trend === 'up' ? (
                        <TrendingUp className="w-4 h-4 text-green-600" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-600" />
                      )}
                      <span className={`text-sm ${metric.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                        {metric.change}
                      </span>
                    </div>
                  </div>
                  <Icon className="w-8 h-8 text-gray-400" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentCampaigns.map((campaign) => (
              <div key={campaign.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{campaign.name}</h3>
                    <p className="text-sm text-gray-600">
                      {campaign.completed} of {campaign.totalContacts} contacts reached
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={
                      campaign.status === 'active' ? 'default' :
                      campaign.status === 'paused' ? 'secondary' : 'outline'
                    }>
                      {campaign.status}
                    </Badge>
                    <div className="text-right">
                      <p className="text-sm font-medium">{campaign.successRate}% success</p>
                      <div className="flex items-center gap-1">
                        {campaign.trend === 'up' ? (
                          <TrendingUp className="w-3 h-3 text-green-600" />
                        ) : (
                          <TrendingDown className="w-3 h-3 text-red-600" />
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <Progress value={campaign.progress} className="h-2" />
                <div className="flex justify-between text-xs text-gray-600 mt-1">
                  <span>{campaign.progress}% complete</span>
                  <span>{campaign.totalContacts - campaign.completed} remaining</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CampaignMetrics;
