
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

const SyncManager = () => {
    const { business } = useBusiness();

    const { data: logs, isLoading } = useQuery({
        queryKey: ['syncLogs', business?.id],
        queryFn: async () => {
            if (!business) return [];
            const { data, error } = await supabase
                .from('sync_logs')
                .select('*')
                .eq('business_id', business.id)
                .order('started_at', { ascending: false })
                .limit(20);
            if (error) throw error;
            return data;
        },
        enabled: !!business,
    });
    
    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'success': return <Badge variant="default" className="bg-green-500 hover:bg-green-600">Success</Badge>;
            case 'failed': return <Badge variant="destructive">Failed</Badge>;
            case 'in_progress': return <Badge variant="secondary">In Progress</Badge>;
            default: return <Badge>{status}</Badge>;
        }
    };

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Sync Manager</CardTitle>
                    <CardDescription>Manage and monitor your data synchronization across platforms.</CardDescription>
                </div>
                <Button disabled title="Feature coming soon">Sync All Now</Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Provider</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Direction</TableHead>
                            <TableHead>Records</TableHead>
                            <TableHead>Started At</TableHead>
                            <TableHead>Finished At</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading && Array.from({ length: 5 }).map((_, i) => (
                            <TableRow key={i}><TableCell colSpan={6}><Skeleton className="h-8 w-full" /></TableCell></TableRow>
                        ))}
                        {logs?.map(log => (
                            <TableRow key={log.id}>
                                <TableCell className="capitalize">{log.provider}</TableCell>
                                <TableCell>{getStatusBadge(log.status)}</TableCell>
                                <TableCell className="capitalize">{log.direction?.replace(/_/g, ' ')}</TableCell>
                                <TableCell>{log.records_processed ?? '-'}</TableCell>
                                <TableCell>{format(new Date(log.started_at), 'Pp')}</TableCell>
                                <TableCell>{log.finished_at ? format(new Date(log.finished_at), 'Pp') : '-'}</TableCell>
                            </TableRow>
                        ))}
                        {!isLoading && logs?.length === 0 && <TableRow><TableCell colSpan={6} className="text-center py-8">No sync history found.</TableCell></TableRow>}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
};

export default SyncManager;
