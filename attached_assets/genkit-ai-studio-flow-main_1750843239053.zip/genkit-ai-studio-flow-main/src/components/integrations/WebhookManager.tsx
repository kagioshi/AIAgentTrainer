
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Copy, TestTube } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const WebhookManager = () => {
  const [webhooks, setWebhooks] = useState([
    {
      id: '1',
      name: 'Call Completed',
      url: 'https://api.example.com/webhooks/call-completed',
      events: ['call.completed', 'call.failed'],
      status: 'active',
      lastTriggered: '2024-01-15 14:30'
    },
    {
      id: '2',
      name: 'Customer Created',
      url: 'https://crm.company.com/webhooks/customer',
      events: ['customer.created', 'customer.updated'],
      status: 'active',
      lastTriggered: '2024-01-15 12:15'
    }
  ]);
  
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    url: '',
    events: []
  });
  
  const { toast } = useToast();

  const availableEvents = [
    'call.started',
    'call.completed',
    'call.failed',
    'customer.created',
    'customer.updated',
    'campaign.started',
    'campaign.completed'
  ];

  const handleSave = () => {
    if (!formData.name || !formData.url) {
      toast({
        title: "Validation Error",
        description: "Name and URL are required",
        variant: "destructive"
      });
      return;
    }

    const newWebhook = {
      id: Date.now().toString(),
      ...formData,
      status: 'active',
      lastTriggered: null
    };

    setWebhooks([...webhooks, newWebhook]);
    setFormData({ name: '', url: '', events: [] });
    setShowForm(false);

    toast({
      title: "Webhook Created",
      description: "Webhook has been successfully created"
    });
  };

  const testWebhook = async (webhook: any) => {
    toast({
      title: "Testing Webhook",
      description: "Sending test payload to webhook endpoint..."
    });
    
    // Simulate webhook test
    setTimeout(() => {
      toast({
        title: "Webhook Test Successful",
        description: "Test payload delivered successfully"
      });
    }, 2000);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "URL copied to clipboard"
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Webhook Management</h2>
          <p className="text-gray-600">Configure webhooks to receive real-time notifications</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Add Webhook
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Webhook</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Webhook Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                placeholder="e.g., Call Notifications"
              />
            </div>
            <div>
              <Label htmlFor="url">Endpoint URL</Label>
              <Input
                id="url"
                type="url"
                value={formData.url}
                onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
                placeholder="https://your-app.com/webhooks/endpoint"
              />
            </div>
            <div>
              <Label>Events</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {availableEvents.map((event) => (
                  <label key={event} className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={formData.events.includes(event)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData(prev => ({
                            ...prev,
                            events: [...prev.events, event]
                          }));
                        } else {
                          setFormData(prev => ({
                            ...prev,
                            events: prev.events.filter(e => e !== event)
                          }));
                        }
                      }}
                      className="rounded"
                    />
                    <span className="text-sm">{event}</span>
                  </label>
                ))}
              </div>
            </div>
            <div className="flex gap-3 pt-4">
              <Button onClick={handleSave}>Create Webhook</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Active Webhooks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {webhooks.map((webhook) => (
              <div key={webhook.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">{webhook.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <code className="text-sm bg-gray-100 px-2 py-1 rounded">
                        {webhook.url}
                      </code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(webhook.url)}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-100 text-green-800">
                      {webhook.status}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => testWebhook(webhook)}
                    >
                      <TestTube className="w-4 h-4 mr-2" />
                      Test
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setWebhooks(webhooks.filter(w => w.id !== webhook.id))}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </div>
                </div>
                <div className="flex gap-2 flex-wrap mb-2">
                  {webhook.events.map((event) => (
                    <Badge key={event} variant="outline" className="text-xs">
                      {event}
                    </Badge>
                  ))}
                </div>
                {webhook.lastTriggered && (
                  <p className="text-xs text-gray-500">
                    Last triggered: {webhook.lastTriggered}
                  </p>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WebhookManager;
