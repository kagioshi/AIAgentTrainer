
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Settings, Database, ExternalLink, RotateCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const CRMIntegrations = () => {
  const [integrations, setIntegrations] = useState([
    {
      id: 'salesforce',
      name: 'Salesforce',
      status: 'connected',
      apiKey: '****-****-****-1234',
      syncEnabled: true,
      lastSync: '2024-01-15 14:30',
      contactsCount: 1247
    },
    {
      id: 'hubspot',
      name: 'HubSpot',
      status: 'disconnected',
      apiKey: '',
      syncEnabled: false,
      lastSync: null,
      contactsCount: 0
    },
    {
      id: 'pipedrive',
      name: 'Pipedrive',
      status: 'disconnected',
      apiKey: '',
      syncEnabled: false,
      lastSync: null,
      contactsCount: 0
    }
  ]);

  const [editingIntegration, setEditingIntegration] = useState<string | null>(null);
  const [tempApiKey, setTempApiKey] = useState('');
  const { toast } = useToast();

  const handleConnect = (integrationId: string) => {
    if (!tempApiKey.trim()) {
      toast({
        title: "API Key Required",
        description: "Please enter your API key to connect",
        variant: "destructive"
      });
      return;
    }

    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { 
            ...integration, 
            status: 'connected', 
            apiKey: tempApiKey,
            syncEnabled: true 
          }
        : integration
    ));

    setEditingIntegration(null);
    setTempApiKey('');

    toast({
      title: "Integration Connected",
      description: `Successfully connected to ${integrations.find(i => i.id === integrationId)?.name}`
    });
  };

  const handleDisconnect = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { 
            ...integration, 
            status: 'disconnected', 
            apiKey: '',
            syncEnabled: false,
            lastSync: null,
            contactsCount: 0
          }
        : integration
    ));

    toast({
      title: "Integration Disconnected",
      description: `Disconnected from ${integrations.find(i => i.id === integrationId)?.name}`
    });
  };

  const handleSync = async (integrationId: string) => {
    toast({
      title: "Sync Started",
      description: "Syncing contacts from CRM..."
    });

    // Simulate sync process
    setTimeout(() => {
      setIntegrations(prev => prev.map(integration => 
        integration.id === integrationId 
          ? { 
              ...integration, 
              lastSync: new Date().toLocaleString(),
              contactsCount: Math.floor(Math.random() * 2000) + 500
            }
          : integration
      ));

      toast({
        title: "Sync Complete",
        description: "Successfully synced contacts from CRM"
      });
    }, 3000);
  };

  const toggleSync = (integrationId: string) => {
    setIntegrations(prev => prev.map(integration => 
      integration.id === integrationId 
        ? { ...integration, syncEnabled: !integration.syncEnabled }
        : integration
    ));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">CRM Integrations</h2>
        <p className="text-gray-600">Connect your CRM to sync contacts and opportunities</p>
      </div>

      <div className="grid gap-6">
        {integrations.map((integration) => (
          <Card key={integration.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Database className="w-8 h-8 text-gray-700" />
                  <div>
                    <CardTitle className="text-xl">{integration.name}</CardTitle>
                    <p className="text-sm text-gray-600">
                      {integration.status === 'connected' 
                        ? `${integration.contactsCount} contacts synced`
                        : 'Not connected'
                      }
                    </p>
                  </div>
                </div>
                <Badge className={
                  integration.status === 'connected' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }>
                  {integration.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {integration.status === 'connected' ? (
                <div className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>API Key</Label>
                      <div className="flex items-center gap-2 mt-1">
                        <code className="text-sm bg-gray-100 px-2 py-1 rounded flex-1">
                          {integration.apiKey}
                        </code>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setEditingIntegration(integration.id);
                            setTempApiKey('');
                          }}
                        >
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <div>
                      <Label>Last Sync</Label>
                      <p className="text-sm text-gray-600 mt-1">
                        {integration.lastSync || 'Never'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <Label>Auto Sync</Label>
                      <p className="text-sm text-gray-600">
                        Automatically sync contacts every hour
                      </p>
                    </div>
                    <Switch
                      checked={integration.syncEnabled}
                      onCheckedChange={() => toggleSync(integration.id)}
                    />
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={() => handleSync(integration.id)}
                      className="flex items-center gap-2"
                    >
                      <RotateCw className="w-4 h-4" />
                      Sync Now
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleDisconnect(integration.id)}
                    >
                      Disconnect
                    </Button>
                    <Button variant="ghost" className="flex items-center gap-2">
                      <ExternalLink className="w-4 h-4" />
                      View in CRM
                    </Button>
                  </div>
                </div>
              ) : editingIntegration === integration.id ? (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor={`apikey-${integration.id}`}>API Key</Label>
                    <Input
                      id={`apikey-${integration.id}`}
                      type="password"
                      value={tempApiKey}
                      onChange={(e) => setTempApiKey(e.target.value)}
                      placeholder="Enter your API key"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={() => handleConnect(integration.id)}>
                      Connect
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setEditingIntegration(null);
                        setTempApiKey('');
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <Button
                    onClick={() => {
                      setEditingIntegration(integration.id);
                      setTempApiKey('');
                    }}
                    className="w-full"
                  >
                    Connect {integration.name}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default CRMIntegrations;
