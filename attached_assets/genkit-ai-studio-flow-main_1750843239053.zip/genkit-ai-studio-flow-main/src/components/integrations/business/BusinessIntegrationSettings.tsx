
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { Accordion } from '@/components/ui/accordion';
import IntegrationSettingItem from './IntegrationSettingItem';
import { Skeleton } from '@/components/ui/skeleton';

const AVAILABLE_INTEGRATIONS = [
  { provider: 'salesforce', name: 'Salesforce', fields: ['api_key', 'api_secret'] },
  { provider: 'hubspot', name: 'HubSpot', fields: ['api_key'] },
];

const BusinessIntegrationSettings = () => {
    const { business } = useBusiness();
    const { data: settings, isLoading } = useQuery({
        queryKey: ['businessIntegrationSettings', business?.id],
        queryFn: async () => {
            if (!business) return [];
            const { data, error } = await supabase
                .from('business_integration_settings')
                .select('*')
                .eq('business_id', business.id);
            if (error) throw error;
            return data;
        },
        enabled: !!business,
    });

    return (
        <Card>
            <CardHeader>
                <CardTitle>Business-Specific Integration Settings</CardTitle>
                <CardDescription>Configure business-specific settings for your CRM integrations here.</CardDescription>
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <div className="space-y-2">
                        <Skeleton className="h-12 w-full" />
                        <Skeleton className="h-12 w-full" />
                    </div>
                ) : (
                    <Accordion type="single" collapsible className="w-full">
                        {AVAILABLE_INTEGRATIONS.map(p => (
                            <IntegrationSettingItem
                                key={p.provider}
                                provider={p}
                                initialSetting={settings?.find(s => s.provider === p.provider)}
                            />
                        ))}
                    </Accordion>
                )}
            </CardContent>
        </Card>
    );
};

export default BusinessIntegrationSettings;
