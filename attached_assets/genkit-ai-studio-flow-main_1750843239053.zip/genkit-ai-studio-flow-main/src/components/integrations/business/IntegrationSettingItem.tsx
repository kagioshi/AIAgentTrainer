
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { toast } from 'sonner';
import { BusinessIntegrationSettings } from '@/types/database';

interface IntegrationSettingItemProps {
  provider: { provider: string; name: string; fields: string[] };
  initialSetting: BusinessIntegrationSettings | undefined;
}

const IntegrationSettingItem = ({ provider, initialSetting }: IntegrationSettingItemProps) => {
    const { business } = useBusiness();
    const queryClient = useQueryClient();
    const [isEnabled, setIsEnabled] = useState(initialSetting?.is_enabled ?? false);
    const [settings, setSettings] = useState<any>(initialSetting?.settings ?? {});

    useEffect(() => {
        setIsEnabled(initialSetting?.is_enabled ?? false);
        setSettings(initialSetting?.settings ?? {});
    }, [initialSetting]);

    const mutation = useMutation({
        mutationFn: async (updatedSettings: Partial<BusinessIntegrationSettings>) => {
            if (!business) throw new Error("Business not found");
            
            const { data, error } = await supabase.from('business_integration_settings').upsert({
                id: initialSetting?.id,
                business_id: business.id,
                provider: provider.provider,
                is_enabled: updatedSettings.is_enabled,
                settings: updatedSettings.settings,
            }, { onConflict: 'business_id,provider' }).select().single();

            if (error) throw error;
            return data;
        },
        onSuccess: () => {
            toast.success(`${provider.name} settings saved successfully!`);
            queryClient.invalidateQueries({ queryKey: ['businessIntegrationSettings', business?.id] });
        },
        onError: (error: any) => {
            toast.error(`Failed to save settings: ${error.message}`);
        },
    });

    const handleSave = () => {
        mutation.mutate({ is_enabled: isEnabled, settings });
    };

    const handleSettingChange = (field: string, value: string) => {
        setSettings((prev: any) => ({ ...prev, [field]: value }));
    };

    return (
        <AccordionItem value={provider.provider}>
            <AccordionTrigger>{provider.name}</AccordionTrigger>
            <AccordionContent>
                <div className="space-y-4 p-1">
                    <div className="flex items-center space-x-2">
                        <Switch id={`${provider.provider}-enabled`} checked={isEnabled} onCheckedChange={setIsEnabled} />
                        <Label htmlFor={`${provider.provider}-enabled`}>Enable {provider.name} Integration</Label>
                    </div>
                    {isEnabled && (
                        <div className="space-y-2">
                            {provider.fields.map(field => (
                                <div key={field}>
                                    <Label htmlFor={`${provider.provider}-${field}`} className="text-sm font-medium">
                                        {field.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                                    </Label>
                                    <Input
                                        id={`${provider.provider}-${field}`}
                                        type="password"
                                        value={settings[field] || ''}
                                        onChange={(e) => handleSettingChange(field, e.target.value)}
                                        placeholder={`Enter your ${provider.name} ${field}`}
                                    />
                                </div>
                            ))}
                        </div>
                    )}
                    <Button onClick={handleSave} disabled={mutation.isPending}>
                        {mutation.isPending ? 'Saving...' : 'Save'}
                    </Button>
                </div>
            </AccordionContent>
        </AccordionItem>
    );
};

export default IntegrationSettingItem;
