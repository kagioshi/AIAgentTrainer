
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { toast } from 'sonner';
import { Trash2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const LOCAL_CUSTOMER_FIELDS = ['first_name', 'last_name', 'email', 'phone_number', 'tier', 'status', 'notes', 'tags', 'last_contact_date', 'preferred_contact_method'];
const PROVIDERS = ['salesforce', 'hubspot'];

const CustomFieldMapper = () => {
    const { business } = useBusiness();
    const queryClient = useQueryClient();
    const [newMapping, setNewMapping] = useState({ provider: '', local_field: '', remote_field: '' });

    const { data: mappings, isLoading } = useQuery({
        queryKey: ['customFieldMappings', business?.id],
        queryFn: async () => {
            if (!business) return [];
            const { data, error } = await supabase
                .from('custom_field_mappings')
                .select('*')
                .eq('business_id', business.id);
            if (error) throw error;
            return data;
        },
        enabled: !!business,
    });

    const addMutation = useMutation({
        mutationFn: async () => {
            if (!business) throw new Error("Business not found");
            const { error } = await supabase.from('custom_field_mappings').insert([{
                business_id: business.id,
                ...newMapping
            }]);
            if (error) throw error;
        },
        onSuccess: () => {
            toast.success('Field mapping added!');
            queryClient.invalidateQueries({ queryKey: ['customFieldMappings', business?.id] });
            setNewMapping({ provider: '', local_field: '', remote_field: '' });
        },
        onError: (error: any) => {
            toast.error(`Failed to add mapping: ${error.message}`);
        },
    });

    const deleteMutation = useMutation({
        mutationFn: async (id: string) => {
            const { error } = await supabase.from('custom_field_mappings').delete().eq('id', id);
            if (error) throw error;
        },
        onSuccess: () => {
            toast.success('Field mapping deleted!');
            queryClient.invalidateQueries({ queryKey: ['customFieldMappings', business?.id] });
        },
        onError: (error: any) => {
            toast.error(`Failed to delete mapping: ${error.message}`);
        },
    });

    const handleAddMapping = () => {
        if (!newMapping.provider || !newMapping.local_field || !newMapping.remote_field) {
            toast.error('Please fill all fields for the new mapping.');
            return;
        }
        addMutation.mutate();
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Custom Field Mapper</CardTitle>
                <CardDescription>Map your custom fields to our system's fields here.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6 p-1">
                    <Select value={newMapping.provider} onValueChange={(v) => setNewMapping(p => ({...p, provider: v}))}>
                        <SelectTrigger><SelectValue placeholder="Select Provider" /></SelectTrigger>
                        <SelectContent>
                            {PROVIDERS.map(p => <SelectItem key={p} value={p}>{p.charAt(0).toUpperCase() + p.slice(1)}</SelectItem>)}
                        </SelectContent>
                    </Select>
                     <Select value={newMapping.local_field} onValueChange={(v) => setNewMapping(p => ({...p, local_field: v}))}>
                        <SelectTrigger><SelectValue placeholder="Select Local Field" /></SelectTrigger>
                        <SelectContent>
                            {LOCAL_CUSTOMER_FIELDS.map(f => <SelectItem key={f} value={f}>{f.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}</SelectItem>)}
                        </SelectContent>
                    </Select>
                    <Input 
                        placeholder="Remote Field Name"
                        value={newMapping.remote_field}
                        onChange={(e) => setNewMapping(p => ({...p, remote_field: e.target.value}))}
                    />
                    <Button onClick={handleAddMapping} disabled={addMutation.isPending}>
                        {addMutation.isPending ? 'Adding...' : 'Add Mapping'}
                    </Button>
                </div>

                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Provider</TableHead>
                            <TableHead>Local Field</TableHead>
                            <TableHead>Remote Field</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading && <TableRow><TableCell colSpan={4}><Skeleton className="h-8 w-full" /></TableCell></TableRow>}
                        {mappings?.map(mapping => (
                            <TableRow key={mapping.id}>
                                <TableCell>{mapping.provider}</TableCell>
                                <TableCell>{mapping.local_field}</TableCell>
                                <TableCell>{mapping.remote_field}</TableCell>
                                <TableCell className="text-right">
                                    <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(mapping.id)} disabled={deleteMutation.isPending && deleteMutation.variables === mapping.id}>
                                        <Trash2 className="h-4 w-4" />
                                    </Button>
                                </TableCell>
                            </TableRow>
                        ))}
                         {!isLoading && mappings?.length === 0 && <TableRow><TableCell colSpan={4} className="text-center">No custom field mappings found.</TableCell></TableRow>}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
};

export default CustomFieldMapper;
