
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Settings, ExternalLink, Zap, Database, Globe, Building } from 'lucide-react';
import WebhookManager from './WebhookManager';
import CRMIntegrations from './CRMIntegrations';
import AutomationBuilder from './automation/AutomationBuilder';
import BusinessIntegrationSettings from './business/BusinessIntegrationSettings';
import CustomFieldMapper from './business/CustomFieldMapper';
import SyncManager from './sync/SyncManager';

const IntegrationDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const integrations = [
    {
      id: 'salesforce',
      name: 'Salesforce',
      category: 'CRM',
      status: 'connected',
      icon: Database,
      description: 'Sync contacts and opportunities',
      lastSync: '2024-01-15 14:30'
    },
    {
      id: 'hubspot',
      name: 'HubSpot',
      category: 'CRM',
      status: 'available',
      icon: Database,
      description: 'Manage leads and pipeline',
      lastSync: null
    },
    {
      id: 'zapier',
      name: 'Zapier',
      category: 'Automation',
      status: 'connected',
      icon: Zap,
      description: 'Connect with 3000+ apps',
      lastSync: '2024-01-15 12:15'
    },
    {
      id: 'webhooks',
      name: 'Webhooks',
      category: 'API',
      status: 'configured',
      icon: Globe,
      description: 'Custom API integrations',
      lastSync: 'Real-time'
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge className="bg-green-100 text-green-800">Connected</Badge>;
      case 'configured':
        return <Badge className="bg-blue-100 text-blue-800">Configured</Badge>;
      case 'available':
        return <Badge variant="outline">Available</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Integrations</h1>
          <p className="text-gray-600 mt-1">Connect your favorite tools and automate workflows</p>
        </div>
        <Button className="flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Browse Integrations
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="crm">CRM</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="business">
            <div className="flex items-center gap-2">
              <Building />
              Business
            </div>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {integrations.map((integration) => {
              const Icon = integration.icon;
              return (
                <Card key={integration.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-gray-100 rounded-lg">
                          <Icon className="w-6 h-6 text-gray-700" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{integration.name}</h3>
                          <p className="text-sm text-gray-600">{integration.category}</p>
                        </div>
                      </div>
                      {getStatusBadge(integration.status)}
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-4">{integration.description}</p>
                    
                    {integration.lastSync && (
                      <p className="text-xs text-gray-500 mb-4">
                        Last sync: {integration.lastSync}
                      </p>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <Switch checked={integration.status === 'connected' || integration.status === 'configured'} />
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="crm" className="space-y-6">
          <CRMIntegrations />
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-6">
          <WebhookManager />
        </TabsContent>

        <TabsContent value="automation" className="space-y-6">
          <AutomationBuilder />
        </TabsContent>
        
        <TabsContent value="business" className="space-y-6">
          <div className="grid gap-6">
            <BusinessIntegrationSettings />
            <CustomFieldMapper />
            <SyncManager />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default IntegrationDashboard;
