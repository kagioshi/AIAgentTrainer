
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Plus, Zap } from 'lucide-react';

const AutomationBuilder = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Automation Hub</CardTitle>
        <CardDescription>Create powerful automations to streamline your workflows.</CardDescription>
      </CardHeader>
      <CardContent>
          <div className="text-center py-12">
            <Zap className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Automation Builder</h3>
            <p className="text-gray-600 mb-6">This feature is under construction.</p>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Automation
            </Button>
          </div>
      </CardContent>
    </Card>
  );
};

export default AutomationBuilder;
