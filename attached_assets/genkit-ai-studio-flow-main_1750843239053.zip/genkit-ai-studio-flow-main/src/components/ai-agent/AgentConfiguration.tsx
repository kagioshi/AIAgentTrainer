
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Bot, Brain, MessageSquare, Volume2, Save } from 'lucide-react';
import { toast } from 'sonner';

interface AgentConfig {
  id: string;
  name: string;
  personality: {
    tone?: string;
    style?: string;
    personality?: string;
  };
  voice_settings: {
    voice?: string;
    speed?: number;
    pitch?: number;
  };
  knowledge_base?: string;
  response_templates: {
    greeting?: string;
    goodbye?: string;
    hold_message?: string;
  };
  is_active: boolean;
}

export const AgentConfiguration = () => {
  const { business } = useBusiness();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<'personality' | 'voice' | 'knowledge'>('personality');

  const { data: agentConfig, isLoading } = useQuery({
    queryKey: ['agent-config', business?.id],
    queryFn: async () => {
      if (!business?.id) return null;
      
      const { data, error } = await supabase
        .from('agent_configurations')
        .select('*')
        .eq('business_id', business.id)
        .eq('is_active', true)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data as AgentConfig;
    },
    enabled: !!business?.id,
  });

  const updateAgent = useMutation({
    mutationFn: async (updates: Partial<AgentConfig>) => {
      if (!business?.id) throw new Error('No business ID');
      
      if (agentConfig?.id) {
        const { error } = await supabase
          .from('agent_configurations')
          .update(updates)
          .eq('id', agentConfig.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('agent_configurations')
          .insert({
            business_id: business.id,
            name: 'AI Agent',
            ...updates
          });
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agent-config'] });
      toast.success('Agent configuration updated successfully');
    },
    onError: (error) => {
      toast.error('Failed to update agent configuration');
      console.error('Error updating agent:', error);
    },
  });

  const handlePersonalityUpdate = (field: string, value: string) => {
    const personality = { ...agentConfig?.personality, [field]: value };
    updateAgent.mutate({ personality });
  };

  const handleVoiceUpdate = (field: string, value: string | number) => {
    const voice_settings = { ...agentConfig?.voice_settings, [field]: value };
    updateAgent.mutate({ voice_settings });
  };

  const handleTemplateUpdate = (field: string, value: string) => {
    const response_templates = { ...agentConfig?.response_templates, [field]: value };
    updateAgent.mutate({ response_templates });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-gray-500">Loading agent configuration...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">AI Agent Configuration</h1>
        <div className="flex items-center space-x-2">
          <Switch
            checked={agentConfig?.is_active ?? true}
            onCheckedChange={(checked) => updateAgent.mutate({ is_active: checked })}
          />
          <Label>Agent Active</Label>
        </div>
      </div>

      <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
        <Button
          variant={activeTab === 'personality' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('personality')}
          className="flex-1"
        >
          <Brain className="w-4 h-4 mr-2" />
          Personality
        </Button>
        <Button
          variant={activeTab === 'voice' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('voice')}
          className="flex-1"
        >
          <Volume2 className="w-4 h-4 mr-2" />
          Voice Settings
        </Button>
        <Button
          variant={activeTab === 'knowledge' ? 'default' : 'ghost'}
          onClick={() => setActiveTab('knowledge')}
          className="flex-1"
        >
          <Bot className="w-4 h-4 mr-2" />
          Knowledge Base
        </Button>
      </div>

      {activeTab === 'personality' && (
        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Personality Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="tone">Communication Tone</Label>
                <Select
                  value={agentConfig?.personality?.tone || 'professional'}
                  onValueChange={(value) => handlePersonalityUpdate('tone', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="professional">Professional</SelectItem>
                    <SelectItem value="friendly">Friendly</SelectItem>
                    <SelectItem value="casual">Casual</SelectItem>
                    <SelectItem value="formal">Formal</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="style">Communication Style</Label>
                <Select
                  value={agentConfig?.personality?.style || 'helpful'}
                  onValueChange={(value) => handlePersonalityUpdate('style', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="helpful">Helpful</SelectItem>
                    <SelectItem value="direct">Direct</SelectItem>
                    <SelectItem value="detailed">Detailed</SelectItem>
                    <SelectItem value="concise">Concise</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="personality">Personality Description</Label>
                <Textarea
                  id="personality"
                  placeholder="Describe how your AI agent should behave..."
                  value={agentConfig?.personality?.personality || ''}
                  onChange={(e) => handlePersonalityUpdate('personality', e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Response Templates</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="greeting">Greeting Message</Label>
                <Textarea
                  id="greeting"
                  placeholder="Hello! How can I help you today?"
                  value={agentConfig?.response_templates?.greeting || ''}
                  onChange={(e) => handleTemplateUpdate('greeting', e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="goodbye">Goodbye Message</Label>
                <Textarea
                  id="goodbye"
                  placeholder="Thank you for calling. Have a great day!"
                  value={agentConfig?.response_templates?.goodbye || ''}
                  onChange={(e) => handleTemplateUpdate('goodbye', e.target.value)}
                  rows={2}
                />
              </div>

              <div>
                <Label htmlFor="hold">Hold Message</Label>
                <Textarea
                  id="hold"
                  placeholder="Please hold while I look that up for you..."
                  value={agentConfig?.response_templates?.hold_message || ''}
                  onChange={(e) => handleTemplateUpdate('hold_message', e.target.value)}
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === 'voice' && (
        <Card>
          <CardHeader>
            <CardTitle>Voice Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="voice">Voice Type</Label>
              <Select
                value={agentConfig?.voice_settings?.voice || 'female'}
                onValueChange={(value) => handleVoiceUpdate('voice', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="neutral">Neutral</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="speed">Speaking Speed</Label>
              <Select
                value={String(agentConfig?.voice_settings?.speed || 1)}
                onValueChange={(value) => handleVoiceUpdate('speed', parseFloat(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.8">Slow</SelectItem>
                  <SelectItem value="1">Normal</SelectItem>
                  <SelectItem value="1.2">Fast</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="pitch">Voice Pitch</Label>
              <Select
                value={String(agentConfig?.voice_settings?.pitch || 1)}
                onValueChange={(value) => handleVoiceUpdate('pitch', parseFloat(value))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.8">Low</SelectItem>
                  <SelectItem value="1">Normal</SelectItem>
                  <SelectItem value="1.2">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      )}

      {activeTab === 'knowledge' && (
        <Card>
          <CardHeader>
            <CardTitle>Knowledge Base</CardTitle>
          </CardHeader>
          <CardContent>
            <div>
              <Label htmlFor="knowledge">Business Information</Label>
              <Textarea
                id="knowledge"
                placeholder="Enter information about your business, services, policies, and common questions..."
                value={agentConfig?.knowledge_base || ''}
                onChange={(e) => updateAgent.mutate({ knowledge_base: e.target.value })}
                rows={10}
                className="mt-2"
              />
              <p className="text-sm text-gray-500 mt-2">
                This information will help your AI agent answer questions about your business accurately.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
