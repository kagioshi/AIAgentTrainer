
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { User, UserCheck, UserX, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface Agent {
  id: string;
  first_name: string | null;
  last_name: string | null;
  role: string | null;
  status: 'available' | 'busy' | 'offline';
  current_call_id?: string;
  active_since?: string;
}

const AgentStatus = () => {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAgents();

    const channel = supabase
      .channel('agent-status')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'calls'
      }, () => {
        fetchAgents();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchAgents = async () => {
    try {
      // Get business users (agents)
      const { data: businessUsers, error: businessError } = await supabase
        .from('business_users')
        .select(`
          user_id,
          role,
          profiles (id, first_name, last_name, role)
        `)
        .eq('status', 'active');

      if (businessError) throw businessError;

      // Get active calls to determine agent status
      const { data: activeCalls, error: callsError } = await supabase
        .from('calls')
        .select('agent_id')
        .eq('status', 'active');

      if (callsError) throw callsError;

      const busyAgentIds = new Set(activeCalls?.map(call => call.agent_id).filter(Boolean));

      const agentData: Agent[] = businessUsers?.map(bu => ({
        id: bu.user_id,
        first_name: bu.profiles?.first_name || null,
        last_name: bu.profiles?.last_name || null,
        role: bu.role,
        status: busyAgentIds.has(bu.user_id) ? 'busy' : 'available'
      })) || [];

      setAgents(agentData);
    } catch (error) {
      console.error('Error fetching agents:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return <UserCheck className="w-4 h-4 text-green-600" />;
      case 'busy': return <User className="w-4 h-4 text-orange-600" />;
      case 'offline': return <UserX className="w-4 h-4 text-red-600" />;
      default: return <User className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      available: 'bg-green-100 text-green-700 border-green-300',
      busy: 'bg-orange-100 text-orange-700 border-orange-300',
      offline: 'bg-red-100 text-red-700 border-red-300'
    };
    
    return (
      <Badge variant="outline" className={variants[status as keyof typeof variants]}>
        {status}
      </Badge>
    );
  };

  const availableCount = agents.filter(a => a.status === 'available').length;
  const busyCount = agents.filter(a => a.status === 'busy').length;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Agent Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">Loading agents...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <UserCheck className="w-5 h-5" />
            Agent Status
          </div>
          <div className="text-sm font-normal">
            {availableCount} / {agents.length} available
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center p-3 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600">{availableCount}</div>
            <div className="text-sm text-green-700">Available</div>
          </div>
          <div className="text-center p-3 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600">{busyCount}</div>
            <div className="text-sm text-orange-700">Busy</div>
          </div>
          <div className="text-center p-3 bg-gray-50 rounded-lg">
            <div className="text-2xl font-bold text-gray-600">{agents.length}</div>
            <div className="text-sm text-gray-700">Total</div>
          </div>
        </div>

        <div className="space-y-3">
          {agents.map((agent) => (
            <div 
              key={agent.id}
              className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                {getStatusIcon(agent.status)}
                <div>
                  <div className="font-medium">
                    {agent.first_name && agent.last_name 
                      ? `${agent.first_name} ${agent.last_name}`
                      : 'Agent'
                    }
                  </div>
                  <div className="text-sm text-gray-600 capitalize">
                    {agent.role || 'agent'}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {getStatusBadge(agent.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default AgentStatus;
