
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, Clock, Users, Phone, AlertTriangle } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const QueueAnalytics = () => {
  const [timeRange, setTimeRange] = useState('today');

  const queueTrendData = [
    { time: '9:00', calls: 5, waitTime: 2.5 },
    { time: '10:00', calls: 12, waitTime: 4.2 },
    { time: '11:00', calls: 18, waitTime: 6.8 },
    { time: '12:00', calls: 25, waitTime: 8.1 },
    { time: '13:00', calls: 15, waitTime: 5.3 },
    { time: '14:00', calls: 20, waitTime: 7.2 },
    { time: '15:00', calls: 22, waitTime: 6.9 },
    { time: '16:00', calls: 28, waitTime: 9.1 }
  ];

  const abandonmentData = [
    { hour: '9-10', abandoned: 2, answered: 8 },
    { hour: '10-11', abandoned: 3, answered: 15 },
    { hour: '11-12', abandoned: 5, answered: 13 },
    { hour: '12-13', abandoned: 8, answered: 17 },
    { hour: '13-14', abandoned: 4, answered: 11 },
    { hour: '14-15', abandoned: 6, answered: 14 },
    { hour: '15-16', abandoned: 7, answered: 15 },
    { hour: '16-17', abandoned: 9, answered: 19 }
  ];

  const tierDistribution = [
    { name: 'Bronze', value: 45, color: '#8B5CF6' },
    { name: 'Silver', value: 30, color: '#06B6D4' },
    { name: 'Gold', value: 20, color: '#F59E0B' },
    { name: 'Platinum', value: 5, color: '#EF4444' }
  ];

  const performanceMetrics = {
    avgWaitTime: '4.2 min',
    maxWaitTime: '12.3 min',
    abandonmentRate: '8.5%',
    serviceLevel: '92.3%',
    throughput: '156 calls',
    efficiency: '94.1%'
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Queue Performance Analytics</h3>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="yesterday">Yesterday</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{performanceMetrics.avgWaitTime}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Clock className="w-3 h-3" />
              Avg Wait
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{performanceMetrics.maxWaitTime}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Max Wait
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{performanceMetrics.abandonmentRate}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Phone className="w-3 h-3" />
              Abandonment
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{performanceMetrics.serviceLevel}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <TrendingUp className="w-3 h-3" />
              Service Level
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{performanceMetrics.throughput}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Users className="w-3 h-3" />
              Throughput
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-cyan-600">{performanceMetrics.efficiency}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <BarChart3 className="w-3 h-3" />
              Efficiency
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Queue Volume and Wait Times */}
        <Card>
          <CardHeader>
            <CardTitle>Queue Volume & Wait Times</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={queueTrendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis yAxisId="left" />
                <YAxis yAxisId="right" orientation="right" />
                <Tooltip />
                <Bar yAxisId="left" dataKey="calls" fill="#3B82F6" />
                <Line yAxisId="right" type="monotone" dataKey="waitTime" stroke="#EF4444" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Abandonment Analysis */}
        <Card>
          <CardHeader>
            <CardTitle>Call Outcome Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={abandonmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="answered" stackId="a" fill="#10B981" />
                <Bar dataKey="abandoned" stackId="a" fill="#EF4444" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Customer Tier Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Customer Tier Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={tierDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {tierDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Performance Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2 text-green-700 font-medium">
                <TrendingUp className="w-4 h-4" />
                Peak Performance
              </div>
              <p className="text-sm text-green-600 mt-1">
                Service level exceeded target during 9-11 AM period
              </p>
            </div>
            
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <div className="flex items-center gap-2 text-orange-700 font-medium">
                <AlertTriangle className="w-4 h-4" />
                Attention Needed
              </div>
              <p className="text-sm text-orange-600 mt-1">
                High abandonment rate during lunch hours (12-1 PM)
              </p>
            </div>
            
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center gap-2 text-blue-700 font-medium">
                <Users className="w-4 h-4" />
                Recommendation
              </div>
              <p className="text-sm text-blue-600 mt-1">
                Consider adding 2 more agents during peak hours
              </p>
            </div>
            
            <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
              <div className="flex items-center gap-2 text-purple-700 font-medium">
                <BarChart3 className="w-4 h-4" />
                Optimization
              </div>
              <p className="text-sm text-purple-600 mt-1">
                Queue rules are working effectively for VIP customers
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QueueAnalytics;
