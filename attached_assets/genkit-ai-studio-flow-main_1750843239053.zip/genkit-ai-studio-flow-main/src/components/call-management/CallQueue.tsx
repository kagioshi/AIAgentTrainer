import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Clock } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { CallWithRelations } from '@/types/database';
import { callService } from '@/services/callService';

const CallQueue = () => {
  const [queuedCalls, setQueuedCalls] = useState<CallWithRelations[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchQueuedCalls = async () => {
    try {
      const data = await callService.getQueuedCalls();
      setQueuedCalls(data || []);
    } catch (error) {
      console.error('Error fetching queued calls:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQueuedCalls();

    const channel = supabase
      .channel('call-queue-component')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'calls',
        filter: 'status=eq.queued'
      }, () => {
        fetchQueuedCalls();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const assignCall = async (callId: string) => {
    try {
      await callService.assignCall(callId);
    } catch (error) {
      console.error('Error assigning call:', error);
    }
  };

  const getPriorityColor = (tier: string) => {
    switch (tier) {
      case 'platinum': return 'border-l-purple-500 bg-purple-50';
      case 'gold': return 'border-l-yellow-500 bg-yellow-50';
      case 'silver': return 'border-l-gray-400 bg-gray-50';
      default: return 'border-l-green-500 bg-green-50';
    }
  };

  const getWaitTime = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    return `${diffInMinutes}m`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Call Queue
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">Loading queue...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Call Queue ({queuedCalls.length})
          </div>
          <Badge variant="outline" className="bg-blue-50">
            {queuedCalls.length} waiting
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {queuedCalls.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Phone className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No calls in queue</p>
          </div>
        ) : (
          <div className="space-y-3">
            {queuedCalls.map((call, index) => (
              <div 
                key={call.id}
                className={`p-4 rounded-lg border-l-4 ${getPriorityColor(call.customers?.tier || 'bronze')} hover:bg-gray-50 transition-colors`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-sm font-mono text-gray-500">#{index + 1}</div>
                    <div>
                      <div className="font-medium">
                        {call.customers?.first_name && call.customers?.last_name 
                          ? `${call.customers.first_name} ${call.customers.last_name}`
                          : 'Unknown Caller'
                        }
                      </div>
                      <div className="text-sm text-gray-600">
                        {call.customers?.phone_number || 'No phone'}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {call.customers?.tier || 'bronze'}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {call.call_type}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-orange-600 font-medium">
                      <Clock className="w-4 h-4" />
                      {getWaitTime(call.created_at)}
                    </div>
                    <Button 
                      size="sm" 
                      className="mt-2"
                      onClick={() => assignCall(call.id)}
                    >
                      <Phone className="w-4 h-4 mr-1" />
                      Take Call
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CallQueue;
