
import React from 'react';
import { Button } from "@/components/ui/button";
import { Download } from 'lucide-react';
import { CallWithRelations } from '@/types/database';
import AudioPlayer from './AudioPlayer';
import CallMetadata from './CallMetadata';
import CallTranscript from './CallTranscript';

interface CallRecordingPlayerProps {
  call: CallWithRelations;
}

const CallRecordingPlayer: React.FC<CallRecordingPlayerProps> = ({ call }) => {
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const downloadRecording = () => {
    if (call.recording_url) {
      const link = document.createElement('a');
      link.href = call.recording_url;
      link.download = `call-recording-${call.id}.mp3`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="space-y-6">
      {/* Player Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">
            Call with {call.customers?.first_name && call.customers?.last_name 
              ? `${call.customers.first_name} ${call.customers.last_name}`
              : 'Unknown Caller'
            }
          </h3>
          <p className="text-sm text-gray-600">
            {new Date(call.created_at).toLocaleDateString()} • Duration: {formatTime(call.duration || 0)}
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={downloadRecording}>
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
        </div>
      </div>

      {/* Audio Player */}
      {call.recording_url && (
        <AudioPlayer audioUrl={call.recording_url} />
      )}

      {/* Transcript */}
      {call.transcript && (
        <CallTranscript transcript={call.transcript} callId={call.id} />
      )}

      {/* Call Metadata */}
      <CallMetadata call={call} />
    </div>
  );
};

export default CallRecordingPlayer;
