
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Clock, User, PhoneOff } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { CallWithRelations } from '@/types/database';

const ActiveCalls = () => {
  const [activeCalls, setActiveCalls] = useState<CallWithRelations[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchActiveCalls();

    const channel = supabase
      .channel('active-calls')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'calls'
      }, () => {
        fetchActiveCalls();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Update call durations every second
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveCalls(prevCalls => 
        prevCalls.map(call => {
          const now = new Date();
          const started = new Date(call.created_at);
          const duration = Math.floor((now.getTime() - started.getTime()) / 1000);
          return { ...call, duration };
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const fetchActiveCalls = async () => {
    try {
      const { data, error } = await supabase
        .from('calls')
        .select(`
          *,
          customers (first_name, last_name, phone_number, email, tier),
          profiles (first_name, last_name, role)
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setActiveCalls(data || []);
    } catch (error) {
      console.error('Error fetching active calls:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const endCall = async (callId: string) => {
    try {
      const { error } = await supabase
        .from('calls')
        .update({ 
          status: 'completed',
          updated_at: new Date().toISOString()
        })
        .eq('id', callId);

      if (error) throw error;
    } catch (error) {
      console.error('Error ending call:', error);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Active Calls</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">Loading active calls...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            Active Calls ({activeCalls.length})
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {activeCalls.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Phone className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No active calls</p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeCalls.map((call) => (
              <div 
                key={call.id}
                className="p-4 rounded-lg border bg-green-50 border-green-200 hover:bg-green-100 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <div>
                      <div className="font-medium">
                        {call.customers?.first_name && call.customers?.last_name 
                          ? `${call.customers.first_name} ${call.customers.last_name}`
                          : 'Unknown Caller'
                        }
                      </div>
                      <div className="text-sm text-gray-600">
                        {call.customers?.phone_number || 'No phone'}
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <User className="w-4 h-4 text-gray-400" />
                        <span className="text-sm text-gray-600">
                          {call.profiles?.first_name && call.profiles?.last_name
                            ? `${call.profiles.first_name} ${call.profiles.last_name}`
                            : 'AI Agent'
                          }
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-green-600 font-mono font-medium">
                      <Clock className="w-4 h-4" />
                      {formatDuration(call.duration || 0)}
                    </div>
                    <Button 
                      size="sm" 
                      variant="destructive"
                      className="mt-2"
                      onClick={() => endCall(call.id)}
                    >
                      <PhoneOff className="w-4 h-4 mr-1" />
                      End Call
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ActiveCalls;
