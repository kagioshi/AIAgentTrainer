
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { TrendingUp, AlertTriangle, Phone, Users, Clock, Settings, Save } from 'lucide-react';

const QueueOverflow = () => {
  const [overflowSettings, setOverflowSettings] = useState({
    enabled: true,
    maxQueueSize: 25,
    maxWaitTime: 8,
    escalationDelay: 5,
    callbackEnabled: true,
    voicemailEnabled: true,
    externalRoutingEnabled: false
  });

  const [escalationRules, setEscalationRules] = useState([
    {
      id: '1',
      name: 'Queue Size Overflow',
      trigger: 'Queue exceeds 25 calls',
      action: 'Offer callback option',
      priority: 1,
      isActive: true
    },
    {
      id: '2',
      name: 'Long Wait Escalation',
      trigger: 'Wait time exceeds 8 minutes',
      action: 'Route to supervisor',
      priority: 2,
      isActive: true
    },
    {
      id: '3',
      name: 'Agent Shortage',
      trigger: 'Less than 2 agents available',
      action: 'Enable external routing',
      priority: 3,
      isActive: false
    }
  ]);

  const [currentStatus, setCurrentStatus] = useState({
    queueSize: 12,
    avgWaitTime: 4.2,
    availableAgents: 5,
    overflowActive: false,
    callbacksOffered: 3,
    externalRoutes: 0
  });

  const toggleOverflow = () => {
    setOverflowSettings({
      ...overflowSettings,
      enabled: !overflowSettings.enabled
    });
  };

  const saveSettings = () => {
    // TODO: Implement save functionality
    console.log('Saving overflow settings...');
  };

  return (
    <div className="space-y-6">
      {/* Current Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Overflow Status Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-6 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{currentStatus.queueSize}</div>
              <div className="text-sm text-gray-600">Queue Size</div>
              <Badge variant={currentStatus.queueSize > overflowSettings.maxQueueSize ? "destructive" : "secondary"}>
                {currentStatus.queueSize > overflowSettings.maxQueueSize ? 'Over Limit' : 'Normal'}
              </Badge>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{currentStatus.avgWaitTime}m</div>
              <div className="text-sm text-gray-600">Avg Wait</div>
              <Badge variant={currentStatus.avgWaitTime > overflowSettings.maxWaitTime ? "destructive" : "secondary"}>
                {currentStatus.avgWaitTime > overflowSettings.maxWaitTime ? 'Over Limit' : 'Normal'}
              </Badge>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{currentStatus.availableAgents}</div>
              <div className="text-sm text-gray-600">Available</div>
              <Badge variant={currentStatus.availableAgents < 2 ? "destructive" : "secondary"}>
                {currentStatus.availableAgents < 2 ? 'Low' : 'Good'}
              </Badge>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{currentStatus.callbacksOffered}</div>
              <div className="text-sm text-gray-600">Callbacks</div>
              <Badge variant="outline">Today</Badge>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-cyan-600">{currentStatus.externalRoutes}</div>
              <div className="text-sm text-gray-600">External</div>
              <Badge variant="outline">Routes</Badge>
            </div>
            <div className="text-center">
              <div className={`text-2xl font-bold ${currentStatus.overflowActive ? 'text-red-600' : 'text-gray-400'}`}>
                {currentStatus.overflowActive ? 'ACTIVE' : 'INACTIVE'}
              </div>
              <div className="text-sm text-gray-600">Overflow</div>
              <Badge variant={currentStatus.overflowActive ? "destructive" : "outline"}>
                Status
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Overflow Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Overflow Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base font-medium">Enable Overflow Management</Label>
              <p className="text-sm text-gray-600">Automatically handle queue overflow situations</p>
            </div>
            <Switch
              checked={overflowSettings.enabled}
              onCheckedChange={toggleOverflow}
            />
          </div>

          <Separator />

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="maxQueueSize">Maximum Queue Size</Label>
              <Input
                id="maxQueueSize"
                type="number"
                value={overflowSettings.maxQueueSize}
                onChange={(e) => setOverflowSettings({
                  ...overflowSettings,
                  maxQueueSize: parseInt(e.target.value)
                })}
              />
              <p className="text-xs text-gray-500">Trigger overflow when queue exceeds this size</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxWaitTime">Maximum Wait Time (minutes)</Label>
              <Input
                id="maxWaitTime"
                type="number"
                value={overflowSettings.maxWaitTime}
                onChange={(e) => setOverflowSettings({
                  ...overflowSettings,
                  maxWaitTime: parseInt(e.target.value)
                })}
              />
              <p className="text-xs text-gray-500">Trigger overflow when wait time exceeds this</p>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="text-sm font-medium">Overflow Actions</h4>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="callbackEnabled">Callback Options</Label>
                <Switch
                  id="callbackEnabled"
                  checked={overflowSettings.callbackEnabled}
                  onCheckedChange={(checked) => setOverflowSettings({
                    ...overflowSettings,
                    callbackEnabled: checked
                  })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="voicemailEnabled">Voicemail Routing</Label>
                <Switch
                  id="voicemailEnabled"
                  checked={overflowSettings.voicemailEnabled}
                  onCheckedChange={(checked) => setOverflowSettings({
                    ...overflowSettings,
                    voicemailEnabled: checked
                  })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="externalRoutingEnabled">External Routing</Label>
                <Switch
                  id="externalRoutingEnabled"
                  checked={overflowSettings.externalRoutingEnabled}
                  onCheckedChange={(checked) => setOverflowSettings({
                    ...overflowSettings,
                    externalRoutingEnabled: checked
                  })}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Escalation Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Escalation Rules
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {escalationRules.map((rule) => (
              <div key={rule.id} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">#{rule.priority}</Badge>
                    <div>
                      <h4 className="font-medium">{rule.name}</h4>
                      <p className="text-sm text-gray-600">{rule.trigger} → {rule.action}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={rule.isActive ? "default" : "secondary"}>
                      {rule.isActive ? 'Active' : 'Inactive'}
                    </Badge>
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={(checked) => {
                        setEscalationRules(escalationRules.map(r => 
                          r.id === rule.id ? { ...r, isActive: checked } : r
                        ));
                      }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={saveSettings}>
          <Save className="w-4 h-4 mr-2" />
          Save Overflow Configuration
        </Button>
      </div>
    </div>
  );
};

export default QueueOverflow;
