
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Clock, User, Phone, MessageSquare, Tag, Calendar, PhoneCall } from 'lucide-react';
import { CallWithRelations } from '@/types/database';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface CallDetailModalProps {
  call: CallWithRelations;
}

const CallDetailModal: React.FC<CallDetailModalProps> = ({ call }) => {
  const [notes, setNotes] = useState(call.transcript || '');
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  const updateCallNotes = async () => {
    setIsUpdating(true);
    try {
      const { error } = await supabase
        .from('calls')
        .update({ transcript: notes })
        .eq('id', call.id);

      if (error) throw error;

      toast({
        title: "Notes Updated",
        description: "Call notes have been saved successfully.",
      });
    } catch (error) {
      console.error('Error updating notes:', error);
      toast({
        title: "Error",
        description: "Failed to update call notes.",
        variant: "destructive"
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-700 border-green-300';
      case 'dropped': return 'bg-red-100 text-red-700 border-red-300';
      case 'active': return 'bg-blue-100 text-blue-700 border-blue-300';
      case 'queued': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'platinum': return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'gold': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'silver': return 'bg-gray-100 text-gray-700 border-gray-300';
      default: return 'bg-green-100 text-green-700 border-green-300';
    }
  };

  return (
    <div className="space-y-6">
      {/* Call Overview */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Call Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Status</span>
              <Badge variant="outline" className={getStatusColor(call.status)}>
                {call.status}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Type</span>
              <Badge variant="outline" className="text-xs">
                {call.call_type}
              </Badge>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Duration</span>
              <span className="font-mono">{formatDuration(call.duration || 0)}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Started</span>
              <span className="text-sm">{formatDate(call.created_at)}</span>
            </div>

            {call.sentiment_score && (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">Sentiment</span>
                <Badge variant="outline" className={
                  call.sentiment_score > 0.5 ? 'bg-green-100 text-green-700' :
                  call.sentiment_score > 0 ? 'bg-yellow-100 text-yellow-700' :
                  'bg-red-100 text-red-700'
                }>
                  {call.sentiment_score > 0.5 ? 'Positive' :
                   call.sentiment_score > 0 ? 'Neutral' : 'Negative'}
                </Badge>
              </div>
            )}

            {call.intent && (
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-600">Intent</span>
                <Badge variant="outline" className="text-xs capitalize">
                  {call.intent}
                </Badge>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Customer Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Name</label>
              <p className="font-medium">
                {call.customers?.first_name && call.customers?.last_name 
                  ? `${call.customers.first_name} ${call.customers.last_name}`
                  : 'Unknown Caller'
                }
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">Phone</label>
              <p className="font-mono">{call.customers?.phone_number || 'No phone'}</p>
            </div>

            {call.customers?.email && (
              <div>
                <label className="text-sm font-medium text-gray-600">Email</label>
                <p>{call.customers.email}</p>
              </div>
            )}

            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Tier</span>
              <Badge variant="outline" className={getTierColor(call.customers?.tier || 'bronze')}>
                {call.customers?.tier || 'bronze'}
              </Badge>
            </div>

            <div>
              <label className="text-sm font-medium text-gray-600">Agent</label>
              <p>
                {call.profiles?.first_name && call.profiles?.last_name
                  ? `${call.profiles.first_name} ${call.profiles.last_name}`
                  : 'AI Agent'
                }
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Separator />

      {/* Call Timeline */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Call Timeline
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <div>
                <p className="font-medium">Call Initiated</p>
                <p className="text-sm text-gray-600">{formatDate(call.created_at)}</p>
              </div>
            </div>
            
            {call.status === 'completed' && (
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <div>
                  <p className="font-medium">Call Completed</p>
                  <p className="text-sm text-gray-600">
                    Duration: {formatDuration(call.duration || 0)}
                  </p>
                </div>
              </div>
            )}

            {call.status === 'dropped' && (
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div>
                  <p className="font-medium">Call Dropped</p>
                  <p className="text-sm text-gray-600">Call ended unexpectedly</p>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Call Notes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Call Notes & Transcript
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Add call notes, observations, or transcript..."
            className="min-h-[150px]"
          />
          <div className="flex justify-end">
            <Button 
              onClick={updateCallNotes}
              disabled={isUpdating}
              size="sm"
            >
              {isUpdating ? 'Saving...' : 'Save Notes'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <PhoneCall className="w-4 h-4 mr-2" />
              Schedule Callback
            </Button>
            <Button variant="outline" size="sm">
              <Calendar className="w-4 h-4 mr-2" />
              Set Reminder
            </Button>
            <Button variant="outline" size="sm">
              <Tag className="w-4 h-4 mr-2" />
              Add Tags
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CallDetailModal;
