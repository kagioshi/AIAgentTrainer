
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Settings, Save, Plus, Trash2, Users, Clock, Shield } from 'lucide-react';

interface QueueRule {
  id: string;
  name: string;
  condition: string;
  action: string;
  priority: number;
  isActive: boolean;
}

const QueueRules = () => {
  const [rules, setRules] = useState<QueueRule[]>([
    {
      id: '1',
      name: 'VIP Customer Priority',
      condition: 'Customer Tier = Platinum',
      action: 'Move to Front',
      priority: 1,
      isActive: true
    },
    {
      id: '2',
      name: 'Long Wait Escalation',
      condition: 'Wait Time > 5 minutes',
      action: 'Escalate to Supervisor',
      priority: 2,
      isActive: true
    }
  ]);

  const [generalSettings, setGeneralSettings] = useState({
    maxQueueSize: 50,
    maxWaitTime: 10,
    enableCallback: true,
    enableEstimates: true,
    autoAssignment: true,
    skillBasedRouting: false
  });

  const addNewRule = () => {
    const newRule: QueueRule = {
      id: Date.now().toString(),
      name: 'New Rule',
      condition: '',
      action: '',
      priority: rules.length + 1,
      isActive: false
    };
    setRules([...rules, newRule]);
  };

  const deleteRule = (ruleId: string) => {
    setRules(rules.filter(rule => rule.id !== ruleId));
  };

  const toggleRule = (ruleId: string) => {
    setRules(rules.map(rule => 
      rule.id === ruleId ? { ...rule, isActive: !rule.isActive } : rule
    ));
  };

  const saveSettings = () => {
    console.log('Saving queue rules and settings...');
  };

  return (
    <div className="space-y-6">
      {/* General Queue Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            General Queue Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="maxQueueSize">Maximum Queue Size</Label>
              <Input
                id="maxQueueSize"
                type="number"
                value={generalSettings.maxQueueSize}
                onChange={(e) => setGeneralSettings({
                  ...generalSettings,
                  maxQueueSize: parseInt(e.target.value)
                })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="maxWaitTime">Maximum Wait Time (minutes)</Label>
              <Input
                id="maxWaitTime"
                type="number"
                value={generalSettings.maxWaitTime}
                onChange={(e) => setGeneralSettings({
                  ...generalSettings,
                  maxWaitTime: parseInt(e.target.value)
                })}
              />
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h4 className="text-sm font-medium">Queue Features</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="enableCallback">Enable Callback Options</Label>
                <Switch
                  id="enableCallback"
                  checked={generalSettings.enableCallback}
                  onCheckedChange={(checked) => setGeneralSettings({
                    ...generalSettings,
                    enableCallback: checked
                  })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="enableEstimates">Show Wait Time Estimates</Label>
                <Switch
                  id="enableEstimates"
                  checked={generalSettings.enableEstimates}
                  onCheckedChange={(checked) => setGeneralSettings({
                    ...generalSettings,
                    enableEstimates: checked
                  })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="autoAssignment">Auto-assign Calls</Label>
                <Switch
                  id="autoAssignment"
                  checked={generalSettings.autoAssignment}
                  onCheckedChange={(checked) => setGeneralSettings({
                    ...generalSettings,
                    autoAssignment: checked
                  })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="skillBasedRouting">Skill-based Routing</Label>
                <Switch
                  id="skillBasedRouting"
                  checked={generalSettings.skillBasedRouting}
                  onCheckedChange={(checked) => setGeneralSettings({
                    ...generalSettings,
                    skillBasedRouting: checked
                  })}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Queue Rules */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Queue Rules & Priorities
            </CardTitle>
            <Button onClick={addNewRule}>
              <Plus className="w-4 h-4 mr-2" />
              Add Rule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rules.map((rule, index) => (
              <div key={rule.id} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">#{rule.priority}</Badge>
                    <h4 className="font-medium">{rule.name}</h4>
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={() => toggleRule(rule.id)}
                    />
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteRule(rule.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Rule Name</Label>
                    <Input
                      value={rule.name}
                      onChange={(e) => {
                        const updatedRules = rules.map(r => 
                          r.id === rule.id ? { ...r, name: e.target.value } : r
                        );
                        setRules(updatedRules);
                      }}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Condition</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="tier-platinum">Customer Tier = Platinum</SelectItem>
                        <SelectItem value="tier-gold">Customer Tier = Gold</SelectItem>
                        <SelectItem value="wait-time">Wait Time greater than X minutes</SelectItem>
                        <SelectItem value="call-type">Call Type = Emergency</SelectItem>
                        <SelectItem value="agent-skills">Agent Skills Match</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Action</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select action" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="move-front">Move to Front</SelectItem>
                        <SelectItem value="escalate">Escalate to Supervisor</SelectItem>
                        <SelectItem value="callback">Offer Callback</SelectItem>
                        <SelectItem value="route-skilled">Route to Skilled Agent</SelectItem>
                        <SelectItem value="priority-queue">Priority Queue</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={saveSettings}>
          <Save className="w-4 h-4 mr-2" />
          Save Queue Configuration
        </Button>
      </div>
    </div>
  );
};

export default QueueRules;
