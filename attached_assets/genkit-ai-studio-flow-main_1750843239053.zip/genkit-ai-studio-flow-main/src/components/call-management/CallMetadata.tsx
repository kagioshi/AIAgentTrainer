
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CallWithRelations } from '@/types/database';

interface CallMetadataProps {
  call: CallWithRelations;
}

const CallMetadata: React.FC<CallMetadataProps> = ({ call }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Call Metadata</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <label className="font-medium text-gray-600">Call Type</label>
            <p>{call.call_type}</p>
          </div>
          <div>
            <label className="font-medium text-gray-600">Status</label>
            <Badge variant="outline" className="ml-2">
              {call.status}
            </Badge>
          </div>
          {call.sentiment_score && (
            <div>
              <label className="font-medium text-gray-600">Sentiment Score</label>
              <p>{(call.sentiment_score * 100).toFixed(1)}%</p>
            </div>
          )}
          {call.intent && (
            <div>
              <label className="font-medium text-gray-600">Detected Intent</label>
              <p className="capitalize">{call.intent}</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CallMetadata;
