
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Phone, 
  Clock, 
  Users, 
  TrendingUp, 
  AlertCircle, 
  Settings,
  BarChart3,
  Filter
} from 'lucide-react';
import QueueStatus from './QueueStatus';
import QueueRules from './QueueRules';
import QueueAnalytics from './QueueAnalytics';
import QueueOverflow from './QueueOverflow';

const QueueDashboard = () => {
  const [activeTab, setActiveTab] = useState('status');
  const [queueStats, setQueueStats] = useState({
    totalInQueue: 0,
    avgWaitTime: '0:00',
    longestWait: '0:00',
    availableAgents: 0
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Call Queue Management</h2>
          <p className="text-gray-600">Monitor and manage your call queue in real-time</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filter Queue
          </Button>
          <Button>
            <Settings className="w-4 h-4 mr-2" />
            Queue Settings
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{queueStats.totalInQueue}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Users className="w-4 h-4" />
              In Queue
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{queueStats.avgWaitTime}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Clock className="w-4 h-4" />
              Avg Wait
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">{queueStats.longestWait}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <AlertCircle className="w-4 h-4" />
              Longest Wait
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{queueStats.availableAgents}</div>
            <div className="text-sm text-gray-600 flex items-center justify-center gap-1">
              <Phone className="w-4 h-4" />
              Available
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="status" className="flex items-center gap-2">
            <Phone className="w-4 h-4" />
            Queue Status
          </TabsTrigger>
          <TabsTrigger value="rules" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Queue Rules
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="overflow" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Overflow
          </TabsTrigger>
        </TabsList>

        <TabsContent value="status" className="space-y-6">
          <QueueStatus />
        </TabsContent>

        <TabsContent value="rules" className="space-y-6">
          <QueueRules />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <QueueAnalytics />
        </TabsContent>

        <TabsContent value="overflow" className="space-y-6">
          <QueueOverflow />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QueueDashboard;
