
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CallQueue from './CallQueue';
import ActiveCalls from './ActiveCalls';
import AgentStatus from './AgentStatus';
import CallHistoryDashboard from './CallHistoryDashboard';
import CallAnalytics from './CallAnalytics';
import { Button } from "@/components/ui/button";
import { PhoneCall, UserPlus, History, BarChart3, Phone, Users } from 'lucide-react';

const CallManagementDashboard = () => {
  const [activeTab, setActiveTab] = useState('live');

  const handleStartOutboundCall = () => {
    // TODO: Implement outbound call functionality
    console.log('Starting outbound call...');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Call Management</h2>
        <div className="flex gap-3">
          <Button onClick={handleStartOutboundCall}>
            <PhoneCall className="w-4 h-4 mr-2" />
            Start Outbound Call
          </Button>
          <Button variant="outline">
            <UserPlus className="w-4 h-4 mr-2" />
            Add Customer
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="live" className="flex items-center gap-2">
            <Phone className="w-4 h-4" />
            Live Calls
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <History className="w-4 h-4" />
            Call History
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="live" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              <CallQueue />
              <ActiveCalls />
            </div>
            <div>
              <AgentStatus />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <CallHistoryDashboard />
        </TabsContent>

        <TabsContent value="analytics">
          <CallAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CallManagementDashboard;
