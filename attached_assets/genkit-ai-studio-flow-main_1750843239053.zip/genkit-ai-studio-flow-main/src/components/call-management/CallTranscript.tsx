
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText } from 'lucide-react';

interface CallTranscriptProps {
  transcript: string;
  callId: string;
}

const CallTranscript: React.FC<CallTranscriptProps> = ({ transcript, callId }) => {
  const exportTranscript = () => {
    const blob = new Blob([transcript], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `call-transcript-${callId}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Call Transcript
          </CardTitle>
          <Button variant="outline" size="sm" onClick={exportTranscript}>
            <FileText className="w-4 h-4 mr-2" />
            Export Transcript
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="bg-gray-50 rounded-lg p-4 max-h-60 overflow-y-auto">
          <p className="text-sm leading-relaxed whitespace-pre-wrap">
            {transcript}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default CallTranscript;
