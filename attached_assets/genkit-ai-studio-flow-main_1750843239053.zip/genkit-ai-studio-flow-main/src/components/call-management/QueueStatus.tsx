
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Phone, Clock, User, ArrowUp, ArrowDown, Play, Pause } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { CallWithRelations } from '@/types/database';

const QueueStatus = () => {
  const [queuedCalls, setQueuedCalls] = useState<CallWithRelations[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    fetchQueuedCalls();

    const channel = supabase
      .channel('queue-status')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'calls'
      }, () => {
        fetchQueuedCalls();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchQueuedCalls = async () => {
    try {
      const { data, error } = await supabase
        .from('calls')
        .select(`
          *,
          customers (first_name, last_name, phone_number, email, tier),
          profiles (first_name, last_name, role)
        `)
        .eq('status', 'queued')
        .order('created_at', { ascending: true });

      if (error) throw error;
      setQueuedCalls(data || []);
    } catch (error) {
      console.error('Error fetching queued calls:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const assignCall = async (callId: string) => {
    try {
      const { error } = await supabase
        .from('calls')
        .update({ 
          status: 'active',
          agent_id: (await supabase.auth.getUser()).data.user?.id
        })
        .eq('id', callId);

      if (error) throw error;
    } catch (error) {
      console.error('Error assigning call:', error);
    }
  };

  const changePriority = async (callId: string, direction: 'up' | 'down') => {
    // TODO: Implement priority management
    console.log(`Moving call ${callId} priority ${direction}`);
  };

  const getPriorityColor = (tier: string) => {
    switch (tier) {
      case 'platinum': return 'border-l-purple-500 bg-purple-50';
      case 'gold': return 'border-l-yellow-500 bg-yellow-50';
      case 'silver': return 'border-l-gray-400 bg-gray-50';
      default: return 'border-l-green-500 bg-green-50';
    }
  };

  const getWaitTime = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    const hours = Math.floor(diffInMinutes / 60);
    const minutes = diffInMinutes % 60;
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
  };

  const toggleQueuePause = () => {
    setIsPaused(!isPaused);
    // TODO: Implement queue pause functionality
  };

  if (isLoading) {
    return (
      <div className="text-center py-8 text-gray-500">Loading queue status...</div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Live Queue Status ({queuedCalls.length} calls)
            </CardTitle>
            <Button 
              variant={isPaused ? "default" : "outline"}
              onClick={toggleQueuePause}
              className="flex items-center gap-2"
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              {isPaused ? 'Resume Queue' : 'Pause Queue'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {queuedCalls.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Phone className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No calls in queue</p>
              <p className="text-sm">All caught up! Great work.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {queuedCalls.map((call, index) => (
                <div 
                  key={call.id}
                  className={`p-4 rounded-lg border-l-4 ${getPriorityColor(call.customers?.tier || 'bronze')} hover:bg-gray-50 transition-colors`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-gray-900">#{index + 1}</div>
                        <div className="text-xs text-gray-500">Position</div>
                      </div>
                      
                      <Avatar className="h-10 w-10">
                        <AvatarFallback>
                          {call.customers?.first_name?.[0] || call.customers?.phone_number?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div>
                        <div className="font-medium text-gray-900">
                          {call.customers?.first_name && call.customers?.last_name 
                            ? `${call.customers.first_name} ${call.customers.last_name}`
                            : 'Unknown Caller'
                          }
                        </div>
                        <div className="text-sm text-gray-600">
                          {call.customers?.phone_number || 'No phone'}
                        </div>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs capitalize">
                            {call.customers?.tier || 'bronze'}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {call.call_type}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-orange-600 font-medium">
                          <Clock className="w-4 h-4" />
                          {getWaitTime(call.created_at)}
                        </div>
                        <div className="text-xs text-gray-500">Wait Time</div>
                      </div>
                      
                      <div className="flex flex-col gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => changePriority(call.id, 'up')}
                          disabled={index === 0}
                        >
                          <ArrowUp className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => changePriority(call.id, 'down')}
                          disabled={index === queuedCalls.length - 1}
                        >
                          <ArrowDown className="w-3 h-3" />
                        </Button>
                      </div>
                      
                      <Button 
                        size="sm" 
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => assignCall(call.id)}
                      >
                        <Phone className="w-4 h-4 mr-1" />
                        Take Call
                      </Button>
                    </div>
                  </div>
                  
                  {call.customers?.email && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="text-sm text-gray-600">
                        <strong>Email:</strong> {call.customers.email}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default QueueStatus;
