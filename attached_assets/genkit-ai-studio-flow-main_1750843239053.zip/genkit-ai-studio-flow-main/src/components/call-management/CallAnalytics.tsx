
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, TrendingUp, TrendingDown, Clock, Phone, Users, Target } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface AnalyticsData {
  totalCalls: number;
  completedCalls: number;
  droppedCalls: number;
  avgDuration: number;
  avgSentiment: number;
  callsByType: { inbound: number; outbound: number };
  callsByTier: { bronze: number; silver: number; gold: number; platinum: number };
  hourlyDistribution: number[];
  agentPerformance: Array<{
    agentId: string;
    agentName: string;
    callCount: number;
    avgDuration: number;
    completionRate: number;
  }>;
}

const CallAnalytics = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [timeRange, setTimeRange] = useState('week');

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    try {
      setIsLoading(true);
      
      // Calculate date range
      const now = new Date();
      let startDate = new Date();
      
      switch (timeRange) {
        case 'today':
          startDate.setHours(0, 0, 0, 0);
          break;
        case 'week':
          startDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          startDate.setMonth(now.getMonth() - 1);
          break;
        case 'quarter':
          startDate.setMonth(now.getMonth() - 3);
          break;
      }

      // Fetch calls data
      const { data: calls, error } = await supabase
        .from('calls')
        .select(`
          *,
          customers (tier),
          profiles (first_name, last_name)
        `)
        .gte('created_at', startDate.toISOString());

      if (error) throw error;

      // Process analytics data
      const totalCalls = calls?.length || 0;
      const completedCalls = calls?.filter(call => call.status === 'completed').length || 0;
      const droppedCalls = calls?.filter(call => call.status === 'dropped').length || 0;
      
      const avgDuration = calls?.reduce((sum, call) => sum + (call.duration || 0), 0) / totalCalls || 0;
      const avgSentiment = calls?.reduce((sum, call) => sum + (call.sentiment_score || 0), 0) / totalCalls || 0;

      // Calls by type
      const inboundCalls = calls?.filter(call => call.call_type === 'inbound').length || 0;
      const outboundCalls = calls?.filter(call => call.call_type === 'outbound').length || 0;

      // Calls by tier
      const callsByTier = calls?.reduce((acc, call) => {
        const tier = call.customers?.tier || 'bronze';
        acc[tier as keyof typeof acc] = (acc[tier as keyof typeof acc] || 0) + 1;
        return acc;
      }, { bronze: 0, silver: 0, gold: 0, platinum: 0 }) || { bronze: 0, silver: 0, gold: 0, platinum: 0 };

      // Hourly distribution
      const hourlyDistribution = Array(24).fill(0);
      calls?.forEach(call => {
        const hour = new Date(call.created_at).getHours();
        hourlyDistribution[hour]++;
      });

      // Agent performance
      const agentStats = calls?.reduce((acc, call) => {
        const agentId = call.agent_id || 'ai-agent';
        const agentName = call.profiles?.first_name && call.profiles?.last_name 
          ? `${call.profiles.first_name} ${call.profiles.last_name}`
          : 'AI Agent';
        
        if (!acc[agentId]) {
          acc[agentId] = {
            agentId,
            agentName,
            callCount: 0,
            totalDuration: 0,
            completedCalls: 0
          };
        }
        
        acc[agentId].callCount++;
        acc[agentId].totalDuration += call.duration || 0;
        if (call.status === 'completed') {
          acc[agentId].completedCalls++;
        }
        
        return acc;
      }, {} as any) || {};

      const agentPerformance = Object.values(agentStats).map((agent: any) => ({
        agentId: agent.agentId,
        agentName: agent.agentName,
        callCount: agent.callCount,
        avgDuration: agent.totalDuration / agent.callCount,
        completionRate: (agent.completedCalls / agent.callCount) * 100
      }));

      setAnalytics({
        totalCalls,
        completedCalls,
        droppedCalls,
        avgDuration,
        avgSentiment,
        callsByType: { inbound: inboundCalls, outbound: outboundCalls },
        callsByTier,
        hourlyDistribution,
        agentPerformance
      });

    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getCompletionRate = () => {
    if (!analytics || analytics.totalCalls === 0) return 0;
    return (analytics.completedCalls / analytics.totalCalls) * 100;
  };

  const getDropRate = () => {
    if (!analytics || analytics.totalCalls === 0) return 0;
    return (analytics.droppedCalls / analytics.totalCalls) * 100;
  };

  if (isLoading || !analytics) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Call Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">Loading analytics...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Call Analytics</h2>
        <select 
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md"
        >
          <option value="today">Today</option>
          <option value="week">Last Week</option>
          <option value="month">Last Month</option>
          <option value="quarter">Last Quarter</option>
        </select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Calls</p>
                <p className="text-2xl font-bold">{analytics.totalCalls}</p>
              </div>
              <Phone className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                <p className="text-2xl font-bold">{getCompletionRate().toFixed(1)}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Drop Rate</p>
                <p className="text-2xl font-bold">{getDropRate().toFixed(1)}%</p>
              </div>
              <TrendingDown className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Duration</p>
                <p className="text-2xl font-bold">{formatDuration(analytics.avgDuration)}</p>
              </div>
              <Clock className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Call Distribution */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Call Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Inbound</span>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{analytics.callsByType.inbound}</Badge>
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ 
                        width: `${(analytics.callsByType.inbound / analytics.totalCalls) * 100}%` 
                      }}
                    ></div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Outbound</span>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{analytics.callsByType.outbound}</Badge>
                  <div className="w-24 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full"
                      style={{ 
                        width: `${(analytics.callsByType.outbound / analytics.totalCalls) * 100}%` 
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customer Tiers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(analytics.callsByTier).map(([tier, count]) => (
                <div key={tier} className="flex items-center justify-between">
                  <span className="text-sm font-medium capitalize">{tier}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{count}</Badge>
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          tier === 'platinum' ? 'bg-purple-600' :
                          tier === 'gold' ? 'bg-yellow-600' :
                          tier === 'silver' ? 'bg-gray-600' : 'bg-green-600'
                        }`}
                        style={{ 
                          width: `${(count / analytics.totalCalls) * 100}%` 
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Agent Performance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Agent Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics.agentPerformance.map((agent) => (
              <div key={agent.agentId} className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium">{agent.agentName}</p>
                  <p className="text-sm text-gray-600">{agent.callCount} calls</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{agent.completionRate.toFixed(1)}% completion</p>
                  <p className="text-sm text-gray-600">Avg: {formatDuration(agent.avgDuration)}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Sentiment Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Call Quality Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">
                {(analytics.avgSentiment * 100).toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600">Average Sentiment</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">
                {getCompletionRate().toFixed(1)}%
              </p>
              <p className="text-sm text-gray-600">Success Rate</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-orange-600">
                {formatDuration(analytics.avgDuration)}
              </p>
              <p className="text-sm text-gray-600">Average Handle Time</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CallAnalytics;
