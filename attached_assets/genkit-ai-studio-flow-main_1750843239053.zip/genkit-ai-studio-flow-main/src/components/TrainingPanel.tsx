
import React, { useState, useEffect } from 'react';
import { Play, Pause, Square, Download, Upload, Settings } from 'lucide-react';

const TrainingPanel = () => {
  const [isTraining, setIsTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [epoch, setEpoch] = useState(0);
  const [loss, setLoss] = useState(2.45);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isTraining) {
      interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = Math.min(prev + Math.random() * 2, 100);
          if (newProgress >= 100) {
            setIsTraining(false);
            return 100;
          }
          return newProgress;
        });
        setEpoch(prev => prev + 1);
        setLoss(prev => Math.max(0.1, prev - Math.random() * 0.05));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTraining]);

  const handleStartTraining = () => {
    setIsTraining(true);
    setProgress(0);
    setEpoch(0);
    setLoss(2.45);
  };

  const handleStopTraining = () => {
    setIsTraining(false);
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <h3 className="text-xl font-semibold text-white mb-6">Training Controls</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Learning Rate</label>
            <input
              type="number"
              step="0.0001"
              defaultValue="0.001"
              className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Batch Size</label>
            <select className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option value="16">16</option>
              <option value="32">32</option>
              <option value="64">64</option>
              <option value="128">128</option>
            </select>
          </div>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Epochs</label>
            <input
              type="number"
              defaultValue="100"
              className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">Optimizer</label>
            <select className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option value="adam">Adam</option>
              <option value="sgd">SGD</option>
              <option value="rmsprop">RMSprop</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex gap-3 mb-6">
        <button
          onClick={isTraining ? handleStopTraining : handleStartTraining}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
            isTraining 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
          }`}
        >
          {isTraining ? <Square className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          {isTraining ? 'Stop Training' : 'Start Training'}
        </button>
        
        <button className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors">
          <Upload className="w-4 h-4" />
          Upload Dataset
        </button>
        
        <button className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors">
          <Settings className="w-4 h-4" />
          Advanced
        </button>
      </div>

      {(isTraining || progress > 0) && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-gray-300">Training Progress</span>
            <span className="text-white font-medium">{progress.toFixed(1)}%</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-3">
            <div 
              className="bg-gradient-to-r from-green-500 to-blue-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="bg-white/5 rounded-lg p-3">
              <div className="text-sm text-gray-300">Current Epoch</div>
              <div className="text-lg font-semibold text-white">{epoch}</div>
            </div>
            <div className="bg-white/5 rounded-lg p-3">
              <div className="text-sm text-gray-300">Loss</div>
              <div className="text-lg font-semibold text-white">{loss.toFixed(3)}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TrainingPanel;
