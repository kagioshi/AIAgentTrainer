
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { CheckCircle, X } from 'lucide-react';
import { ValidationResult } from './types';

interface ValidationResultsTableProps {
  results: ValidationResult[];
}

const ValidationResultsTable = ({ results }: ValidationResultsTableProps) => {
  return (
    <div className="max-h-96 overflow-auto border rounded-lg">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Status</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Tier</TableHead>
            <TableHead>Errors</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {results.map((result, index) => (
            <TableRow key={index} className={result.valid ? '' : 'bg-red-50'}>
              <TableCell>
                {result.valid ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <X className="w-4 h-4 text-red-500" />
                )}
              </TableCell>
              <TableCell>{result.data.phone_number}</TableCell>
              <TableCell>
                {result.data.first_name && result.data.last_name
                  ? `${result.data.first_name} ${result.data.last_name}`
                  : '-'}
              </TableCell>
              <TableCell>{result.data.email || '-'}</TableCell>
              <TableCell>{result.data.tier || 'bronze'}</TableCell>
              <TableCell>
                {result.errors.length > 0 && (
                  <div className="text-red-600 text-sm">
                    {result.errors.join(', ')}
                  </div>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default ValidationResultsTable;
