
import { RawCustomerFromCsv, ValidationResult } from './types';

export const validateCustomer = (customer: RawCustomerFromCsv): ValidationResult => {
  const errors: string[] = [];
  
  if (!customer.phone_number?.trim()) {
    errors.push('Phone number is required');
  } else if (!/^\+?[\d\s\-\(\)]+$/.test(customer.phone_number.trim())) {
    errors.push('Invalid phone number format');
  }
  
  if (customer.email && !/\S+@\S+\.\S+/.test(customer.email.trim())) {
    errors.push('Invalid email format');
  }
  
  if (customer.tier && !['bronze', 'silver', 'gold', 'platinum'].includes(customer.tier.toLowerCase())) {
    errors.push('Tier must be bronze, silver, gold, or platinum');
  }

  return {
    valid: errors.length === 0,
    errors,
    data: {
      phone_number: customer.phone_number?.trim() || '',
      email: customer.email?.trim() || undefined,
      first_name: customer.first_name?.trim() || undefined,
      last_name: customer.last_name?.trim() || undefined,
      tier: customer.tier?.toLowerCase() || 'bronze',
      notes: customer.notes?.trim() || undefined,
      tags: typeof customer.tags === 'string'
        ? customer.tags.split(',').map(tag => tag.trim()).filter(Boolean)
        : undefined,
      preferred_contact_method: customer.preferred_contact_method?.toLowerCase() || 'phone'
    }
  };
};

export const downloadTemplate = () => {
    const template = 'phone_number,email,first_name,last_name,tier,notes,tags,preferred_contact_method\n+1234567890,john@example.com,John,Doe,gold,VIP customer,"urgent,priority",email';
    const blob = new Blob([template], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'customer_import_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };
