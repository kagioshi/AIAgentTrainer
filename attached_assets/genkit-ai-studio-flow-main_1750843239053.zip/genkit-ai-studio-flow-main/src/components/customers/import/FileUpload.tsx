
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Download } from 'lucide-react';
import { downloadTemplate } from './utils';

interface FileUploadProps {
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

const FileUpload = ({ onFileUpload }: FileUploadProps) => {
  return (
    <div className="flex items-center gap-4">
      <Input
        type="file"
        accept=".csv"
        onChange={onFileUpload}
        className="flex-1"
      />
      <Button variant="outline" onClick={downloadTemplate}>
        <Download className="w-4 h-4 mr-2" />
        Download Template
      </Button>
    </div>
  );
};

export default FileUpload;
