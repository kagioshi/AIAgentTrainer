
export interface ImportCustomer {
  phone_number: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  tier?: string;
  notes?: string;
  tags?: string[];
  preferred_contact_method?: string;
}

// Represents raw data parsed from CSV before validation
export interface RawCustomerFromCsv {
  phone_number?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  tier?: string;
  notes?: string;
  tags?: string; // In CSV, tags are a single comma-separated string
  preferred_contact_method?: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  data: ImportCustomer;
}
