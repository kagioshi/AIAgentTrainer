import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload, AlertCircle, CheckCircle } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { customerService } from '@/services/customerService';
import { toast } from 'sonner';
import { ValidationResult, RawCustomerFromCsv } from './import/types';
import { validateCustomer } from './import/utils';
import FileUpload from './import/FileUpload';
import ValidationResultsTable from './import/ValidationResultsTable';

const CustomerImport = ({ onClose }: { onClose: () => void }) => {
  const [validationResults, setValidationResults] = useState<ValidationResult[]>([]);
  const queryClient = useQueryClient();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        toast.error('CSV file must have at least a header row and one data row');
        return;
      }

      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      const requiredHeaders = ['phone_number'];
      const missingHeaders = requiredHeaders.filter(h => !headers.includes(h));
      
      if (missingHeaders.length > 0) {
        toast.error(`Missing required headers: ${missingHeaders.join(', ')}`);
        return;
      }

      const customers = lines.slice(1).map((line) => {
        const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
        const customer: any = {};
        
        headers.forEach((header, i) => {
          if (values[i]) {
            customer[header] = values[i];
          }
        });
        
        return customer as RawCustomerFromCsv;
      });

      const results = customers.map(validateCustomer);
      setValidationResults(results);
    };
    
    reader.readAsText(file);
  };

  const importCustomers = useMutation({
    mutationFn: async () => {
      const validCustomers = validationResults
        .filter(result => result.valid)
        .map(result => result.data);

      const promises = validCustomers.map(customer => 
        customerService.createCustomer({
          ...customer,
          tags: customer.tags || undefined
        })
      );

      return Promise.all(promises);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      toast.success(`Successfully imported ${data.length} customers`);
      onClose();
    },
    onError: (error) => {
      console.error('Import error:', error);
      toast.error('Failed to import customers');
    }
  });

  const validCount = validationResults.filter(r => r.valid).length;
  const errorCount = validationResults.filter(r => !r.valid).length;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Import Customers from CSV
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <FileUpload onFileUpload={handleFileUpload} />

          {validationResults.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Badge variant={validCount > 0 ? "default" : "secondary"}>
                  <CheckCircle className="w-3 h-3 mr-1" />
                  {validCount} Valid
                </Badge>
                <Badge variant={errorCount > 0 ? "destructive" : "secondary"}>
                  <AlertCircle className="w-3 h-3 mr-1" />
                  {errorCount} Errors
                </Badge>
              </div>

              <ValidationResultsTable results={validationResults} />

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  onClick={() => importCustomers.mutate()}
                  disabled={validCount === 0 || importCustomers.isPending}
                >
                  {importCustomers.isPending ? 'Importing...' : `Import ${validCount} Customers`}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerImport;
