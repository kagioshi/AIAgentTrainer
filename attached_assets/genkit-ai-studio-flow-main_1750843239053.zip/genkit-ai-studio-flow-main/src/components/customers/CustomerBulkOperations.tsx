
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users } from 'lucide-react';
import { toast } from 'sonner';

import { CustomerBulkOperationsProps, BulkAction, BulkUpdateData } from './bulk/types';
import { useBulkOperations } from './bulk/hooks/useBulkOperations';
import { exportCustomersToCsv } from './bulk/utils';
import CustomerSelectionControls from './bulk/CustomerSelectionControls';
import CustomerListView from './bulk/CustomerListView';
import BulkActionPanel from './bulk/BulkActionPanel';

const CustomerBulkOperations = ({ customers, onClose }: CustomerBulkOperationsProps) => {
  const [selectedCustomers, setSelectedCustomers] = useState<Set<string>>(new Set());
  const [bulkAction, setBulkAction] = useState<BulkAction>('');
  const [bulkUpdateData, setBulkUpdateData] = useState<BulkUpdateData>({
    tier: '',
    status: '',
    tags: '',
    notes: ''
  });

  const resetStateAndClose = () => {
    setSelectedCustomers(new Set());
    setBulkAction('');
    onClose();
  };

  const { bulkUpdateMutation, bulkDeleteMutation } = useBulkOperations(selectedCustomers, resetStateAndClose);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCustomers(new Set(customers.map(c => c.id)));
    } else {
      setSelectedCustomers(new Set());
    }
  };

  const handleSelectCustomer = (customerId: string, checked: boolean) => {
    const newSelected = new Set(selectedCustomers);
    if (checked) {
      newSelected.add(customerId);
    } else {
      newSelected.delete(customerId);
    }
    setSelectedCustomers(newSelected);
  };

  const handleBulkAction = () => {
    if (selectedCustomers.size === 0) {
      toast.error('Please select customers first');
      return;
    }

    switch (bulkAction) {
      case 'delete':
        if (confirm(`Are you sure you want to mark ${selectedCustomers.size} customers as inactive?`)) {
          bulkDeleteMutation.mutate();
        }
        break;
      case 'update':
        const { tier, status, notes, tags } = bulkUpdateData;
        const updates = { tier, status, notes, tags };
        bulkUpdateMutation.mutate(updates);
        break;
      case 'export':
        exportCustomersToCsv(customers, selectedCustomers);
        break;
    }
  };

  const isProcessing = bulkUpdateMutation.isPending || bulkDeleteMutation.isPending;
  const isActionDisabled = selectedCustomers.size === 0 || !bulkAction || isProcessing;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users />
            Bulk Customer Operations
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <CustomerSelectionControls
            selectedCount={selectedCustomers.size}
            totalCount={customers.length}
            onSelectAll={handleSelectAll}
          />

          <CustomerListView
            customers={customers}
            selectedCustomers={selectedCustomers}
            onSelectCustomer={handleSelectCustomer}
          />

          <BulkActionPanel
            bulkAction={bulkAction}
            setBulkAction={setBulkAction}
            bulkUpdateData={bulkUpdateData}
            setBulkUpdateData={setBulkUpdateData}
            handleBulkAction={handleBulkAction}
            isActionDisabled={isActionDisabled}
            isProcessing={isProcessing}
          />

          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerBulkOperations;
