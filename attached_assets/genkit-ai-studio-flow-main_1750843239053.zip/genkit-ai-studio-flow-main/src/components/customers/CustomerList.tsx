
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useBusiness } from '@/hooks/useBusiness';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, Plus, Phone, Mail, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';

interface Customer {
  id: string;
  phone_number: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  tier?: string;
  status?: string;
  tags?: string[];
  notes?: string;
  last_contact_date?: string;
  preferred_contact_method?: string;
  created_at: string;
}

export const CustomerList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { business } = useBusiness();
  const queryClient = useQueryClient();

  const { data: customers, isLoading } = useQuery({
    queryKey: ['customers', business?.id],
    queryFn: async () => {
      if (!business?.id) return [];
      
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .eq('business_id', business.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Customer[];
    },
    enabled: !!business?.id,
  });

  const deleteCustomer = useMutation({
    mutationFn: async (customerId: string) => {
      const { error } = await supabase
        .from('customers')
        .delete()
        .eq('id', customerId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      toast.success('Customer deleted successfully');
    },
    onError: (error) => {
      toast.error('Failed to delete customer');
      console.error('Error deleting customer:', error);
    },
  });

  const filteredCustomers = customers?.filter(customer => {
    const searchLower = searchTerm.toLowerCase();
    return (
      customer.first_name?.toLowerCase().includes(searchLower) ||
      customer.last_name?.toLowerCase().includes(searchLower) ||
      customer.email?.toLowerCase().includes(searchLower) ||
      customer.phone_number.includes(searchTerm)
    );
  }) || [];

  const getTierColor = (tier?: string) => {
    switch (tier) {
      case 'platinum': return 'bg-purple-100 text-purple-800';
      case 'gold': return 'bg-yellow-100 text-yellow-800';
      case 'silver': return 'bg-gray-100 text-gray-800';
      default: return 'bg-orange-100 text-orange-800';
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-gray-500">Loading customers...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Customers</h1>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Customer
        </Button>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="text-sm text-gray-500">
          {filteredCustomers.length} of {customers?.length || 0} customers
        </div>
      </div>

      <div className="grid gap-4">
        {filteredCustomers.map((customer) => (
          <Card key={customer.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-semibold">
                      {customer.first_name?.[0] || customer.phone_number[0]}
                    </span>
                  </div>
                  <div>
                    <CardTitle className="text-lg">
                      {customer.first_name && customer.last_name
                        ? `${customer.first_name} ${customer.last_name}`
                        : customer.phone_number}
                    </CardTitle>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className={getTierColor(customer.tier)}>
                        {customer.tier || 'bronze'}
                      </Badge>
                      <Badge variant={customer.status === 'active' ? 'default' : 'secondary'}>
                        {customer.status || 'active'}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => deleteCustomer.mutate(customer.id)}
                    disabled={deleteCustomer.isPending}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <Phone className="w-4 h-4 mr-2" />
                    {customer.phone_number}
                  </div>
                  {customer.email && (
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="w-4 h-4 mr-2" />
                      {customer.email}
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  {customer.last_contact_date && (
                    <div className="text-sm text-gray-600">
                      Last contact: {new Date(customer.last_contact_date).toLocaleDateString()}
                    </div>
                  )}
                  {customer.preferred_contact_method && (
                    <div className="text-sm text-gray-600">
                      Prefers: {customer.preferred_contact_method}
                    </div>
                  )}
                </div>
              </div>
              {customer.tags && customer.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3">
                  {customer.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
              {customer.notes && (
                <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-700">{customer.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        
        {filteredCustomers.length === 0 && (
          <Card className="p-8 text-center">
            <div className="text-gray-500">
              {searchTerm ? 'No customers found matching your search.' : 'No customers yet. Add your first customer to get started.'}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};
