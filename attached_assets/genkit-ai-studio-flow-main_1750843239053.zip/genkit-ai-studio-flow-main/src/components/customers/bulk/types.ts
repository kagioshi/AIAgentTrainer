
import { CustomerWithStats } from '@/types/database';

export type BulkAction = 'update' | 'delete' | 'export' | '';

export interface BulkUpdateData {
  tier: string;
  status: string;
  tags: string;
  notes: string;
}

export interface CustomerBulkOperationsProps {
  customers: CustomerWithStats[];
  onClose: () => void;
}
