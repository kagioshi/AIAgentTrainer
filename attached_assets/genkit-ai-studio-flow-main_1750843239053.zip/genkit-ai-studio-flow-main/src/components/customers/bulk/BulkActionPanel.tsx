
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Trash2, Edit, Download } from 'lucide-react';
import { BulkAction, BulkUpdateData } from './types';

interface BulkActionPanelProps {
  bulkAction: BulkAction;
  setBulkAction: (action: BulkAction) => void;
  bulkUpdateData: BulkUpdateData;
  setBulkUpdateData: React.Dispatch<React.SetStateAction<BulkUpdateData>>;
  handleBulkAction: () => void;
  isActionDisabled: boolean;
  isProcessing: boolean;
}

const BulkActionPanel = ({
  bulkAction,
  setBulkAction,
  bulkUpdateData,
  setBulkUpdateData,
  handleBulkAction,
  isActionDisabled,
  isProcessing,
}: BulkActionPanelProps) => {
  return (
    <div className="space-y-4 p-4 border rounded-lg">
      <div className="flex items-center gap-4">
        <Select value={bulkAction} onValueChange={(value) => setBulkAction(value as BulkAction)}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="Select action" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="update">
              <div className="flex items-center gap-2">
                <Edit />
                Update Selected
              </div>
            </SelectItem>
            <SelectItem value="delete">
              <div className="flex items-center gap-2">
                <Trash2 />
                Delete Selected
              </div>
            </SelectItem>
            <SelectItem value="export">
              <div className="flex items-center gap-2">
                <Download />
                Export Selected
              </div>
            </SelectItem>
          </SelectContent>
        </Select>

        <Button onClick={handleBulkAction} disabled={isActionDisabled}>
          {isProcessing ? 'Processing...' : 'Execute Action'}
        </Button>
      </div>

      {bulkAction === 'update' && (
        <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
          <div>
            <label className="text-sm font-medium mb-1 block">Tier</label>
            <Select value={bulkUpdateData.tier} onValueChange={(value) => setBulkUpdateData(prev => ({ ...prev, tier: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select tier" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="bronze">Bronze</SelectItem>
                <SelectItem value="silver">Silver</SelectItem>
                <SelectItem value="gold">Gold</SelectItem>
                <SelectItem value="platinum">Platinum</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Status</label>
            <Select value={bulkUpdateData.status} onValueChange={(value) => setBulkUpdateData(prev => ({ ...prev, status: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Tags (comma-separated)</label>
            <Input
              value={bulkUpdateData.tags}
              onChange={(e) => setBulkUpdateData(prev => ({ ...prev, tags: e.target.value }))}
              placeholder="urgent, vip, priority"
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-1 block">Notes</label>
            <Input
              value={bulkUpdateData.notes}
              onChange={(e) => setBulkUpdateData(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Bulk update notes"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default BulkActionPanel;
