
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { CustomerWithStats } from '@/types/database';

interface CustomerListViewProps {
  customers: CustomerWithStats[];
  selectedCustomers: Set<string>;
  onSelectCustomer: (customerId: string, checked: boolean) => void;
}

const CustomerListView = ({ customers, selectedCustomers, onSelectCustomer }: CustomerListViewProps) => {
  return (
    <div className="max-h-96 overflow-auto border rounded-lg">
      <div className="space-y-2 p-4">
        {customers.map((customer) => (
          <div key={customer.id} className="flex items-center gap-3 p-3 border rounded hover:bg-gray-50">
            <Checkbox
              checked={selectedCustomers.has(customer.id)}
              onCheckedChange={(checked) => onSelectCustomer(customer.id, checked as boolean)}
              aria-labelledby={`customer-name-${customer.id}`}
            />
            <div className="flex-1 grid grid-cols-4 gap-4 items-center">
              <div id={`customer-name-${customer.id}`}>
                <div className="font-medium">
                  {customer.first_name || customer.last_name
                    ? `${customer.first_name || ''} ${customer.last_name || ''}`.trim()
                    : 'Unknown Customer'}
                </div>
                <div className="text-sm text-gray-600">{customer.phone_number}</div>
              </div>
              <div className="text-sm text-gray-600 truncate">{customer.email || '-'}</div>
              <Badge variant="outline" className="w-fit">
                {customer.tier || 'bronze'}
              </Badge>
              <Badge variant={customer.status === 'active' ? 'default' : 'secondary'} className="w-fit">
                {customer.status || 'active'}
              </Badge>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomerListView;
