
import React from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';

interface CustomerSelectionControlsProps {
  selectedCount: number;
  totalCount: number;
  onSelectAll: (checked: boolean) => void;
}

const CustomerSelectionControls = ({ selectedCount, totalCount, onSelectAll }: CustomerSelectionControlsProps) => {
  const isAllSelected = selectedCount === totalCount && totalCount > 0;
  
  return (
    <div className="flex items-center gap-4 p-4 border rounded-lg">
      <Checkbox
        checked={isAllSelected}
        onCheckedChange={onSelectAll}
        aria-label="Select all customers"
      />
      <span className="text-sm font-medium">
        Select All ({selectedCount} of {totalCount} selected)
      </span>
      <Badge variant="outline">
        {selectedCount} selected
      </Badge>
    </div>
  );
};

export default CustomerSelectionControls;
