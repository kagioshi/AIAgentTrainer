
import { CustomerWithStats } from '@/types/database';
import { toast } from 'sonner';

export const exportCustomersToCsv = (customers: CustomerWithStats[], selectedCustomers: Set<string>) => {
  const selectedCustomerData = customers.filter(c => selectedCustomers.has(c.id));
  if (selectedCustomerData.length === 0) {
    toast.error("No customers selected for export.");
    return;
  }

  const csvContent = [
    'phone_number,email,first_name,last_name,tier,status,notes,tags,created_at',
    ...selectedCustomerData.map(customer => [
      customer.phone_number,
      customer.email || '',
      customer.first_name || '',
      customer.last_name || '',
      customer.tier || 'bronze',
      customer.status || 'active',
      customer.notes?.replace(/,/g, ';') || '',
      Array.isArray(customer.tags) ? customer.tags.join(';') : '',
      customer.created_at
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `customers_export_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  toast.success(`Exported ${selectedCustomers.size} customers`);
};
