
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const useBulkOperations = (selectedCustomers: Set<string>, onSuccessCallback: () => void) => {
  const queryClient = useQueryClient();

  const bulkUpdateMutation = useMutation({
    mutationFn: async (updates: { tier?: string; status?: string; tags?: string; notes?: string; }) => {
      const customerIds = Array.from(selectedCustomers);
      
      const updatePayload: any = {};
      if (updates.tier) updatePayload.tier = updates.tier;
      if (updates.status) updatePayload.status = updates.status;
      if (updates.notes) updatePayload.notes = updates.notes;
      if (updates.tags) {
        updatePayload.tags = updates.tags.split(',').map(tag => tag.trim()).filter(Boolean);
      }

      if (Object.keys(updatePayload).length === 0) {
        toast.error("Please specify what to update");
        return 0;
      }

      const { error } = await supabase
        .from('customers')
        .update({
          ...updatePayload,
          updated_at: new Date().toISOString()
        })
        .in('id', customerIds);

      if (error) throw error;
      return customerIds.length;
    },
    onSuccess: (count) => {
      if (count > 0) {
        queryClient.invalidateQueries({ queryKey: ['customers'] });
        toast.success(`Successfully updated ${count} customers`);
        onSuccessCallback();
      }
    },
    onError: (error) => {
      console.error('Bulk update error:', error);
      toast.error('Failed to update customers');
    }
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async () => {
      const customerIds = Array.from(selectedCustomers);
      
      const { error } = await supabase
        .from('customers')
        .update({ status: 'inactive' }) // Soft delete
        .in('id', customerIds);

      if (error) throw error;
      return customerIds.length;
    },
    onSuccess: (count) => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      toast.success(`Successfully marked ${count} customers as inactive`);
      onSuccessCallback();
    },
    onError: (error) => {
      console.error('Bulk delete error:', error);
      toast.error('Failed to delete customers');
    }
  });

  return { bulkUpdateMutation, bulkDeleteMutation };
};
