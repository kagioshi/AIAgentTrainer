
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Search, Filter, UserPlus, Phone, Mail, Edit, Trash2, Users, Upload, Database, Download } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { CustomerWithStats } from '@/types/database';
import CustomerForm from './CustomerForm';
import CustomerImport from './CustomerImport';
import CustomerBulkOperations from './CustomerBulkOperations';
import { useToast } from '@/hooks/use-toast';

const CustomerDashboard = () => {
  const [customers, setCustomers] = useState<CustomerWithStats[]>([]);
  const [filteredCustomers, setFilteredCustomers] = useState<CustomerWithStats[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<CustomerWithStats | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isBulkOperationsOpen, setIsBulkOperationsOpen] = useState(false);
  const [filterTier, setFilterTier] = useState<string>('all');
  const { toast } = useToast();

  useEffect(() => {
    fetchCustomers();
  }, []);

  useEffect(() => {
    filterCustomers();
  }, [searchQuery, filterTier, customers]);

  const fetchCustomers = async () => {
    try {
      const { data, error } = await supabase
        .from('customers')
        .select(`
          *,
          calls!inner(id, duration, status)
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const customersWithStats = data?.map(customer => {
        const calls = customer.calls || [];
        const completedCalls = calls.filter(call => call.status === 'completed');
        
        return {
          ...customer,
          total_calls: calls.length,
          avg_duration: completedCalls.length > 0 
            ? completedCalls.reduce((sum, call) => sum + (call.duration || 0), 0) / completedCalls.length 
            : 0,
          satisfaction_score: Math.random() * 5 // Mock satisfaction score
        };
      }) || [];

      setCustomers(customersWithStats);
    } catch (error) {
      console.error('Error fetching customers:', error);
      toast({
        title: "Error",
        description: "Failed to load customers.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const filterCustomers = () => {
    let filtered = customers;

    if (searchQuery) {
      filtered = filtered.filter(customer => 
        customer.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        customer.last_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        customer.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        customer.phone_number?.includes(searchQuery)
      );
    }

    if (filterTier !== 'all') {
      filtered = filtered.filter(customer => customer.tier === filterTier);
    }

    setFilteredCustomers(filtered);
  };

  const handleCustomerSubmit = (customer: any) => {
    setIsFormOpen(false);
    setSelectedCustomer(null);
    fetchCustomers();
  };

  const handleDeleteCustomer = async (customerId: string) => {
    if (!confirm('Are you sure you want to delete this customer?')) return;

    try {
      const { error } = await supabase
        .from('customers')
        .update({ status: 'inactive' })
        .eq('id', customerId);

      if (error) throw error;

      toast({
        title: "Customer Deleted",
        description: "Customer has been deactivated successfully.",
      });

      fetchCustomers();
    } catch (error) {
      console.error('Error deleting customer:', error);
      toast({
        title: "Error",
        description: "Failed to delete customer.",
        variant: "destructive"
      });
    }
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'platinum': return 'bg-purple-100 text-purple-700 border-purple-300';
      case 'gold': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'silver': return 'bg-gray-100 text-gray-700 border-gray-300';
      default: return 'bg-green-100 text-green-700 border-green-300';
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const exportAllCustomers = () => {
    const csvContent = [
      'phone_number,email,first_name,last_name,tier,status,notes,tags,total_calls,avg_duration,satisfaction_score,created_at',
      ...customers.map(customer => [
        customer.phone_number,
        customer.email || '',
        customer.first_name || '',
        customer.last_name || '',
        customer.tier || 'bronze',
        customer.status || 'active',
        customer.notes?.replace(/,/g, ';') || '',
        Array.isArray(customer.tags) ? customer.tags.join(';') : '',
        customer.total_calls || 0,
        customer.avg_duration || 0,
        customer.satisfaction_score || 0,
        customer.created_at
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `all_customers_export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast({
      title: "Export Complete",
      description: `Exported ${customers.length} customers to CSV`,
    });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Customer Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">Loading customers...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Customer Management</h2>
        <div className="flex gap-2">
          <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="w-4 h-4 mr-2" />
                Import CSV
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
              <DialogHeader>
                <DialogTitle>Import Customers</DialogTitle>
              </DialogHeader>
              <CustomerImport onClose={() => setIsImportOpen(false)} />
            </DialogContent>
          </Dialog>

          <Dialog open={isBulkOperationsOpen} onOpenChange={setIsBulkOperationsOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Database className="w-4 h-4 mr-2" />
                Bulk Operations
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-auto">
              <DialogHeader>
                <DialogTitle>Bulk Customer Operations</DialogTitle>
              </DialogHeader>
              <CustomerBulkOperations 
                customers={filteredCustomers} 
                onClose={() => setIsBulkOperationsOpen(false)} 
              />
            </DialogContent>
          </Dialog>

          <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => setSelectedCustomer(null)}>
                <UserPlus className="w-4 h-4 mr-2" />
                Add Customer
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Customer Information</DialogTitle>
              </DialogHeader>
              <CustomerForm
                customer={selectedCustomer}
                onSubmit={handleCustomerSubmit}
                onCancel={() => setIsFormOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Users className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Total Customers</p>
                <p className="text-2xl font-bold">{customers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="h-4 w-4 rounded-full bg-purple-500" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Platinum</p>
                <p className="text-2xl font-bold">
                  {customers.filter(c => c.tier === 'platinum').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="h-4 w-4 rounded-full bg-yellow-500" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Gold</p>
                <p className="text-2xl font-bold">
                  {customers.filter(c => c.tier === 'gold').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <div className="ml-2">
                <p className="text-sm font-medium leading-none">Avg Satisfaction</p>
                <p className="text-2xl font-bold">
                  {customers.length > 0 
                    ? (customers.reduce((sum, c) => sum + (c.satisfaction_score || 0), 0) / customers.length).toFixed(1)
                    : '0.0'
                  }
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search customers by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select 
              value={filterTier}
              onChange={(e) => setFilterTier(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md"
            >
              <option value="all">All Tiers</option>
              <option value="bronze">Bronze</option>
              <option value="silver">Silver</option>
              <option value="gold">Gold</option>
              <option value="platinum">Platinum</option>
            </select>

            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              More Filters
            </Button>

            <Button variant="outline" size="sm" onClick={exportAllCustomers}>
              <Download className="w-4 h-4 mr-2" />
              Export All
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Customer Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            Customers ({filteredCustomers.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Customer</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Tier</TableHead>
                <TableHead>Total Calls</TableHead>
                <TableHead>Avg Duration</TableHead>
                <TableHead>Satisfaction</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCustomers.map((customer) => (
                <TableRow key={customer.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {customer.first_name && customer.last_name 
                          ? `${customer.first_name} ${customer.last_name}`
                          : 'Unknown Customer'
                        }
                      </div>
                      <div className="text-sm text-gray-600">
                        Added {new Date(customer.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex items-center gap-1 text-sm">
                        <Phone className="w-3 h-3" />
                        {customer.phone_number}
                      </div>
                      {customer.email && (
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <Mail className="w-3 h-3" />
                          {customer.email}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getTierColor(customer.tier || 'bronze')}>
                      {customer.tier || 'bronze'}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono">
                    {customer.total_calls || 0}
                  </TableCell>
                  <TableCell className="font-mono">
                    {formatDuration(customer.avg_duration || 0)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <span className="font-medium">
                        {(customer.satisfaction_score || 0).toFixed(1)}
                      </span>
                      <span className="text-gray-500 ml-1">/5</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedCustomer(customer)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>Edit Customer</DialogTitle>
                          </DialogHeader>
                          <CustomerForm
                            customer={selectedCustomer}
                            onSubmit={handleCustomerSubmit}
                            onCancel={() => setSelectedCustomer(null)}
                          />
                        </DialogContent>
                      </Dialog>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteCustomer(customer.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {filteredCustomers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No customers found matching your criteria</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerDashboard;
