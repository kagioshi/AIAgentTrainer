
import React from 'react';
import { Bot, User, Clock, Phone, CheckCircle } from 'lucide-react';

interface Agent {
  id: string;
  name: string;
  type: 'ai' | 'human';
  status: 'available' | 'busy' | 'break' | 'offline';
  currentCall?: string;
  callsHandled: number;
  avgHandleTime: string;
  satisfaction: number;
}

const AgentStatusGrid = () => {
  const agents: Agent[] = [
    {
      id: 'A001',
      name: 'AI Agent Alpha',
      type: 'ai',
      status: 'busy',
      currentCall: 'Sarah Johnson',
      callsHandled: 23,
      avgHandleTime: '3:42',
      satisfaction: 4.8
    },
    {
      id: 'A002',
      name: 'AI Agent Beta',
      type: 'ai',
      status: 'available',
      callsHandled: 18,
      avgHandleTime: '4:15',
      satisfaction: 4.6
    },
    {
      id: 'H001',
      name: 'John Smith',
      type: 'human',
      status: 'busy',
      currentCall: 'David Wilson',
      callsHandled: 12,
      avgHandleTime: '6:30',
      satisfaction: 4.9
    },
    {
      id: 'H002',
      name: 'Maria Garcia',
      type: 'human',
      status: 'break',
      callsHandled: 8,
      avgHandleTime: '5:45',
      satisfaction: 4.7
    },
    {
      id: 'A003',
      name: 'AI Agent Gamma',
      type: 'ai',
      status: 'available',
      callsHandled: 31,
      avgHandleTime: '3:28',
      satisfaction: 4.9
    },
    {
      id: 'H003',
      name: 'Alex Johnson',
      type: 'human',
      status: 'offline',
      callsHandled: 0,
      avgHandleTime: '0:00',
      satisfaction: 0
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-500';
      case 'busy': return 'bg-yellow-500 animate-pulse';
      case 'break': return 'bg-orange-500';
      case 'offline': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'Available';
      case 'busy': return 'On Call';
      case 'break': return 'On Break';
      case 'offline': return 'Offline';
      default: return 'Unknown';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <User className="w-5 h-5" />
          Agent Status
        </h3>
        <div className="text-sm text-gray-300">
          {agents.filter(a => a.status === 'available').length} Available / {agents.length} Total
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-white/5 rounded-lg p-4 hover:bg-white/10 transition-colors">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                {agent.type === 'ai' ? (
                  <Bot className="w-5 h-5 text-blue-400" />
                ) : (
                  <User className="w-5 h-5 text-green-400" />
                )}
                <span className="text-white font-medium">{agent.name}</span>
              </div>
              <div className={`w-3 h-3 rounded-full ${getStatusColor(agent.status)}`}></div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Status:</span>
                <span className="text-white text-sm">{getStatusText(agent.status)}</span>
              </div>

              {agent.currentCall && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Current Call:</span>
                  <span className="text-cyan-400 text-sm">{agent.currentCall}</span>
                </div>
              )}

              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Calls Today:</span>
                <span className="text-white text-sm">{agent.callsHandled}</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Avg Handle Time:</span>
                <span className="text-white text-sm font-mono">{agent.avgHandleTime}</span>
              </div>

              {agent.satisfaction > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-gray-400 text-sm">Rating:</span>
                  <div className="flex items-center gap-1">
                    <span className="text-yellow-400 text-sm">{agent.satisfaction}</span>
                    <CheckCircle className="w-3 h-3 text-yellow-400" />
                  </div>
                </div>
              )}
            </div>

            {agent.status === 'available' && (
              <button className="w-full mt-3 px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors">
                Assign Next Call
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default AgentStatusGrid;
