import React, { useState, useEffect } from 'react';
import { Phone, Clock, User, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Database } from '@/integrations/supabase/types';
import DashboardErrorBoundary from './DashboardErrorBoundary';

// Use the database types directly to ensure compatibility
type DatabaseCall = Database['public']['Tables']['calls']['Row'];
type DatabaseCustomer = Database['public']['Tables']['customers']['Row'];
type DatabaseProfile = Database['public']['Tables']['profiles']['Row'];

// Create specific interfaces for the query results
interface CallCustomer {
  first_name: string | null;
  last_name: string | null;
  phone_number: string;
}

interface CallProfile {
  first_name: string | null;
  last_name: string | null;
}

interface Call extends DatabaseCall {
  customers?: CallCustomer;
  profiles?: CallProfile;
}

const CallFeedWidgetContent = () => {
  const [calls, setCalls] = useState<Call[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'queued': return 'bg-yellow-500';
      case 'active': return 'bg-green-500 animate-pulse';
      case 'completed': return 'bg-blue-500';
      case 'dropped': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getPriorityColor = (callType: string) => {
    switch (callType) {
      case 'inbound': return 'border-l-blue-500';
      case 'outbound': return 'border-l-green-500';
      default: return 'border-l-gray-500';
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getTimeAgo = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} min ago`;
    const hours = Math.floor(diffInMinutes / 60);
    return `${hours}h ago`;
  };

  useEffect(() => {
    const fetchCalls = async () => {
      try {
        console.log('Fetching calls from database...');
        setError(null);
        
        const { data, error } = await supabase
          .from('calls')
          .select(`
            *,
            customers (first_name, last_name, phone_number),
            profiles (first_name, last_name)
          `)
          .in('status', ['queued', 'active', 'completed', 'dropped'])
          .order('created_at', { ascending: false })
          .limit(10);

        if (error) {
          console.error('Error fetching calls:', error);
          throw error;
        }
        
        console.log('Fetched calls:', data?.length || 0);
        setCalls(data || []);
      } catch (error) {
        console.error('Error fetching calls:', error);
        const errorMessage = error instanceof Error ? error.message : 'Failed to load calls';
        setError(errorMessage);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCalls();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('call-feed')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'calls'
      }, () => {
        console.log('Call update detected, refreshing...');
        fetchCalls();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Update duration for active calls
  useEffect(() => {
    const interval = setInterval(() => {
      setCalls(prevCalls => 
        prevCalls.map(call => {
          if (call.status === 'active') {
            const now = new Date();
            const started = new Date(call.created_at);
            const duration = Math.floor((now.getTime() - started.getTime()) / 1000);
            return { ...call, duration };
          }
          return call;
        })
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  if (isLoading) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 h-full">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-white flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Live Call Feed
          </h3>
          <div className="flex items-center gap-2">
            <Loader2 className="w-4 h-4 text-blue-400 animate-spin" />
            <span className="text-sm text-gray-300">Loading...</span>
          </div>
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white/5 rounded-lg p-4 animate-pulse">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                  <div className="space-y-2">
                    <div className="w-32 h-4 bg-gray-500 rounded"></div>
                    <div className="w-24 h-3 bg-gray-600 rounded"></div>
                  </div>
                </div>
                <div className="w-16 h-4 bg-gray-500 rounded"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 h-full">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-semibold text-white flex items-center gap-2">
            <Phone className="w-5 h-5" />
            Live Call Feed
          </h3>
        </div>
        <div className="flex items-center justify-center h-64">
          <div className="text-center text-red-400">
            <AlertCircle className="w-8 h-8 mx-auto mb-2" />
            <p>Error loading calls: {error}</p>
            <button 
              onClick={() => window.location.reload()}
              className="mt-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 h-full">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <Phone className="w-5 h-5" />
          Live Call Feed
        </h3>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">Live ({calls.length})</span>
        </div>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {calls.length === 0 ? (
          <div className="text-center text-gray-400 py-8">
            <Phone className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <h4 className="text-lg font-medium mb-2">No Active Calls</h4>
            <p className="text-sm">Call activity will appear here when customers connect</p>
          </div>
        ) : (
          calls.map((call) => (
            <div 
              key={call.id} 
              className={`bg-white/5 rounded-lg p-4 border-l-4 ${getPriorityColor(call.call_type)} hover:bg-white/10 transition-colors`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(call.status || 'queued')}`}></div>
                  <div>
                    <div className="text-white font-medium">
                      {call.customers?.first_name && call.customers?.last_name 
                        ? `${call.customers.first_name} ${call.customers.last_name}`
                        : 'Unknown Caller'
                      }
                    </div>
                    <div className="text-gray-400 text-sm">
                      {call.customers?.phone_number || 'No phone number'}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white text-sm font-mono">
                    {formatDuration(call.duration || 0)}
                  </div>
                  <div className="text-gray-400 text-xs">
                    {getTimeAgo(call.created_at)}
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/10">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-300 text-sm">
                    {call.profiles?.first_name && call.profiles?.last_name
                      ? `${call.profiles.first_name} ${call.profiles.last_name}`
                      : call.agent_id 
                        ? 'AI Agent'
                        : 'Waiting'
                    }
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs px-2 py-1 bg-white/10 rounded-full text-gray-300 capitalize">
                    {call.status || 'unknown'}
                  </span>
                  <span className="text-xs px-2 py-1 bg-white/5 rounded-full text-gray-400 capitalize">
                    {call.call_type}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

const CallFeedWidget = () => (
  <DashboardErrorBoundary componentName="Call Feed Widget">
    <CallFeedWidgetContent />
  </DashboardErrorBoundary>
);

export default CallFeedWidget;
