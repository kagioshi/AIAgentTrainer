
import React, { useState } from 'react';
import { Search, User, Phone, Mail, Calendar, Clock, Star } from 'lucide-react';

interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  lastContact: string;
  totalCalls: number;
  avgSatisfaction: number;
  openIssues: number;
  notes: string;
}

const CustomerLookup = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const customers: Customer[] = [
    {
      id: 'CUST001',
      name: 'Sarah Johnson',
      email: 'sarah.johnson@example.com',
      phone: '+1 (555) 123-4567',
      tier: 'gold',
      lastContact: '2 hours ago',
      totalCalls: 15,
      avgSatisfaction: 4.8,
      openIssues: 1,
      notes: 'Prefers email communication. Technical background.'
    },
    {
      id: 'CUST002',
      name: 'Mike Chen',
      email: 'mike.chen@example.com',
      phone: '+1 (555) 987-6543',
      tier: 'platinum',
      lastContact: '1 day ago',
      totalCalls: 28,
      avgSatisfaction: 4.9,
      openIssues: 0,
      notes: 'VIP customer. Always escalate billing issues.'
    },
    {
      id: 'CUST003',
      name: 'Lisa Brown',
      email: 'lisa.brown@example.com',
      phone: '+1 (555) 456-7890',
      tier: 'silver',
      lastContact: '3 days ago',
      totalCalls: 7,
      avgSatisfaction: 4.2,
      openIssues: 2,
      notes: 'New customer. Requires detailed explanations.'
    }
  ];

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone.includes(searchTerm)
  );

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'platinum': return 'text-purple-400 bg-purple-500/20';
      case 'gold': return 'text-yellow-400 bg-yellow-500/20';
      case 'silver': return 'text-gray-300 bg-gray-500/20';
      case 'bronze': return 'text-orange-400 bg-orange-500/20';
      default: return 'text-gray-400 bg-gray-500/20';
    }
  };

  const getTierIcon = (tier: string) => {
    switch (tier) {
      case 'platinum': return '💎';
      case 'gold': return '🏆';
      case 'silver': return '🥈';
      case 'bronze': return '🥉';
      default: return '👤';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <User className="w-5 h-5" />
          Customer Lookup
        </h3>
      </div>

      {/* Search */}
      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search by name, email, or phone..."
          className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
        />
      </div>

      {/* Search Results */}
      {searchTerm && (
        <div className="mb-6">
          <h4 className="text-sm font-medium text-gray-300 mb-3">Search Results ({filteredCustomers.length})</h4>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {filteredCustomers.map((customer) => (
              <div
                key={customer.id}
                onClick={() => setSelectedCustomer(customer)}
                className="p-3 bg-white/5 rounded-lg hover:bg-white/10 cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{getTierIcon(customer.tier)}</span>
                    <div>
                      <div className="text-white font-medium">{customer.name}</div>
                      <div className="text-gray-400 text-sm">{customer.phone}</div>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full capitalize ${getTierColor(customer.tier)}`}>
                    {customer.tier}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Customer Details */}
      {selectedCustomer && (
        <div className="bg-white/5 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{getTierIcon(selectedCustomer.tier)}</span>
              <div>
                <div className="text-white text-lg font-semibold">{selectedCustomer.name}</div>
                <span className={`text-xs px-2 py-1 rounded-full capitalize ${getTierColor(selectedCustomer.tier)}`}>
                  {selectedCustomer.tier} Member
                </span>
              </div>
            </div>
            <button
              onClick={() => setSelectedCustomer(null)}
              className="text-gray-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <Mail className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300">{selectedCustomer.email}</span>
            </div>
            <div className="flex items-center gap-3">
              <Phone className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300">{selectedCustomer.phone}</span>
            </div>
            <div className="flex items-center gap-3">
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300">Last contact: {selectedCustomer.lastContact}</span>
            </div>
          </div>

          {/* Customer Stats */}
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="text-center">
              <div className="text-white font-bold">{selectedCustomer.totalCalls}</div>
              <div className="text-gray-400 text-xs">Total Calls</div>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-1">
                <span className="text-white font-bold">{selectedCustomer.avgSatisfaction}</span>
                <Star className="w-3 h-3 text-yellow-400" />
              </div>
              <div className="text-gray-400 text-xs">Avg Rating</div>
            </div>
            <div className="text-center">
              <div className="text-white font-bold">{selectedCustomer.openIssues}</div>
              <div className="text-gray-400 text-xs">Open Issues</div>
            </div>
          </div>

          {/* Notes */}
          <div className="mt-4 pt-4 border-t border-white/10">
            <div className="text-gray-400 text-sm mb-2">Notes:</div>
            <div className="text-gray-300 text-sm">{selectedCustomer.notes}</div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2 mt-4">
            <button className="flex-1 px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded transition-colors">
              Call Customer
            </button>
            <button className="flex-1 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded transition-colors">
              View History
            </button>
          </div>
        </div>
      )}

      {/* Quick Stats */}
      {!selectedCustomer && (
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-white font-bold">1,247</div>
            <div className="text-gray-400 text-xs">Total Customers</div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-white font-bold">89%</div>
            <div className="text-gray-400 text-xs">Satisfaction</div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-white font-bold">23</div>
            <div className="text-gray-400 text-xs">VIP Customers</div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerLookup;
