
import React, { useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import useVoiceCall from '@/hooks/useVoiceCall';
import { useMessages } from '@/hooks/useMessages';
import { formatCallDuration } from '@/utils/voiceUtils';

// Import our new components
import MessageList from './voice-interface/MessageList';
import VoiceStatusIndicator from './voice-interface/VoiceStatusIndicator';
import MessageInput from './voice-interface/MessageInput';
import CallHeader from './voice-interface/CallHeader';

const StreamingInterface = () => {
  const { toast } = useToast();
  
  // Use our hooks for messages and voice calls
  const { 
    messages, 
    isStreaming, 
    streamedResponse, 
    simulateStreaming,
    setMessages
  } = useMessages();
  
  const { 
    isInCall,
    voiceState,
    isRecording,
    isMuted,
    callDuration,
    startCall,
    endCall,
    toggleMute,
    toggleRecording
  } = useVoiceCall(handleSpeechRecognized);

  // Handle speech recognized from voice call
  function handleSpeechRecognized(userText: string, aiResponse: string) {
    // Add the conversation to the messages
    setMessages(prev => [...prev, 
      {
        id: prev.length + 1,
        text: userText,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString()
      },
      {
        id: prev.length + 2,
        text: aiResponse,
        sender: 'ai',
        timestamp: new Date().toLocaleTimeString()
      }
    ]);
  }

  const handleSendMessage = useCallback((message: string) => {
    simulateStreaming(message);
  }, [simulateStreaming]);

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 h-96 flex flex-col">
      <CallHeader 
        isInCall={isInCall}
        callDuration={callDuration}
        formatDuration={formatCallDuration}
      />
      
      <MessageList 
        messages={messages}
        isStreaming={isStreaming}
        streamedResponse={streamedResponse}
      />
      
      <VoiceStatusIndicator 
        voiceState={voiceState}
        isInCall={isInCall}
        isRecording={isRecording}
        isMuted={isMuted}
        toggleMute={toggleMute}
        toggleRecording={toggleRecording}
      />
      
      <MessageInput 
        isStreaming={isStreaming}
        isInCall={isInCall}
        onSendMessage={handleSendMessage}
        onStartCall={startCall}
        onEndCall={endCall}
      />
    </div>
  );
};

export default StreamingInterface;
