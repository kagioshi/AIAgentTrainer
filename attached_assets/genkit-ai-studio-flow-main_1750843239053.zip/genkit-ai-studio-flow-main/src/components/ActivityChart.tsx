
import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, AreaChart, Area } from 'recharts';

const ActivityChart = () => {
  const data = [
    { time: '9:00', inbound: 45, answered: 42, abandoned: 3 },
    { time: '10:00', inbound: 52, answered: 48, abandoned: 4 },
    { time: '11:00', inbound: 38, answered: 36, abandoned: 2 },
    { time: '12:00', inbound: 61, answered: 55, abandoned: 6 },
    { time: '13:00', inbound: 43, answered: 41, abandoned: 2 },
    { time: '14:00', inbound: 55, answered: 52, abandoned: 3 },
    { time: '15:00', inbound: 47, answered: 45, abandoned: 2 },
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white">Call Volume Today</h3>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">Live</span>
        </div>
      </div>
      
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis 
              dataKey="time" 
              stroke="rgba(255,255,255,0.6)"
              fontSize={12}
            />
            <YAxis 
              stroke="rgba(255,255,255,0.6)"
              fontSize={12}
            />
            <Area 
              type="monotone" 
              dataKey="inbound" 
              stackId="1"
              stroke="#3B82F6" 
              fill="#3B82F6"
              fillOpacity={0.3}
            />
            <Area 
              type="monotone" 
              dataKey="answered" 
              stackId="2"
              stroke="#10B981" 
              fill="#10B981"
              fillOpacity={0.6}
            />
            <Line 
              type="monotone" 
              dataKey="abandoned" 
              stroke="#EF4444" 
              strokeWidth={2}
              dot={{ fill: '#EF4444', strokeWidth: 2, r: 3 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      
      <div className="flex justify-center gap-6 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
          <span className="text-gray-300 text-sm">Inbound Calls</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-gray-300 text-sm">Answered</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span className="text-gray-300 text-sm">Abandoned</span>
        </div>
      </div>
    </div>
  );
};

export default ActivityChart;
