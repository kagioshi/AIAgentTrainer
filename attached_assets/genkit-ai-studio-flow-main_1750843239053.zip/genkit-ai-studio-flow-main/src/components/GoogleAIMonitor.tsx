
import React from 'react';
import { Bot, Wifi, Zap, Activity, AlertCircle, CheckCircle } from 'lucide-react';

const GoogleAIMonitor = () => {
  const aiModels = [
    {
      name: 'Gemini Pro',
      status: 'active',
      responseTime: '245ms',
      accuracy: 94.2,
      requestsPerMin: 847,
      uptime: 99.9
    },
    {
      name: 'PaLM 2',
      status: 'active',
      responseTime: '180ms',
      accuracy: 92.8,
      requestsPerMin: 623,
      uptime: 99.7
    },
    {
      name: 'Codey',
      status: 'maintenance',
      responseTime: 'N/A',
      accuracy: 91.5,
      requestsPerMin: 0,
      uptime: 98.2
    }
  ];

  const systemMetrics = {
    apiHealth: 'excellent',
    totalRequests: 15420,
    errorRate: 0.3,
    avgLatency: '210ms'
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'maintenance': return <AlertCircle className="w-4 h-4 text-yellow-400" />;
      case 'offline': return <AlertCircle className="w-4 h-4 text-red-400" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'maintenance': return 'text-yellow-400';
      case 'offline': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'excellent': return 'text-green-400';
      case 'good': return 'text-blue-400';
      case 'warning': return 'text-yellow-400';
      case 'critical': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-white flex items-center gap-2">
          <Bot className="w-5 h-5" />
          Google AI Studio Status
        </h3>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-gray-300">Connected</span>
        </div>
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center mb-2">
            <Wifi className={`w-5 h-5 ${getHealthColor(systemMetrics.apiHealth)}`} />
          </div>
          <div className="text-white font-medium">API Health</div>
          <div className={`text-sm capitalize ${getHealthColor(systemMetrics.apiHealth)}`}>
            {systemMetrics.apiHealth}
          </div>
        </div>

        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center mb-2">
            <Activity className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-white font-medium">Requests</div>
          <div className="text-blue-400 text-sm">{systemMetrics.totalRequests.toLocaleString()}</div>
        </div>

        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center mb-2">
            <Zap className="w-5 h-5 text-yellow-400" />
          </div>
          <div className="text-white font-medium">Latency</div>
          <div className="text-yellow-400 text-sm">{systemMetrics.avgLatency}</div>
        </div>

        <div className="bg-white/5 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center mb-2">
            <AlertCircle className="w-5 h-5 text-green-400" />
          </div>
          <div className="text-white font-medium">Error Rate</div>
          <div className="text-green-400 text-sm">{systemMetrics.errorRate}%</div>
        </div>
      </div>

      {/* AI Models Status */}
      <div className="space-y-4">
        <h4 className="text-lg font-medium text-white">AI Models</h4>
        {aiModels.map((model, index) => (
          <div key={index} className="bg-white/5 rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                {getStatusIcon(model.status)}
                <div>
                  <div className="text-white font-medium">{model.name}</div>
                  <div className={`text-sm capitalize ${getStatusColor(model.status)}`}>
                    {model.status}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-white text-sm">
                  {model.uptime}% uptime
                </div>
                <div className="text-gray-400 text-xs">Last 24h</div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-gray-400 text-xs">Response Time</div>
                <div className="text-white font-medium">{model.responseTime}</div>
              </div>
              <div className="text-center">
                <div className="text-gray-400 text-xs">Accuracy</div>
                <div className="text-white font-medium">{model.accuracy}%</div>
              </div>
              <div className="text-center">
                <div className="text-gray-400 text-xs">Req/Min</div>
                <div className="text-white font-medium">{model.requestsPerMin}</div>
              </div>
            </div>

            {/* Model Health Bar */}
            <div className="mt-3">
              <div className="w-full bg-white/10 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${
                    model.status === 'active' ? 'bg-green-500' :
                    model.status === 'maintenance' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${model.uptime}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="flex gap-3 mt-6 pt-6 border-t border-white/20">
        <button className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors">
          Refresh Status
        </button>
        <button className="flex-1 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white text-sm rounded-lg transition-colors">
          Configure Models
        </button>
      </div>
    </div>
  );
};

export default GoogleAIMonitor;
