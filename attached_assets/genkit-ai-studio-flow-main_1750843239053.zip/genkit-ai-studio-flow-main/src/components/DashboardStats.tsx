import React from 'react';
import { Phone, Users, Clock, TrendingUp } from 'lucide-react';
import { useDashboardData } from '@/hooks/useDashboardData';
import DashboardErrorBoundary from './DashboardErrorBoundary';

const DashboardStatsContent = () => {
  const { 
    activeCalls, 
    availableAgents, 
    avgHandleTime, 
    customerSatisfaction, 
    isLoading, 
    error 
  } = useDashboardData();

  const stats = [
    {
      label: 'Active Calls',
      value: isLoading ? '...' : activeCalls.toString(),
      change: '+3 from last hour',
      icon: Phone,
      color: 'from-green-500 to-emerald-500',
      status: 'active'
    },
    {
      label: 'Available Agents',
      value: isLoading ? '...' : availableAgents,
      change: '53% availability',
      icon: Users,
      color: 'from-blue-500 to-cyan-500',
      status: 'good'
    },
    {
      label: 'Avg Handle Time',
      value: isLoading ? '...' : avgHandleTime,
      change: '-18s from yesterday',
      icon: Clock,
      color: 'from-purple-500 to-pink-500',
      status: 'improved'
    },
    {
      label: 'Customer Satisfaction',
      value: isLoading ? '...' : customerSatisfaction,
      change: '+0.2 this week',
      icon: TrendingUp,
      color: 'from-orange-500 to-red-500',
      status: 'excellent'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-green-400';
      case 'good': return 'text-blue-400';
      case 'improved': return 'text-purple-400';
      case 'excellent': return 'text-orange-400';
      default: return 'text-gray-400';
    }
  };

  if (error) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="lg:col-span-4 bg-red-500/10 backdrop-blur-lg rounded-2xl p-6 border border-red-500/20">
          <div className="text-red-400 text-center">
            <TrendingUp className="w-8 h-8 mx-auto mb-2" />
            <p>Error loading dashboard data: {error}</p>
            <button 
              onClick={() => window.location.reload()} 
              className="mt-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-sm rounded-lg transition-colors"
            >
              Retry
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <div key={index} className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/15 transition-colors">
            <div className="flex items-center justify-between mb-4">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center ${isLoading ? 'animate-pulse' : ''}`}>
                <Icon className="w-6 h-6 text-white" />
              </div>
              <div className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${stat.status === 'active' ? 'bg-green-400 animate-pulse' : 'bg-gray-400'}`}></div>
              </div>
            </div>
            
            <div>
              <div className={`text-2xl font-bold text-white mb-1 ${isLoading ? 'animate-pulse' : ''}`}>
                {stat.value}
              </div>
              <div className="text-gray-300 text-sm mb-1">{stat.label}</div>
              <div className={`text-xs font-medium ${getStatusColor(stat.status)}`}>
                {stat.change}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const DashboardStats = () => (
  <DashboardErrorBoundary componentName="Dashboard Stats">
    <DashboardStatsContent />
  </DashboardErrorBoundary>
);

export default DashboardStats;
