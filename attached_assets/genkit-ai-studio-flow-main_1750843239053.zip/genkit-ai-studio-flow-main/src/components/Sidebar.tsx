
import React from 'react';
import { 
  Phone, 
  Settings, 
  Users, 
  UserCheck, 
  Monitor,
  BarChart3,
  MessageSquare,
  Clock,
  Shield,
  Megaphone,
  Brain,
  Zap
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const Sidebar = ({ activeSection, onSectionChange }: SidebarProps) => {
  const sections = [
    { id: 'dashboard', label: 'Dashboard', icon: Monitor },
    { id: 'calls', label: 'Active Calls', icon: Phone },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'campaigns', label: 'Campaigns', icon: Megaphone },
    { id: 'ai-features', label: 'AI Features', icon: Brain },
    { id: 'integrations', label: 'Integrations', icon: Zap },
    { id: 'agents', label: 'Agents', icon: UserCheck },
    { id: 'queue', label: 'Call Queue', icon: Clock },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'conversations', label: 'Conversations', icon: MessageSquare },
    { id: 'quality', label: 'Quality Control', icon: Shield },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="w-64 bg-white/10 backdrop-blur-lg border-r border-white/20 min-h-screen">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
            <Phone className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">AI Contact Center</h1>
            <p className="text-sm text-gray-300">Powered by Google AI</p>
          </div>
        </div>
        
        <nav className="space-y-2">
          {sections.map((section) => {
            const Icon = section.icon;
            const isActive = activeSection === section.id;
            
            return (
              <button
                key={section.id}
                onClick={() => onSectionChange(section.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                  isActive 
                    ? 'bg-white/20 text-white shadow-lg' 
                    : 'text-gray-300 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{section.label}</span>
                {isActive && (
                  <div className="w-2 h-2 bg-cyan-400 rounded-full ml-auto"></div>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};

export default Sidebar;
